# oiagent 协作团队分工 — 连接器 / 技能 / 工作流 推进顺序 · 2026-08-13

> 承接:[oiagent-coworker-plan](oiagent-coworker-plan-2026-08-12.md) §7 能力对标、§8 用户点名缺失项。
> 本文给协作团队(oiagent_coworker 本地包 + 扩展侧)定**统一接口契约 + 推进顺序 + 每步验收**。
> 三条能力共用一套底层红线,先立契约再分工,避免重复工程和各自为政。

## 0. 一句话边界

| 能力 | 是什么 | 底层形态 | 风险基线 |
|---|---|---|---|
| **连接器** | 关联一个在线/本地应用,读数据/代操作 | **白名单 adapter**(凭证本地存) | 每动作按 L0–L3 分级确认 |
| **技能** | 可复用的能力包,让动作可插拔 | **registry 条目 + 提示词模板包** | 继承宿主动作的红线 |
| **工作流** | 把多个动作串成多步流程 | **recipe**(动作数组 + 步骤确认) | 步骤级确认,不批一次全放行 |

三者不并列乱做:**连接器是「手」(触达外部),技能是「招」(单动作模板),工作流是「套路」(连招)。** 但**首个工作流不依赖外部连接器**——用「内部问答周报」(读本地已有问答历史→整理→导出 MD),让用户先用最低门槛感知工作流价值;外部连招(要连接器/群聊数据)排其后。

## 1. 共用红线(三能力同守,不可删,与 M7a/coworker 同源)

1. **动作只来自 NTP 用户输入**;页面内容/附件/工作流中间产物**永不**触发新动作。
2. **白名单 only**:连接器只注册列名的 adapter,技能只用列名模板,工作流只串已注册动作。**无 eval、无任意 shell、无任意 OAuth。**
3. **凭证不进 LLM、不落盘明文**:adapter 凭证本地存(chrome.storage.local / coworker 本地配置),口令只在签名瞬间传递即弃。
4. **确认门槛在扩展侧**:connector/coworker 不替用户做决定;L1 内嵌卡 / L2 全回显 / L3 安全对话框(口令)。
5. **本地优先、默认不上云**:连接器/技能/工作流的定义与日志本地存;任何上传明示 + opt-in。

## 2. 接口契约(三方对齐的「插座」)

### 2.1 连接器 adapter(触达外部应用)
每个连接器一个 adapter 模块,对外只暴露**白名单方法**:

```python
# oiagent_coworker/connectors/<name>.py
class Connector:
    name = "securedm"                 # 注册名
    endpoints = {                     # 白名单方法表(其余一律 404)
        "status":  {"risk": "L0", "fn": api_status},
        "send":    {"risk": "L2", "fn": api_send},   # 发消息要全回显确认
    }
    def call(self, method, params):   # 统一入口:校验 method∈endpoints + schema
        ...
```
- **凭证**:install 时写 coworker 本地配置 + 扩展 storage 各一份(同 token 红线);adapter 自行保管,不进 LLM。
- **风险标注**:每个 endpoint 带 `risk`,扩展侧据此弹对应确认卡。

### 2.2 技能包(单动作可插拔)
技能 = **registry 条目 + 提示词模板**,扩展 `src/agent/registry.js` 已有骨架:

```js
{
  id: 'chatroom_post',                 // 动作 id(白名单)
  risk: 'L2',                          // 确认级别
  params: { /* JSON schema,validateParams 校验 */ },
  promptPack: 'skills/chatroom_post.md', // 技能模板(选填,给 LLM 路由/补参用)
  handler: handleChatroomPost,
}
```
- **可插拔**:新增技能 = 加一个 registry 条目 + (选填)一个模板文件,不动路由/审计/确认框架。
- `catalogForPrompt` 已能把技能清单喂给 LLM 慢路径路由——技能天然接入自然语言触发。

### 2.3 工作流 recipe(多步连招)
recipe = **有序动作数组 + 每步确认策略**,跑在 coworker `/auto/run` 或扩展内:

```json
{
  "id": "weekly_digest",
  "name": "内部问答周报→整理→导出 MD",
  "steps": [
    {"action": "history_collect", "params": {"window": "user_set"}, "confirm": "L0"},
    {"action": "digest_synthesize","params": {"group_by": "topic"},  "confirm": "L0"},
    {"action": "export_md",        "params": {"filename": "auto"},   "confirm": "L1"}
  ]
}
```
- **首个 recipe 用「内部数据问答周报」,不用「周报收料」**(2026-08-13 用户拍板):不依赖外部连接器/群聊数据,从用户已有问答历史整理,门槛低、关联体验好,让用户立刻感知工作流价值。
- **步骤级确认**:敏感步骤(L1+)单步弹卡,**不允许开头批一次全放行**。导出 MD 落 L1(用户确认后存本地)。
- **依赖**:依赖 P0.5 问答历史持久化(本地,默认开)。CW-3 跨 tab 是后续外部 recipe 的底座,本 recipe 不需要。

## 3. 推进顺序与验收

> 原则:**自下而上、每步可独立验收、严禁跳步;严格串行,不并行**(2026-08-13 用户拍板)。

| 序 | 里程碑 | 内容 | 归属 | 验收(真跑,反 flattery) |
|---|---|---|---|---|
| **P0** | **CW-1 骨架** | Prisir 工坊(PrisirWork) HTTP server + token 校验 + endpoint 白名单框架 + `/wallet/status` 只读(testnet Electrum) | coworker | 无 token→401;错 token→401;对 token→200;`netstat` 确认只监听 127.0.0.1 |
| **P0.5** | **问答历史持久化**(前置) | `oiThread` 从 `storage.session` 迁 `storage.local`,**默认开**(用户可关),数据不上云 | 扩展 | 重启浏览器历史仍在;容量有上限(防撑爆);设置里可关;不上任何远端 |
| **P1** | **连接器框架 + 首个 adapter** | connector 基类 + **securedm adapter**(只读先行:`status`/`get_identity`) | coworker + 扩展 registry | 扩展注册 `securedm_status`(L0);白名单外 endpoint→404;凭证不出现在任何 LLM prompt |
| **P2** | **技能包机制** | registry 支持 `promptPack` 模板加载;`catalogForPrompt` 列出技能 | 扩展 | 新增一个技能条目不动路由/审计即可用;自然语言能路由到新技能 |
| **P3** | **连接器写操作(带确认)** | securedm `send` / chatroom_post(L2 全回显) | 扩展确认卡 + adapter | L2 卡全回显待确认;取消不执行;审计落 `agentAudit` |
| **P4** | **CW-3 跨 tab** | CDP 自带受控实例,tabs/step/run,先只读 recipe | coworker | 1 个跨 tab 只读收集 recipe 跑通;敏感 step 强制 L2 |
| **P5** | **工作流引擎 + 首个 recipe** | recipe 解析 + 步骤级确认执行器;**首个跑「内部问答周报」**(收集→整理→导出 MD,定时用 `alarms`) | 扩展为主 + coworker `/auto/run` | 定时/手动触发跑通;导出 MD 前 L1 弹卡;任一 L1+ 步骤单独确认;中途取消不继续 |
| **P6** | **CW-2 钱包** | receive/payto/history,L3 确认,testnet only | coworker | 口令不落盘;memo 强制;**严禁主网真钱** |

**串行链**:P0 → P0.5 → P1 → P2 → P3 → P4 → P5 → P6。P0.5 是首个 recipe(周报)的硬依赖,插在 P0 后。**严格串行**(用户拍板),不并行推进。

## 4. 分工建议(谁做哪块)

- **coworker 本地包(Python)**:P0、P1 adapter、P4 跨 tab、P6 钱包——凡是「浏览器沙箱做不了」的(起进程、跨 tab、持钥)。
- **扩展侧(MV3,JS)**:P0.5 历史持久化、P2 技能机制、P3 确认卡、P5 首个 recipe(内部数据,不出扩展)、registry 注册、审计——凡是「确认门槛 + 用户可见 UI + 本地数据」。
- **联合**:外部多步 recipe(coworker 执行 + 扩展确认 UI);首个内部周报 recipe 数据不出扩展,以扩展为主。

> 一条硬规矩:**确认 UI 永远只在扩展侧**,coworker 不渲染、不决定。这条与 M7a「确认门槛在扩展侧」红线一致,防止本地进程绕过用户。

## 5. 暂不做(本轮明确排除)

- 任意 OAuth 连接器(Gmail/GitHub 等)——先只做生态内白名单(securedm/chatroom/wallet)。
- 项目目录 / 通用工件导出——见 coworker §8,在连接器/技能稳定后排期(首个「导出 MD」特指周报 recipe 的 P5,不算通用工件)。
- 外部数据 recipe(周报收料等要拉连接器/群聊数据的)——等 P1/P3 连接器就位后再排。

> 注:**问答历史本地持久化**原属「跨会话记忆(谨慎)」范畴,经用户拍板**为周报导出而默认开、数据不上云**——见 P0.5。其余跨会话记忆(Brain 概念/实体积累)本轮仍不动。

## 6. 已拍板(2026-08-13)

1. ~~P0 与 P2 并行启动还是严格串行~~ → **严格串行** P0→P0.5→P1→…→P6。
2. ~~首个连接器 securedm 还是 chatroom~~ → **securedm**。理由:`securedm_web.py` 已是成体系本地 `api_*` 服务(status/setup/identity/send…),几乎直接包成 adapter;chatroom 要自己起 relay/client、理清协议,对接成本高。先做 securedm 最快打通白名单 adapter 管线并验证红线(401/凭证不进 LLM),chatroom 排其后。
3. ~~首个 recipe 场景~~ → **内部数据问答周报**:不依赖外部信息,从用户已有问答历史,以周为单位(用户可设时长)整理并**导出 MD**;默认开启,定时(alarms)+手动触发,数据全程本地。
4. ~~问答历史持久化默认开还是 opt-in~~ → **默认开**(用户可在设置关),存 `storage.local`,不上云——这是周报 recipe 的硬依赖(原 `oiThread` 在 `storage.session`,重启即清)。
