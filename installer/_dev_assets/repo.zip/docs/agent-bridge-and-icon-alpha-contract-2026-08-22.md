# 双 Agent 任务移交(浏览器→壳)+ 图标透明化 — 实施契约

日期: 2026-08-22 · 触发: 用户明确「打通两个 agent 的任务通信」(浏览器 agent 接到本地活如「检查驱动」应移交 OIagent 壳执行并反馈)+ 图标黑背景透明化(B:描边保可见)
状态: 已拍板方向,出契约即实施

## 一、双 Agent 任务移交(浏览器 → OIagent 壳)

### 现状缺口(已勘察,勿重查)
- 现有通道(#58)只有**壳→扩展**单向:壳 `oiagent_web.py` 的 `agent/poll`(L2456)/`snap_state`/`pair_status` 服务端已做,但**扩展端 `_shellChannel` 客户端 + browse_* handler 全空**(grep 无匹配)。
- **浏览器→壳方向完全没有**:扩展 `registry.js` 18 个动作(translate_page/social_search/cross_tab_research 等)无任何 delegate/local_exec;扩展无 `127.0.0.1:18802` host 权限(manifest 只有 12308)。

### 设计:补「浏览器 agent → 壳」移交(复用现有,零新框架)

**方向**:浏览器 agent 判断「这是本地活」(驱动/文件/进程/本机状态)→ `delegate_local_task` 动作 → POST 壳 `/oiagent/api/shell_task` → 壳当对话跑 → 结果回执。

1. **壳后端 `oiagent_web.py`**(新增,复用现有原语):
   - **现有缺口**:契约承诺的 `agent/pair`(配对注册)和 `agent/ack`(回执)**根本没实现**(grep 无匹配),只有 `poll`/`snap_state`/`pair_status`。**本期一并补齐 pair/ack**,否则 `_AGENT_PAIRED` 永远空、配对不可用。
   - 模块级:`_PENDING_SHELL = {}`(task_id→{token,task,status,session_id,result})+ `_PENDING_LOCK`;结果经 `_AGENT_QUEUES[token]`(现有 `_agent_enqueue`)回推,扩展走现有 `agent/poll` 拉。**不新建回传通道。**
   - `POST /oiagent/api/agent/pair`:body `{token}` → 校验非空、入 `_AGENT_PAIRED` + 建空队列/回执 + `_pair_save_token(token)`(0600)。幂等。回 `{ok:true, paired:true}`。
   - `POST /oiagent/api/agent/ack`:body `{token, id, ok, result, error?}` → token 校验 → `add_message(_agent_sid(), "tool", "[🌐 浏览器] <name> → 摘要")`(截断 4000)+ 队列空则 `_SNAP_STATE` 收尾。
   - `POST /oiagent/api/shell_task`:body `{token, task, task_id?}`。token 不在 `_AGENT_PAIRED` → 401。**人审(并行确认卡,不悬挂请求线程)**:登记 `_PENDING_SHELL[task_id]={status:"pending"}` 立即回 `{ok:true, task_id, status:"pending_confirm"}`;壳 UI 前端 `setInterval` 轮询新端点 `GET /oiagent/api/shell_pending` 拿到待确认任务 → `dlgConfirm` 弹卡 → 用户点确认/拒 → `POST /oiagent/api/shell_task_confirm {task_id, approve}`。
   - `POST /oiagent/api/shell_task_confirm`:approve=true → `create_session()`(标题前缀 `[浏览器移交]`)、`add_message(sid,"user",_wrap_handoff_as_data(task) 防注入)`、`threading.Thread(_run_chat_thread,...)` 跑本地工具链,`_PENDING_SHELL[task_id]` 置 running;approve=false → 置 rejected,经 `_agent_enqueue` 回推 `{type:"shell_task_result", ok:false, error:"用户拒绝"}`。
   - `_run_chat_thread` 完成钩子(shell_task 来源的会话):把最终 answer 截断(4000)经 `_agent_enqueue(token, {type:"shell_task_result", task_id, ok:true, result})` 回推。
   - **红线**:task 文本走 `_wrap_handoff_as_data` 同款防注入(只当资料),token 不落审计/LLM 明文,`shell_pending` GET 只回 task_id+任务摘要(截断)+来源,不回 token。

2. **扩展 `registry.js`**(新增 1 条):
   - `delegate_local_task`:risk L1,params `{task:{string,required,maxLen:1000}, context:{string,maxLen:500}}`,handler `handleAgentDelegateLocal`,confirm `{style:'inline',timeoutMs:120000}`,trace 'ephemeral'(任务文本可能含本机路径,不落审计明文)。
   - desc 写清触发域:「检查本机驱动/文件/进程/软件版本/本地状态等需要在本机执行的任务」,让 intent 分类器(catalogForPrompt 自动收)能路由到。

3. **扩展 `background.js`**:
   - `_agentDispatch` switch 加 `case 'delegate_local_task': return _agentDelegateLocal(params);`
   - `_agentDelegateLocal(params)`:`chrome.storage.local.get('shellPairToken')` 取 token(无则回 `{ok:false,error:'壳未配对,请到选项页配对'}`)→ `fetch POST http://127.0.0.1:18802/oiagent/api/shell_task {token,task,task_id:crypto.randomUUID()}` → 回 `{ok, task_id, session_id}`;**结果经 poll 异步回来**,handler 立即返回"已移交,执行中,结果稍后回"。
   - `_shellChannel` poll 客户端补 `shell_task_result` 类型分支:收到 → 注入当前 agent 会话为 assistant 消息「本地执行结果:...」。

4. **manifest.json**:`host_permissions` 加 `http://127.0.0.1:18802/*` + `http://localhost:18802/*`。

### 遗留(本期不做,标 TODO)
- **`_shellChannel` poll 客户端的 `shell_task_result` 分支**:结果回传的**接收端**依赖扩展 `_shellChannel` 长轮询(#58 设计但该客户端目前未实现)。本期已把**壳侧发送**(shell_task/shell_task_confirm/pair/ack + `_shell_task_run` 回推 `_agent_enqueue`)做全;扩展侧 `delegate_local_task` 移交动作已可用(任务真到壳、真执行)。结果**回到浏览器会话**这一步待 `_shellChannel` 客户端落地后接 `shell_task_result` 类型注入——那是 #58 通道客户端的活,与本移交动作解耦。当前壳侧结果仍可在壳会话(`[浏览器移交]` 前缀)直接查看,不丢。

### 验收
- 壳:`python -m py_compile oiagent_web.py` 过;`POST /shell_task` 无 token→401、有 token→确认卡→`{ok,task_id,session_id}`;壳会话列表出 `[浏览器移交]` 会话并真跑。
- 扩展:浏览器 agent 接「检查本机驱动」→ intent 路由到 `delegate_local_task` → 壳出确认卡 → 确认后壳执行 → 结果经 poll 回浏览器会话。
- token 全文不出现在 LLM msgs/审计/DOM 明文。

## 二、图标黑背景透明化(B:描边保可见)

### 实测(勿重查)
- 母标 `assets/prisir-mark-metal-v2.png` 1024×1024 RGBA,五尺寸(16/32/48/128/256)是它中心方裁+LANCZOS 降采样(256→48 与现成 48 均差 0.11,**非小图拉伸**,质量好)。
- 背景:四角/四边 RGB≈(17~24, 20~30, 29~39) 深墨蓝近黑,**alpha=255 不透明**;量化主色全深色(20,21,31)系。
- **主体亮度:中心 40% 平均 70/中位 50(偏暗青绿 (105,137,130) 系),背景 25。**

### B 方案要点
主体偏暗(70)不是亮logo,浅色背景下对比弱,深色描边不够——**描边用「亮描边 + 半透明柔影」双保**:
1. 背景透明化:以四角中值色 (20,23,33) 为键,`dist<阈值(≈28)` 像素 alpha→0,边缘羽化(距离渐变 alpha 平滑,防锯齿)。
2. 主体保留:深色/中色主体像素原样。
3. 加可见性框:对 alpha 通道做「膨胀亮描边(1.5px,近白 #E8EEF2,80% 不透明)+ 外层 2px 半透明深色柔影(#0B0E14, 40%)」——亮描边保深背景可见,柔影保浅背景立体。
4. 重出 5 尺寸(从 1024 母标处理后再 LANCZOS 降采样,保精度)+ `prisir-logo.ico` 多尺寸打包(16/32/48/256)。
5. **校验**:生成透明 PNG 后,合成到纯黑底和纯白底各渲染一张目检,确认两底都清晰可辨。

### 产出
- `assets/prisir-logo-{16,32,48,128,256}.png`(透明底新版,覆盖)+ `assets/prisir-logo.ico`
- 同步覆盖 `prisIr-browser/content-cabinet/prisir-logo-48.png`、`prisIr-browser/agent/assets/prisir-logo-48.png`(现用同尺寸)
- 保留原带底版本备份 `assets/prisir-logo-solid-{...}.png`(安装包/任务栏可能仍需方底)

### 红线
- 不动 manifest 里已引用的文件名(覆盖同路径,引用不断)。
- 母标原图 `prisir-mark-metal-v2.png` 不改,只读。

### 实施结果(2026-08-22,B 已交付后被用户否决 → 回退 A)
- B 透明化曾完整落地并自校验(黑/白底目检通过、alpha 量化 {0,96,255} 无灰雾),但用户目检后判定**不能用**,明确改用 **A:保持深色方底不透明**。
- 已从备份 `assets/prisir-logo-solid-{16,32,48,128,256}.png` + `-solid.ico`(8月14 原带底版)**全量还原**为不透明正式图标(已 PIL 实测全 alpha=255),并同步 `prisIr-browser/{content-cabinet,agent/assets}/prisir-logo-48.png`。
- 按用户指示**全删** B 的脚本与透明产物:`assets/gen_logo_alpha.py`、`assets/_preview_on_{black,white}.png` 已删除;solid 系列保留为唯一正式图标源。
- 结论:本批编译/分发用的图标 = 深色方底不透明 solid 版,无透明化。
