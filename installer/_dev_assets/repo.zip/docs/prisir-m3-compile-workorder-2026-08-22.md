# Prisir 浏览器 M3 编译批次 — 待实例施工单

日期: 2026-08-22 · 任务: #59/#66(编译批次)· 类型: 施工单(真编译时照此按依赖顺序施工)
**性质**: 所有本地源码交付已就绪、编译基镜像 `m-j6cgwhn89zx36bc1tp8j` 已 Available(100%)。本单把「一次强实例编译」要做的事**按依赖排序**列全,开实例后照着打,不浪费时薪、不返工。
**前置阅读**: `docs/prisir-browser-compile-architecture-2026-08-20.md`(归置蓝图+检查清单)· `docs/network-link-singbox-contract-2026-08-21.md`(编译环境/SOP/坑)· `prisIr-browser/ARCHITECTURE.md`(整体框架+红线)。

---

## 0. 铁律(施工全程不可违)

- **编译只走 cn-hongkong**: `chromium.googlesource.com` + CIPD 国内 ECS 全被 GFW 断,只有香港直连。
- **强实例 = c8i.8xlarge 按时付费 PostPaid(¥18.58/h),绝不用 Spot/按量**;**用完即 DeleteInstance 释放**,不养常驻。
- **禁区**: Linux 镜像 `m-j6cg6nxefjl4ujykzlwd` 绝不动;编译基 = `m-j6cgwhn89zx36bc1tp8j`(Chromium153 src+obj+ATL+WinSDK 26100,C 400GB,ninja -j48 已验证)。
- **自杀坑**: 任何脚本不得 stop/snapshot 自己所在 host;实例级收尾(stop/做镜像/释放)必须外部执行或 schtasks 分离。
- **凭证**: AK 走系统环境变量,PowerShell `$env:` 注入子进程(Git Bash env 前缀不传 Windows 子进程);密码/key 不落盘、不进脚本、不进 LLM 上下文。
- **红线**: 私钥不出原生层;apiKey 走 os_crypt;默认本地、任何云端用户显式;只存元数据不读文件内容(探囊);不开 TUN/不读系统代理(网络链路);E2E 不降级。

---

## 1. 阶段总览(依赖排序)

```
P0 起实例+恢复编译环境(镜像 5-10min)
   ↓
P1 基线编译链跑通(证明镜像可编 → 出基线 chrome.exe)   ← 不通则一切免谈
   ↓
P2 M-4 libsimplex FFI spike(密信技术前提探活)         ← 风险最高,最先探;失败则密信 2人私信降级为群聊-only,其余照做
   ↓
P3 批量接线(可并行子任务,均依赖 P1 的编译链):
     P3a 网络链路层 proxy(BUILD 并入 + pref 注册 + sing-box 随包 + 3 TODO + B8 视频)
     P3b 智能体原生层 agent(AgentStore/AgentRuntime Mojo + 存储/迁移验证)
     P3c 密信 mixin WebUI(chrome://mixin,群聊 WebCrypto 原样 + 私信走 P2 FFI)
     P3d 论坛 forum WebUI(chrome://forum,原生代签接 identity.mojom)
     P3e 内容柜 content-cabinet(功能按钮入口,内嵌页)
     P3f 探囊 findex(PrisirFindex C++ 薄壳 + ⋮菜单「本机文件搜索」+ chrome://findex)
     P3g NTP 智能体 WebUI(chrome://agent,独立 WebUI 注册)
     P3h ⋮ 菜单契约(#69:统一挂点 app_menu/tools_menu,挂各功能项)
     P3i 品牌层(图标/命名/配置页删 Google+新增 Prisir 三块)
   ↓
P4 出包前检查清单(§6.1 全项,含发布前 VT 自检)
   ↓
P5 收尾(产物拷回持久位 → 外部做新镜像 → 释放实例 → 结算时薪)
```

> 关键路径 = P0→P1→P2→(P3 并行)→P4→P5。P2 是唯一可能「否决某功能」的探活点,必须最早做;P3 各项相互独立,可在 P1 编译链通了之后并行推进(同一实例内多目录 patch)。

---

## 2. P0 — 起实例 + 恢复编译环境

**目标**: 拿到一台能立刻增量编译的 Windows 实例。
- [ ] `RunInstances` cn-hongkong,c8i.8xlarge PostPaid,镜像 `m-j6cgwhn89zx36bc1tp8j`,SG `sg-j6c5xtnlr1v54naric40`,vSwitch `vsw-j6chjrio5ijum3ynw1hxl`(zone cn-hongkong-d)。
- [ ] 实例起来后确认 src/ccache/产物从镜像继承(镜像快照含 25GB 源码 + 已编出 chrome.dll 397.6MB)。
- [ ] 确认运行时 env: `DEPOT_TOOLS_WIN_TOOLCHAIN=0` / `GYP_MSVS_VERSION=2022` / `GYP_MSVS_OVERRIDE_PATH=C:\BuildTools` / `vs2022_install=C:\BuildTools`。
- [ ] **核验镜像仍是 3 个 GN 补丁已打状态**(visual_studio_version.gni / win_toolchain_data.gni / args.gn `use_cxx23=false`+`use_clang_modules=false`)。

## 3. P1 — 基线编译链跑通(门禁)

**目标**: 不改任何功能,先增量编译出基线 `chrome.exe`,证明镜像+工具链可用。
- [ ] 触发一次空增量编译(`ninja -C out\Release chrome`),应秒级~分钟级(ccache 命中)。
- [ ] 跑通 = 基线 `chrome.exe` 能起、CDP 控制面绿。
- [ ] **不通过则停下排查**(工具链/SDK/env),绝不带 broken 链进 P2/P3。

## 4. P2 — M-4 libsimplex FFI spike(密信技术前提,风险最高先探)

**目标**: 验证「libsimplex.dll(Haskell 核心,v6.5.1)经原生 FFI 被 Chromium 原生层调用连 smp.babelspan.com:5223」可行——这是 2 人私信 P-A 编进浏览器的**唯一硬前提**,没验证过。
- [ ] 把 `C:\Users\Administrator\simplex-libs\v6.5.1\sqlite\` 的 `libsimplex.dll` + `.lib` + `.def` 拷进实例,写一个**最小原生 spike**(独立小 exe 或 browser 内一处 test hook):`LoadLibrary` + `GetProcAddress` 调 simplex 初始化 + 建连一个 SMP server。
- [ ] **判活标准**: spike 能初始化 Haskell RTS、能发出一次 SMP 握手、不崩。
- [ ] **失败降级预案**(用户已定): 密信本期只固化**群聊(suite=2 纯 WebCrypto 原样进)+ ML-KEM 后量子进原生层(crypto_conduit 就绪)**;2 人私信降级为「Web/壳版保留,不编进本体」,mixin 页私信 tab 标「桌面版可用」。**其余 P3 项不受影响,照做。**
- [ ] spike 结果(成/败 + 原因)写进交接,作为密信 2 人私信是否进本体的最终依据。

## 5. P3 — 批量接线(依赖 P1,可并行)

> 每项都给出:交付源码位置 → 编译期动作 → 验收。

### P3a 网络链路层 proxy(契约 `network-link-singbox-contract-2026-08-21.md`)
- 源码: `prisIr-browser/proxy/`(BUILD.gn / prisir_proxy.mojom / handler.{h,cc} / prefs / subscription_parse)。
- [ ] `source_set("proxy")` 并入 `chrome/browser/BUILD.gn`(deps 已列)。
- [ ] `browser_prefs.cc` 的 `RegisterProfilePrefs()` 加 `prisir::proxy::RegisterPrisirProxyPrefs(registry);`。
- [ ] 下载 sing-box windows-amd64 release 放 `<out>/prisir-proxy/sing-box.exe`,mini_installer 打包进安装树。
- [ ] handler 以 profile-keyed service 持有(注入 `profile->GetPrefs()`+`profile->GetPath()` + network_context)。
- [ ] 补 3 个 TODO: `SetSubscription` 接 `SimpleURLLoader` 拉订阅体 / `TestLink` 接 `URLLoader` 经已代理 network_context 测延迟 / `ApplyProxyToBrowser` 接 `StoragePartition::GetNetworkContext()->SetProxyConfig`(只本浏览器)。
- [ ] **B8 视频修复一并打**: args.gn `proprietary_codecs=true` + `ffmpeg_branding="Chrome"` + `enable_widevine=true`(CDM 二进制另行下发)。
- 验收: 设置页「网络链路」区可配订阅→StartLink→TestLink 通,只代理浏览器流量。

### P3b 智能体原生层 agent(M2/M3,源码 `prisIr-browser/agent/`)
- [ ] AgentStore 落位: `agent_store.{h,cc}` + `agent_store_prefs.{h,cc}` 编进本体,profile 级存储(PrefService + os_crypt `apikey.enc` + `threads.json`/`memories.json`)。
- [ ] AgentRuntime Mojo(`agent_runtime.mojom`)+ AgentStore Mojo(`agent_store.mojom`)+ handler 接线;**apiKey 只进不出**,时间戳契约 ISO8601 string。
- [ ] identity.mojom 身份根:`DeriveKey`/`SignWith` 实现(Ed25519,私钥不出原生层)——P3d 论坛代签依赖它。
- [ ] 迁移 `migration_m2b.js` 在真实 profile 上跑一次验证(apiKey 审计脱敏/校验失败不置 flag/回滚窗)。
- [ ] 跑 `agent_store_unittest.cc`。
- 验收: NTP 侧经 Mojo 读写配置/会话,apiKey 全程不明文落 prefs。

### P3c 密信 mixin WebUI(chrome://mixin,源码 `prisIr-browser/mixin/`)
- [ ] 照 `chrome_web_ui_configs.cc` 的 `map.AddWebUIConfig` 模式注册 chrome://mixin 独立 WebUI(UIConfig + WebUIController + MojoHandler + `mixin.mojom`)。
- [ ] 群聊(suite=2)纯 WebCrypto 原样进,`group.html` 挂 WebUI;**可插拔签名层**: `nativeReady()` 检测 `window.MixinNative`,就绪走 Mojo 代签,未就绪退 WebCrypto 降级。
- [ ] 2 人私信: 若 P2 spike 成功 → dm.html 私信走 libsimplex FFI(capability-04 同通路);若失败 → 私信 tab 标「桌面版可用」降级。
- [ ] 保留 guohua 浅色主题(assets 已在 mixin/assets/)。
- 验收: 同页两 tab(私信/群聊),群聊 E2E 可跑,身份迁原生层。

### P3d 论坛 forum WebUI(chrome://forum,源码 `prisIr-browser/forum/`)
- [ ] 注册 chrome://forum WebUI;`forum.mojom` 原生代签实现 = `identity.DeriveKey("forum-sign","ed25519-sign")` 薄壳转发(**依赖 P3b 的 identity.mojom 落地**)。
- [ ] 页面侧可插拔签名(forum_client.js 已复刻 mixin 模式): 原生就绪走代签,未就绪退 WebCrypto + localStorage 降级并诚实标注。
- 验收: (a) `window.ForumNative` 存在 (b) 同一身份根两端派生相同 author_fp (c) localStorage 无明文私钥 (d) 发帖/验签/三态渲染正常。

### P3e 内容柜 content-cabinet(源码 `prisIr-browser/content-cabinet/`,最小集成项)
- [ ] 作浏览器功能按钮入口,开内嵌页指向 `content-cabinet.html`(已剥 Google Fonts/sendBeacon/站内导航)。
- [ ] 数据 localStorage(已满足本地优先红线);profile 级持久化(threads.json 思路)**本期不动**,留后续。
- 验收: 增删改查/三视图/导入导出/海报桥全链路在浏览器内可用。

### P3f 探囊 findex(契约 `prisir-findex-compile-contract-2026-08-21.md`,引擎 `prisir_findex/` 已产 dll)
- [ ] `prisir_findex.dll` 随包落地(仿 sing-box 先例),本体 `base::LoadNativeLibrary` / 延迟 `LoadLibrary` 加载。
- [ ] 封装 `PrisirFindex` C++ 薄壳(`components/prisir_findex/`),`GetProcAddress` 解析 7 导出(open/build/query/status/clear/free/free_string)包装同步/回调。
- [ ] 索引库落 `user_data_dir/findex/findex.db`(与 profile 同生命周期)。
- [ ] ⋮ 菜单挂「本机文件搜索」(挂点见 P3h);未开启→确认气泡(告知只存元数据/约需时长)→`findex_build` 放 worker 线程 + UI 进度条轮询;已开启→直达 chrome://findex 页(复用 `_FINDEX_PAGE`,fetch 换本体 IPC)。
- 验收: ⋮ 菜单开/关索引,chrome://findex 可搜,默认不扫盘。

### P3g NTP 智能体 WebUI(chrome://agent,M3/M4)
- [ ] 自建独立 host(chrome://agent,M4 定名),照 `AddWebUIConfig` 模式注册,三件套 UIConfig+WebUIController+MojoHandler+.mojom(参照 `new_tab_page/`)。
- [ ] 挂接 agent 操作层 M3 三层(白名单 registry/router/audit 纯 JS 直搬;原生 AgentRuntime 接 P3b)。
- 验收: 新 tab 进 chrome://agent,一次对话调通(原生存储 + 白名单动作 + A0/A1/A2 授权门)。

### P3h ⋮ 菜单契约(#69,统一挂点)
- [ ] 在 `app_menu`/`tools_menu` model 统一加各功能项: 本机文件搜索(findex)/ 密信 / 内容柜 / 论坛 / 智能体 等,各跳对应 WebUI。
- [ ] 每项遵循「未开启显示引导、已开启直达」模式(findex 已有范式)。
- 验收: ⋮ 菜单列出全部 Prisir 功能项,点击各达对应页。

### P3i 品牌层
- [ ] 图标: `assets/prisir-logo-{16,32,48,128,256}.png` + `prisir-logo.ico`(母标 AI版metal-v2,中心方裁)打进安装包/各 WebUI favicon。
- [ ] 配置页力度(已拍板): **A 类全删**(Google账号/sync/Google服务/主题/Google默认搜索)+ **B 类默认隐私向**(遥测/预加载/安全浏览/广告隐私全关)+ **C 类新增 Prisir 三块**(智能体/密信/内容柜 + Token中转站)。
- [ ] 去除 Chromium 自带「自定义 Chromium/主题」模块(§6.1 已有项)。
- 验收: 配置页无 Google 痕迹,三块 Prisir 区可见,图标全套生效。

---

## 6. P4 — 出包前检查清单(逐项,不通过不出包)

照 `prisir-browser-compile-architecture-2026-08-20.md §6.1` 逐项核对:
- [ ] 去除浏览器自带「自定义主题/自定义 Chromium」模块,新 tab 底部只有自家 footer。
- [ ] manifest 不再引用任何 127.0.0.1 / localhost。
- [ ] 搜索提供方: 设置页可配 Parallel/EXA/Tavily,测试按钮走真实 /search。
- [ ] 凭据纪律: 所有 key 存 storage.local/os_crypt、不回显明文、不进模型上下文、不落审计明文。
- [ ] 论坛跨端身份一致性(§6.1 四项验收 a-d)。
- [ ] **发布前 VT 自检(防误报)**: 本批每个将分发的可执行产物(installer/exe/各 dll: prisir_ime/prisir_findex/壳)逐个走探囊查毒闭环: SHA256 → 查 VT;无记录经用户显式同意上传分析。**0 引擎报毒才放行**,≥1 报毒停发排查(是否误用敏感 API/加壳),确认误报走厂商申诉,绝不带病出包。实测锚点(2026-08-22): 无签名 `prisir_findex.dll` VT 75 引擎 0 报毒。

## 7. P5 — 收尾(外部执行,防自杀)

- [ ] 产物(chrome.exe/mini_installer.exe/setup.exe + 各 dll)拷回本地**持久位**(非 `D:/Temp`,会被清)。
- [ ] **外部**对实例做新镜像(固化本期成果为下一编译基),再 `DeleteInstance` 释放(铁律:不养常驻贵实例)。
- [ ] 结算实际时薪,记进交接。
- [ ] 更新 `prisIr-browser/ARCHITECTURE.md` + 本施工单各项勾选状态。

---

## 8. 风险与对策速查

| 风险 | 阶段 | 对策 |
|---|---|---|
| 编译链不通 | P1 | 停,排查工具链/SDK/env;不带 broken 链进后续 |
| libsimplex FFI 失败 | P2 | 密信 2人私信降级 Web/壳版,群聊+后量子照做,其余不受影响 |
| os_crypt 非交互降级 | P3b | 已知:非交互会话 DPAPI 降级(release 只记 ERROR 不崩),真实用户会话正常,符合预期 |
| 脚本自杀 | P5 | 实例级 stop/snapshot/release 全部外部执行或 schtasks 分离 |
| 实例忘释放烧钱 | P5 | 施工单最后一项硬卡;P5 完成前不算完 |
| VT 误报 | P4 | 0 报毒才放行;误报先排查再走申诉,不带病出包 |

## 8.1 海外低价实例可行性评估(2026-08-22 实测 DescribePrice,含 Win2022 license + 400GB ESSD)

**结论:不建议换,HK 继续用。** 实测各 region c8i/c9i/c7/g7.8xlarge(32v64G)时薪:HK c8i ¥18.58 / c7 ¥18.59 / c9i ¥20.04 / g7 ¥20.73;海外最低 ap-southeast-8(雅加达)c9i ¥16.88 / us-east-1 c7 ¥17.08 / us-west-1 c7 ¥17.19 / ap-southeast-6(吉隆坡)c7 ¥16.10——**最多省 ~¥2.5/h(13%)**。

但三个劝退点远大于省的钱:
1. **镜像复制费**: 自定义镜像 `m-j6cgwhn89zx36bc1tp8j` 是 cn-hongkong region 本地资源,换 region 需 `CopyImage` 400GB 跨地域快照,跨域流量费 + 数小时复制 + 目标 region 快照长期存储费,一次就把时薪差额全吃回去还多。
2. **拉代码网络**: HK 物理离 chromium.googlesource.com 出口最近、链路最熟(3 个 GN 补丁+编译链全在 HK 验证过);换美西/欧洲拉 Google 源反而跨太平洋更慢,编译时长拉长抵掉时薪差。
3. **新 SG/vSwitch/VPC 要在目标 region 重配**(sg-j6c5xtnlr1v54naric40 / vsw-j6chjrio5ijum3ynw1hxl 都是 HK 资源),又是一轮配置面。

**触发重估的条件**: 单批编译时长 > ~30h(时薪差才累计到值得),或 HK c8i 缺货/涨价,或镜像已在某海外 region 有副本。否则维持 HK c8i.8xlarge PostPaid ¥18.58/h。

---

## 9. 本单与既有契约的关系

本单是**总施工顺序**,不重复各模块细节;每个 P3 项的技术细节看对应契约文档(findex/network-link/forum 协议等),本单只负责「什么时候做、依赖谁、验收什么」。拍板「全部做完一次编译」的范围=本单 P0–P5 全部。
