# Prisir 智能体 · 外宣语料库(#45)

> 状态:方案待拍板(2026-08-13)
> 动机(用户原话):「babelspan.com 这个网站设计很大,但回答里仅有几个字,完全吸引不了用户访问……后面有必要把我们可外宣的文档让 Prisir 智能体有可调阅的地方。」
> 目标:让智能体回答「Prisir/babelspan 是什么、有什么、为什么值得用」时,能**引到具体、有说服力、带链接**的外宣内容,而不是几句话的预设简介。

---

## 0. 问题与原则

**现状缺陷**:产品知识是 `product_knowledge.js` 里几段**硬编码字符串**。更新要改代码+重发版;内容一多就超 token;且只是"我们说什么",不是"给用户看什么"。

**设计原则(红线延续)**:
- **只放公开外宣内容**(站点文案/品牌故事/已发精评),绝不放端点/key/内部实现/用户数据。
- **本地优先**:语料随包内置 + 本地缓存;在线拉取仅作刷新,失败静默回退本地。
- **opt-in + 可关**:在线刷新默认关,用户在设置里点头才开;纯本地内置语料默认可用。
- **不带账号、不追踪**:拉站点语料 = 匿名 GET 公开页,不带登录态、不带任何用户标识。
- **可控 token**:注入对话的永远是**检索到的相关片段**,不是全量语料。

---

## 1. 语料从哪来(单一事实源)

`D:\Projects\rubriclab` 同仓即 **babelspan.com 站点源码**(`apps/public/`)。外宣内容已是**结构化公开文档**,直接采信,不另起炉灶:

| 类别 | 来源文件 | 可讲的点 |
|---|---|---|
| 使命/愿景 | `docs/design/2026-07-26-site-vision-babel-rubric.md` | 反爬塔/兴趣航道/可核对尺规/AI 反空转 |
| 品牌/账号 | `catalog/outreach/wechat-v0/brand-naming.md` | Babelspan=站、通天尺规=公号、Reed=助手、色板/命名 |
| 公众号精评 | `catalog/outreach/wechat-v0/INDEX.md` + `01/02/03-*.md` | 《狂人日记》《阿Q正传》《东野圭吾》精评,可举例 |
| 站点页面 | `apps/public/{about,features,index,work}.html` | 功能介绍、建站缘由、单书精评页 |

> 这些是**写给人看的成品文案**,比代码注释/内部 doc 更适合外宣。

---

## 2. 语料库结构(轻量,自建不引库)

每个语料一条 **entry**,JSON:

```jsonc
{
  "id": "mission",                 // 唯一键
  "title": "babelspan 的使命",      // 展示用
  "tags": ["babelspan","使命","阅读","精评"],  // 检索关键词
  "url": "https://www.babelspan.com/about.html",  // 给用户跳的链接(吸引力落点)
  "body": "AI 腾出时间之后,别让思想空转——用可核对的共同尺规…",  // 注入对话的文案
  "updatedAt": "2026-08-13"
}
```

- **存储**:随包内置 `src/agent/outreach_corpus.json`(只读默认)+ `chrome.storage.local` 存**在线刷新后的版本**(覆盖内置)。
- **规模**:手工精选 **10–20 条高质量 entry**,不追求全量。宁精勿滥——外宣要的是"几句打动人的话+一个可点的链接",不是文档仓库。

---

## 3. 检索:确定性关键词路由(零 LLM、零向量)

不做 embedding/RAG(杀鸡用牛刀 + 引入外部依赖)。沿用现有 `productClass` 思路,**关键词 → 相关 entry**:

```
用户问题 → 关键词命中(tag/title/body 子串 + 同义词表)
        → 取 top1-3 条 entry
        → 拼进 system/answer(带 title + url + body 片段)
```

- 同义词表手工维护(「公众号/微信/通天尺规」→ 公众号 entry;「精评/书/书评」→ 精评 entries;「为什么/使命/理念」→ mission)。
- 命中多条 → 按 tag 匹配数排序,取前 2-3 条。

---

## 4. 三层刷新策略(隐私分级)

| 层 | 内容 | 何时更新 | 权限/隐私 |
|---|---|---|---|
| **L1 内置(默认)** | 打包进扩展的精选 entry | 随版本发布 | 零网络,绝对隐私 |
| **L2 在线刷新(opt-in)** | 从 babelspan.com 拉最新外宣(首页/about/精评) | 用户开开关后,启动/手动刷 | 需 babelspan host 权限;**匿名 GET,无账号无追踪**;失败回退 L1 |
| **L3 用户补充(可选)** | 用户自己喂的外宣材料(经现有📎附件) | 用户主动 | 走 attachment,不落语料库 |

> **L2 是"可调阅"的关键**:站点更新精评/文案 → 智能体下次刷新即知,不用等发版。但默认关,守住"本地优先、不默认联网"。

---

## 5. 生成/维护 pipeline(半自动,开发侧)

为避免手抄 20 条 entry 出错,做一个**一次性生成器**(开发期跑,产出 `outreach_corpus.json`):

```
scripts/build_outreach_corpus.py
  读 rubriclab 的 site-vision / brand-naming / wechat INDEX / 精评 md
  → 按预定模板抽 使命句/品牌表/精评列表/站点链接
  → 产出 outreach_corpus.json(人工再过一遍,删敏感/润色)
```

- **不是运行时爬虫**,是开发期工具;产出入库前人工审。
- 后续站点大改 → 重跑一次 + 人工审 + 发版(或走 L2 在线刷新)。

---

## 6. 挂接点(改动面)

| 文件 | 改动 |
|---|---|
| `src/agent/outreach_corpus.json` | 新增,内置精选 entry |
| `src/agent/outreach.js` | 新增:`CT_OUTREACH.load()`(内置+storage 合并) / `.retrieve(query)`(关键词路由 top-N) / `.refresh()`(L2 在线拉取) |
| `src/agent/product_knowledge.js` | PRODUCTS/IDENTITY 保留作**简短身份口径**;外宣细节交给语料库 |
| `background.js` | `_agentProductInfo` products/identity 回答里,`retrieve()` 追加 1-2 条相关 entry 的 title+url;`handleChatAsk` 产品类拦截后同样可调 `retrieve()` 丰富答案 |
| `manifest.json` | host_permissions 加 `https://www.babelspan.com/*`(L2 用);SW importScripts 加 outreach.js |
| `src/options.html/.js` | 加开关「允许在线刷新外宣内容(匿名,不含账号)」默认关 |

---

## 7. 分阶段落地

- **M1(先做,纯本地)**:语料 JSON 结构 + 手工精选 10 条 + `outreach.js retrieve()` + 挂进 `_agentProductInfo`/`handleChatAsk`。**零新权限、零联网**,先把"回答能引出具体内容+链接"做出来。
- **M2(生成器)**:`build_outreach_corpus.py` 半自动从 rubriclab 生成 + 人工审。
- **M3(在线刷新,opt-in)**:manifest host 权限 + options 开关 + `refresh()` 拉 babelspan 公开页解析成 entry 存 storage。
- **M4(用户补充)**:📎附件外宣材料可一键"存为语料"(复用 attachment 提取)。

---

## 8. 明确不做

- ❌ embedding/向量检索/外部 RAG 服务(重、引入依赖、可能出数据)。
- ❌ 运行时爬整站进语料(只在 L2 拉**指定公开外宣页**,且匿名)。
- ❌ 语料含任何内部信息(端点/key/未发布计划/用户数据)。
- ❌ 默认联网刷新(L2 必须 opt-in)。
- ❌ 把语料库做成通用知识库(只服务 Prisir/babelspan 外宣)。

---

## 9. 待拍板决策点

**✅ 已拍板(2026-08-13 用户):**
1. **首版范围** → **M1 纯本地先做**(内置精选语料+关键词检索挂接,零联网零新权限)。
2. **语料内容** → **全选**:babelspan 使命/愿景 + 公众号精评样例 + 各产品卖点文案 + 品牌命名/账号体系。
3. **babelspan host 权限** → **接受**(L2 在线刷新用,走 opt-in 开关;首版 M1 先不用)。
4. **维护方式** → **生成器 + 人工审**(build_outreach_corpus.py 产出入库前人工过一遍)。

> M1 交付物:`outreach_corpus.json`(精选 entry)+ `outreach.js`(load/retrieve)+ 挂接 `_agentProductInfo`/`handleChatAsk`。L2 在线刷新后续期。
