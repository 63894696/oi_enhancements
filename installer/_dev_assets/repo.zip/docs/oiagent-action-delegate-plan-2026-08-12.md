# OIagent 代行调用(Action Delegate)方案 — 2026-08-12

> 对标 Perplexity Comet "Computer" 的教训:它的 web agent 因间接 prompt injection 泄露本地文件(Zenity PerplexedComet,2026-01/02 两次补丁),根因是「agent 通用 + 无白名单 + 页面内容与用户指令同级可信」。
> 我们的代行调用走相反路线:**封闭白名单 + 参数 schema 校验 + 页面内容永不可触发动作 + 分级确认门槛 + 凭证不过 LLM**。

## 0. 三条不可逾越的红线

1. **动作只能由用户在 NTP 对话框的输入触发**。网页正文、翻译内容、搜索结果、群聊消息——一律是「数据」,永不进入意图识别链路。LLM 只能*提议*动作,执行前必须过确认门槛。
2. **凭证(私钥/口令/TOTP 种子)永不进入 LLM 上下文**。模型最多看到「钱包已解锁,地址 0x1234…abcd」这种脱敏状态;签名/解密由本地代码在确认后执行。与现有红线一致:chrome.storage.local 本地优先、不上传。
3. **白名单之外无动作**。模型输出只能是「从注册表里选一个 action + 填 schema 定义的参数」,不能发明动作、不能拼 shell/JS 执行。没有 eval,没有任意代码路径。
4. **代理钱包与用户钱包物理隔离**。agent 操作的是用户**专门给它**的一个独立钱包(§5),不是用户的主钱包。agent 永远拿不到、也不该拿到用户主钱包的任何凭证。

## 1. 架构总览

```
NTP 输入框(用户键入)
   │
   ▼
SW: intent 路由器 (src/agent/router.js)
   ├─ 快路径: 斜杠命令 /chip(/翻译 /海报 /书签 …) — 零 LLM,直接命中
   └─ 慢路径: chatText 分类 → 严格 JSON {action, params}
        ├─ action ∉ 注册表 → 退回普通问答(不是错误)
        └─ action ∈ 注册表 → schema 校验 params(ajv 风格手写,防注入字段)
   ▼
确认门槛(按 action.risk 分级,见 §3)
   ▼
执行器(handler,复用现有原语:翻译管道/海报/书签/securedm/钱包适配器)
   ▼
NTP 结果卡:动作摘要 + 结果 + (可逆时)撤销按钮 + 审计条目
```

关键:**intent 分类是独立的一次小调用**(maxTokens ~200,JSON mode),与问答管道分离。分类失败/置信低 = 普通问答,不会误执行。

## 2. Action 注册表(白名单)

每个动作一个条目,集中定义在 `src/agent/registry.js`,SW 启动时装载:

```js
{
  id: 'translate_page',            // 唯一 id,模型只能引用 id
  name: '整页翻译',                 // i18n key
  risk: 'L0',                      // 风险级 → 决定确认门槛
  params: {                        // JSON schema(手写校验,不引库)
    tab: { type: 'string', enum: ['current'], default: 'current' },
    target: { type: 'string', pattern: '^[a-z]{2}(-[A-Z]{2})?$', default: 'auto' },
  },
  handler: 'handleAgentTranslate', // background 里已注册的消息处理器名
  confirm: { style: 'none' },      // none | inline | dialog | secure
  undo: 'translate_restore',       // 可逆动作的撤销 handler(可选)
}
```

### 首批动作清单(按风险级)

| id | 干什么 | 风险 | 确认 | 复用 |
|---|---|---|---|---|
| `translate_page` | 当前页整页翻译/恢复原文 | L0 | 无(结果卡给「恢复原文」) | 现有 content.js 翻译管道 |
| `poster_search` | 给当前页/查询配海报图 | L0 | 无 | baiduImageCandidates/ddgImageCandidates |
| `bookmark_preview` | 书签分类**预演**(只读,输出移动计划) | L0 | 无 | 书签读取 |
| `bookmark_apply` | 执行上一步的移动计划 | L1 | inline 卡(列出将移动 N 条) | chrome.bookmarks.move |
| `chatroom_post` | 向群聊房间发一条消息(内容回显) | L2 | inline 卡(全文回显+发送按钮) | chatroom_client/relay |
| `chatroom_moderate` | 置顶/删除/禁言(主持操作) | L2 | inline 卡(目标+原因回显) | chatroom 管理 API |
| `securedm_send` | 与指定目标建立加密会话并发消息 | L2 | inline 卡(收件人指纹+全文) | securedm_web |
| `wallet_receive` | 出示收款地址/付款请求(带 memo,只读) | 免确认(新手)/L1(熟手) | 直接给 | Electrum `add_request` |
| `wallet_transfer` | 付款(强制 memo 备注 + 支付前告知) | **L3** | **secure 对话框** | Electrum `payto` |
| `wallet_fund_guide` | 新手入金引导:解释法币→币→提币 + 只读给收款地址 + 查账 | 免确认(只读) | 直接给(解释+地址) | Electrum `getbalance`/`listaddresses` |

新增动作 = 改注册表 + 写 handler,**路由/确认/审计代码零改动**。

## 3. 确认门槛(四级)

| 级 | 含义 | UI | 例子 |
|---|---|---|---|
| **L0** | 只读或一键可逆 | 直接执行,结果卡附撤销 | 整页翻译、海报、分类预演 |
| **L1** | 本地批量改动,可逆但麻烦 | 聊天气泡内确认卡:动作摘要+影响数量+「确认/取消」 | 书签批量移动 |
| **L2** | 对外可见/不可撤回 | 确认卡**全文回显**将发出的内容+目标,必须点「发送」;无任何默认焦点在确认键 | 群聊发言、加密消息 |
| **L3** | 付款(资金离手) | **独立模态对话框**(不是聊天气泡):结构化渲染金额/币种/收款地址(全量,首末高亮)/手续费/**备注**,全部来自结构化数据而非 LLM 文本;需输入钱包解锁口令(或会话解锁在时效内);超时 60s 自动取消 | `wallet_transfer` |

通用规则:
- 确认卡在 NTP 内渲染,但确认按钮的点击事件**直接绑定执行**,不再过模型。
- 所有 L1+ 确认都有超时(L1/L2 120s,L3 60s),超时视为取消。
- 连续相同动作不「记住选择」——每次都确认(防惯性点击)。唯一例外:L0 本来就不要确认。

## 4. 自然语言触发细节(「agent 能便利操作」= 双通道,不依赖手动点 chip)

- **快路径(零 LLM)**:`/翻译`、`/海报 xxx`、`/书签`、`/付款 0.01 给 bc1q…` 之类前缀,正则直接命中,零延迟零 token。
- **慢路径(LLM 分类)**:用户自由输入 → intent 分类(prompt 列注册表 id+一句话描述+参数 schema,要求输出 `{"action":"...","params":{...}}` 或 `{"action":null}`)。
- **入口设计原则**:入口对 agent 透明——agent 不需要用户先点某个按钮,只要输入文本就能触发。「深入研」那种 chip 是「模式开关」,代行**不用 chip**,因为代行是「按指令做单次动作」而非「进入一个模式」。斜杠给熟手,自然语言给所有人。
- **参数消毒**:schema 之外的字段丢弃;字符串参数长度上限;enum/pattern 强制;`tab` 类参数只允许 `current`(初期不让 agent 选别的 tab)。
- **歧义不问模型,问用户**:分类置信不足或参数缺失 → NTP 弹一个「你想让我:①整页翻译 ②配海报 ③都不是」的选择卡,而不是让模型瞎猜。
- **上下文**:代行动作不进 threadCtx 的问答语义(避免「上文提到转账」被后续问答误触发);只进审计日志。

## 5. 钱包(L3)专项 —— 双模式:熟手「代理钱包隔离」 / 新手「授权托管」

用户分两群,方案对两群分别设计,**同一个底层适配器**(§5.0)支撑:

| | 熟手(懂加密货币) | 新手(不懂、嫌麻烦) |
|---|---|---|
| 钱包归属 | 用户**专门给 agent 的一个钱包** | 用户**自己的钱包**,授权 agent 操作 |
| 凭证 | 代理钱包凭证进扩展;主钱包凭证从不进系统 | 用户钱包凭证在授权后进扩展 |
| 风险敞口 | 仅代理钱包余额 | 用户钱包(靠 §5.5 护栏收口) |
| 入金 | 用户自己充值,不用管 | **这是最大门槛**,见 §5.6 入金引导 |
| 支付前 | L3 确认 | L3 确认 + **强制备注** + 告知 |
| 收款 | L1 只读 | **完全不用确认**(只读),更宽松 |

> 你的决策:默认对新手走「授权托管」,因为这部分用户恰恰不会自己搞定代理钱包和入金。隔离模式保留给熟手。两模式共用确认/审计/适配器,只是凭证来源与护栏松紧不同。

### 5.0 链选型:BTC + Electrum,以「能接 Electrum CLI/JSON-RPC」为硬前提

已查证 [Electrum JSON-RPC 文档](https://electrum.readthedocs.io/en/latest/jsonrpc.html),**Electrum 原生就是可脚本化的**——这正好满足你「不管用哪种都要能接运营方 cli 为前提」:

- 守护进程:`electrum daemon -w /path/to/wallet` 启动,`setconfig rpcport 7777` 固定端口(否则随机端口)。
- 认证:HTTP Basic Auth(`rpcuser` / `rpcpassword`,首次启动自动生成随机密码)。**仅限 127.0.0.1 本地回环**,因为 basic auth 明文,绝不可跨网络。
- 关键方法:`getbalance`、`listaddresses`(可按 funded 过滤)、`add_request`(收款,**原生支持 `memo` 备注字段**)、构造/广播用 `payto`(CLI)对应 RPC。
- 完全 headless,curl/任何 HTTP 客户端都能驱动——意味着我们的 handler 不需要 Electrum GUI,纯后台进程。

**架构含义**:钱包 handler 不自己实现加密/签名,而是**驱动一个本地 Electrum daemon**(它是「运营方 cli」)。好处:① 加密、签名、助记词管理全部交给 Electrum 这个经过实战的成熟实现,我们不重造轮子;② 用户可用 Electrum GUI 独立查看同一个钱包,透明可审计;③ 天然满足「新建干净环境」——专用 wallet 文件 + 独立口令。

### 5.0.1 安装形态:①′ 整合包内 Prisir 工坊(PrisirWork) 托管 Electrum daemon,扩展经本地 HTTP 调用

**已定(取代原 ①/② 之争)**:用户装了我们的**智能整合包**,本地常驻 **Prisir 工坊(PrisirWork)**(oiagent-coworker 的本地组件)。新手也能走这条,因为 Prisir 工坊(PrisirWork) 吃掉了「自己装 Electrum + 自己起 daemon」的全部门槛:

```
NTP 输入(用户键入「付款 0.01 给 bc1q…」)
  → SW intent 路由 → wallet_transfer(L3)
  → 扩展 fetch http://127.0.0.1:<Prisir 工坊(PrisirWork)端口>/wallet/payto   (本地 HTTP,白名单 endpoint)
  → Prisir 工坊(PrisirWork) 起/连 Electrum daemon(electrum daemon -w …)→ 走 JSON-RPC
  → Electrum 构造 tx → 返回扩展 → L3 对话框(所见即所签)
  → 用户输独立口令 → Prisir 工坊(PrisirWork) 让 Electrum 签名+广播
```

新手全程不碰命令行、不装 Electrum、不见助记词——Prisir 工坊(PrisirWork) 把「运营方 cli」管起来了。为什么比 native messaging 更适合整合包:

- **不装 native messaging host**:那要写注册表清单 + 绑浏览器 + 配扩展 id,「一键装」场景里很脆;Prisir 工坊(PrisirWork) 本地 HTTP 天然没这些。
- **进程归我们管**:Electrum daemon 的启动、崩溃重启、wallet 路径、rpcport 固定,全由 Prisir 工坊(PrisirWork) 统一管。
- **凭证边界更清**:扩展(MV3,Chrome 沙箱内)**只持有 Prisir 工坊(PrisirWork) 的本地 endpoint + 一次性 token**,助记词/私钥/Electrum 的 rpcpassword 全在 Prisir 工坊(PrisirWork) + Electrum 侧——比「扩展直连 Electrum RPC」还少一层暴露。

### 5.0.2 Prisir 工坊(PrisirWork) 本地安全红线(三条,必须守住)

1. **只监听 127.0.0.1 + 本地一次性 token**:Prisir 工坊(PrisirWork) 的每个敏感 endpoint 都要带 token(整合包安装时随机生成,存 chrome.storage.local,与凭证同红线不上传)。否则本机任何网页/进程都能打这个端口转钱——这是把「本地端口」变成「仅本扩展可调」的关键。
2. **口令不过 Prisir 工坊(PrisirWork) 持久化**:解锁口令只在签名那一刻从扩展传给 Prisir 工坊(PrisirWork),Prisir 工坊(PrisirWork) 转交 Electrum 后即弃,**不落盘、不入日志**。
3. **Prisir 工坊(PrisirWork) 的 wallet endpoint 同样走 action 白名单**:只暴露 `payto / getbalance / listaddresses / add_request` 这几个,**不开放 Electrum 全量 RPC**;其余方法在 Prisir 工坊(PrisirWork) 侧即拒。

### 5.1 凭证与存储(两模式通用)

- 助记词/私钥由 Electrum 管理(新建干净钱包文件),daemon 由 Prisir 工坊(PrisirWork) 托管。扩展**不碰私钥、也不碰 Electrum 的 rpcuser/rpcpassword**——只持有 Prisir 工坊(PrisirWork) 的本地 endpoint + 一次性 token(见 §5.0.2)。
- 钱包解锁口令独立(你的决策),与 securedm A2 的口令体系分开,为干净;口令只在签名瞬间经 Prisir 工坊(PrisirWork) 转交 Electrum,不落盘。
- 模型上下文里只有脱敏状态:`{unlocked, address: "bc1q…xyz", balance, mode: "isolated"|"custodial"}`。凭证永不进 prompt。

### 5.2 意图来源硬校验

钱包动作只接受「用户在 NTP 输入框键入 + L3 对话框内确认」双信号。任何来自页面/消息/搜索结果的「转账」字样,连 intent 分类都不进(分类器对 wallet_* 动作要求 trigger_source === 'ntp_input')。

### 5.3 交易构造与备注(新手模式强制)

- **模板化**:走 Electrum `payto` 模板,金额/地址全是结构化字段。
- **支付前必告知 + 强制备注**:每笔支付构造时强制写 `memo`(Electrum `add_request`/payto 原生支持),内容 = 用户原始意图的一句话摘要(如「购买 XX 服务」)。L3 对话框里金额/地址/手续费/**备注**全部结构化渲染,所见即所签。
- **新地址二次确认**:首次向某地址付款,额外一步「这是新地址,确认无误?」。

### 5.4 收款(两模式都宽松)

- 出示收款地址/付款请求(`add_request`)是**只读**,新手模式下连 L1 确认都不要——直接给。
- 收款天然带 `memo`,方便对账。

### 5.5 护栏(新手托管模式必须更严)

| 护栏 | 熟手隔离模式 | 新手托管模式 |
|---|---|---|
| 单笔上限 | 代理余额 20% | **更低**(如 10% 或固定等值上限) |
| 每日累计上限 | 代理余额 50% | **更低**(如 25%) |
| 会话解锁时效 | 10 分钟 | **更短**(如 5 分钟) |
| 新地址 | 二次确认 | 二次确认 + 冷静期(可选) |
| 收款 | L1 | 免确认(只读) |

因为托管模式的风险敞口是用户整个钱包,护栏必须比隔离模式明显更紧。

### 5.6 新手入金引导(「怎么换到币 / 不会转币」是最大门槛)

这是新手模式能不能用的真正瓶颈——用户连「法币怎么变成 BTC」都不会。代行的职责在这里**不是替他买币**(那涉及交易所 KYC、支付通道,远超 agent 能力边界,也有合规风险),而是**「手把手引导 + 只读辅助」**:

1. **解释,不代操作**:用问答管道解释「法币 → 交易所 → 提币到钱包」的完整链路,给合规交易所的官方链接(带引用)。
2. **只读生成收款地址**:用户在交易所提币时,agent 给出**他自己钱包**的收款地址和 memo,让他复制到交易所提币页面。这一步 agent 只出不进的地址,零风险。
3. **到账确认**:用户说「我提了」,agent 调 `getbalance`/`listaddresses` 查账,确认到账后告知。
4. **红线**:agent **绝不**替用户登录交易所、绝不碰法币支付、绝不代收代付法币。入金永远是用户自己在交易所完成,agent 只做解释和给地址。

这条线把「教用户入金」和「替用户入金」划清——前者是代行能做的,后者越界。

## 6. 审计日志(本地优先)

- 每次代行执行(含被取消的)写一条:`{ts, action, params(脱敏), result, confirmed_by: 'user', duration_ms}` 存 chrome.storage.local,环形保留最近 500 条。
- NTP 设置页加「代行记录」只读视图;**永不上传**(与收藏/书柜同红线)。
- L3 条目额外记录 tx hash,不记录任何 key 材料。

## 7. 反 prompt-injection 清单(对照 PerplexedComet 逐条设防)

| Zenity 披露的攻击手法 | 我们的对策 |
|---|---|
| 页面/日历邀请里藏指令,agent 当用户意图执行 | 页面内容不进 intent 链路;intent 分类器输入**只有** NTP 输入框文本 |
| 伪装语言/游戏化绕过护栏 | 不依赖模型自觉:动作集合是代码层白名单,模型输出只能选 id |
| `file://` 导航读本地文件 | 无 navigate 类动作;fetch-text 白名单已有(仅 youtube timedtext),继续收紧 |
| 数据经普通导航外泄 | 无自由 URL 导航动作;所有外发请求走既有固定 endpoint |
| 密码管理器解锁后被搜刮 | 我们的凭证不存密码管理器;L3 确认要口令,agent 无法自问自答 |
| 确认流于形式(默认焦点在确认) | L2/L3 确认按钮无默认焦点、需主动点击;L3 需输口令 |

## 8. 分期实施

- **M7a(骨架 + L0/L1)**:registry + router + 确认卡组件 + 审计日志;动作:`translate_page` / `poster_search` / `bookmark_preview` / `bookmark_apply`。E2E:自然语言「把这页翻译成英文」→ 当前页翻译成功;「整理书签」→ 预演卡 → 确认 → 移动 + 可撤销。
- **M7b(L2 对外动作)**:`chatroom_post` / `chatroom_moderate` / `securedm_send`(复用 chatroom 与 securedm 现有模块,先各支持一个最小路径)。
- **M7c(钱包,双模式 + Electrum-cli)**:见 §5。E2E 用 Electrum testnet/regtest,严禁一上来碰主网真钱。

## 9. 开放点收口(全部已定)

1. ~~接哪条链~~ → **已定:BTC(Electrum),前提是能接 Electrum 的 CLI/JSON-RPC**(见 §5.0 查证)。
2. ~~口令~~ → **已定:钱包独立口令,新建干净环境**。
3. ~~入口形态~~ → **已定:斜杠快路径 + LLM 慢路径双通道,不用 chip**(见 §4)。
4. ~~钱包安装形态~~ → **已定:①′ 整合包内 Prisir 工坊(PrisirWork) 托管 Electrum daemon,扩展经本地 HTTP 调用 + 一次性 token**(见 §5.0.1/§5.0.2),新手零命令行。
5. M7a(骨架+L0/L1)**可开工**——不依赖钱包,先行。
