# Prisir Findex 本体集成契约 — 本机文件搜索(类 Everything,自建索引)

日期: 2026-08-21 · 任务: #79 · 类型: 编译期契约(不本次编译,随 #59/#66 编译批次走)
**性质**: 本机文件搜索引擎的**浏览器本体集成契约**。Rust cdylib `prisir_findex.dll` 已编译产出并 E2E 验证;本文档定义它如何被 Chromium 本体加载、⋮ 菜单如何挂「本机文件搜索」、本体如何调 cdylib。**本次只交付契约,不做实际 C++ 集成**。

## 一、背景(为什么做)

用户用浏览器必然搜集大量资料,散落在硬盘各处。跟智能体对话谈到某个资料时常不记得地址,需要快速本机搜到并取上下文。

**关键约束(用户拍板)**:
- **目标机没有 Everything**,不能依赖外部 es.exe → 必须自建独立索引。
- **默认不扫盘** — 用户在菜单显式开启才首扫。
- 开启时告知**预计索引时长**。
- 提供**用户也能用的本地文件搜索页**(不只智能体用)。
- **编译期用 Rust cdylib**(复用输入法 prisir_ime 成功链路),不用 C++ 重写。

## 二、已交付物(本次,已 E2E 验证)

| 产物 | 路径 | 状态 |
|---|---|---|
| Rust 索引引擎 crate | `prisir_findex/`(Cargo.toml + src/{lib,index,query,ffi}.rs) | ✅ `cargo build --release` 出 `prisir_findex.dll`(1.98 MB) |
| ctypes 壳 | `prisir_findex/shell_findex.py` | ✅ 单例 + enable/enable_async/search/status/disable |
| 端到端自检 | `prisir_findex/verify.py` | ✅ 7 步全过(建库/索引/子串/mtime 倒序/清空) |
| oiagent 工具 | `oiagent_cli.py`: `local_file_search` + `read_file_head` | ✅ dispatch 接线 + 优雅降级 |
| findex API | `oiagent_web.py`: `/oiagent/api/findex/{status,enable,disable,search}` | ✅ E2E 验证 |
| 用户搜索页 | `oiagent_web.py`: `GET /oiagent/findex`(_FINDEX_PAGE,国风浅色) | ✅ 渲染 + 搜索 + 开关 + 进度条 |

**引擎设计要点**:
- **存储**: SQLite(rusqlite bundled),表 `(path,name,dir,ext,size,mtime)`,`name`/`mtime` 列索引,WAL。
- **检索**: 文件名/路径子串 `LIKE`(转义 `%`/`_` 防通配注入),按 `mtime` 倒序,毫秒级。
- **遍历**: walkdir,默认排除系统/缓存目录(`Windows`/`Program Files`/`ProgramData`/`node_modules`/`.git`/`AppData`/`$Recycle.Bin` 等,可配追加)。
- **红线**: **只存元数据,不读文件内容**;搜索只读;**默认不扫盘**,显式 `enable` 才首扫;`disable` 清空索引。

## 三、FFI 接口(cdylib 导出,本体直接调)

opaque handle + C 字符串 JSON(仿 prisir_ime)。所有返回字符串由调用方 `findex_free_string` 释放。

| 导出 | 签名 | 语义 |
|---|---|---|
| `findex_open` | `(db_path: *c_char) -> *c_void` | 开/建 SQLite 库(**不扫盘**),回 opaque handle,失败 null |
| `findex_build` | `(handle, args_json) -> *c_char` | 首扫/重建(同步,调用方放线程);args=`{"roots":[..],"exclude":[..]}`,回 `{"ok","scanned"}` |
| `findex_query` | `(handle, query, limit) -> *c_char` | 子串搜索,回 `{"ok","hits":[{path,name,dir,ext,size,mtime}]}` |
| `findex_status` | `(handle) -> *c_char` | `{"ok","enabled","indexed_count","last_scan","building","scanned"}` |
| `findex_clear` | `(handle) -> *c_char` | 清空索引(关闭功能),回 `{"ok"}` |
| `findex_free` | `(handle)` | 释放 handle |
| `findex_free_string` | `(s: *c_char)` | 释放返回字符串 |

**多线程**: 引擎内部 `Mutex<Connection>` + 原子进度计数,`build` 与 `query`/`status` 可并发(首扫进行中可搜已索引部分)。`build` 重入返 `{"ok":false,"error":"already_building"}`。

## 四、本体集成方案(编译期实现,本次不做)

### A. 加载方式
- `prisir_findex.dll` 随包落地(仿 sing-box 随包二进制,#59 §三.B 先例),本体 `base::LoadNativeLibrary` 或延迟 `LoadLibrary` 加载。
- 封装一个 `PrisirFindex` C++ 薄壳(`components/prisir_findex/`),`GetProcAddress` 解析上表 7 个导出,包装成同步/回调接口。
- 索引库落用户数据目录(`user_data_dir/findex/findex.db`),与浏览器 profile 同生命周期。

### B. ⋮ 菜单挂「本机文件搜索」
- 沿用 #69 ⋮菜单编译期契约的挂点(`app_menu` / `tools_menu` model 加 item)。
- **未开启**: 菜单项显示「本机文件搜索(开启建索引)」,点击 → 确认气泡「将扫描本机磁盘建文件名索引,只存路径/名称/大小/时间,不读内容。大型硬盘约需 X 分钟」→ 用户确认 → 调 `findex_build`(放 worker 线程,UI 进度条轮询 `findex_status` 的 `scanned`)。
- **已开启**: 菜单项直达搜索页(新开 tab 渲染 §五 页)。

### C. 智能体调用面
- 智能体侧已走 `oiagent_cli.local_file_search`(ctypes 壳直调 dll),本体编译后改为本体 IPC 调同一 `PrisirFindex` C++ 壳,语义不变。
- 「找到后取上下文」走独立 `read_file_head`(读文件开头 N 字符,截断防爆上下文)——与索引分离,索引绝不存内容。

### D. 索引新鲜度(后续优化,不阻塞)
- 原型期: 首扫全量 + 手动/定时重扫(mtime 比对)。
- 优化项(TODO): **NTFS USN Journal 增量监听**(Everything 同源思路,Rust 调 Win32 `DeviceIoControl FSCTL_READ_USN_JOURNAL`),只在变更时增量更新,免全量重扫。本期不实现。

## 五、用户搜索页(已实现,本体复用)

用户页 `_FINDEX_PAGE`(挂 `/oiagent/findex`)国风浅色,功能:
- 搜索框 + 结果列表(图标/名称/路径/修改时间/大小)。
- 「开启本机搜索」/「关闭并清空索引」开关。
- 首扫进度条 + 已扫描文件数实时刷新(1.5s 轮询 `status`)。
- 状态行:已索引文件数 + 上次扫描时间。

本体编译时此页可作为 `chrome://findex` 或内嵌 WebUI 复用同一 HTML/JS,仅把 `/oiagent/api/findex/*` fetch 换成本体 IPC。

## 六、API 面(oiagent_web,已实现)

| 方法 | 路径 | 语义 |
|---|---|---|
| GET | `/oiagent/api/findex/status` | `{ready, enabled, indexed_count, building, scanned, last_scan}` |
| POST | `/oiagent/api/findex/enable` | body `{roots?, exclude?}`,后台首扫,回 `{started, hint}` |
| POST | `/oiagent/api/findex/disable` | 清空索引,回 `{ok}` |
| GET | `/oiagent/api/findex/search?q=&limit=` | 回 `{enabled, hits[]}`;未开启回引导 hint |
| GET | `/oiagent/findex` | 用户搜索页 HTML |

## 七、红线对齐

- **不依赖外部**: 自建索引,目标机无 Everything 也能用(es.exe 仅开发机快路径,`search_files` 保留)。
- **默认不扫盘**: 引擎加载不自动建库;显式 `enable` 才首扫;开启时显示预计时长。
- **只存元数据不存内容**;搜索只读;读内容走独立 `read_file_head`;默认排除系统目录可配。
- **复用不重复造**: 引擎复用 prisir_ime 的 Rust cdylib/ctypes/rusqlite 链路;读内容复用 `_t_read_file` 截断。

## 八、验证(本次已跑通)

1. ✅ `cargo build --release` → `prisir_findex.dll`。
2. ✅ `python prisir_findex/verify.py` → 7 步全过(建库/索引/CJK+ASCII 子串/mtime 倒序/清空)。
3. ✅ oiagent_web 起服务: POST enable(scoped root)→ status(enabled, indexed_count)→ GET search 命中 → 用户页 `/oiagent/findex` 渲染(关键 id 齐全)→ disable 清空。
4. ✅ oiagent 工具: `local_file_search` 命中 + `read_file_head` 取上下文。

**待编译批次**: 实际 Chromium C++ 集成(§四)+ USN 增量(§三.D)。
