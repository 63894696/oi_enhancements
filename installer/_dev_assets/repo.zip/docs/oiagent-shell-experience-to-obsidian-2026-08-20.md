# oiagent 壳「经验提炼存 Obsidian」立项设计

日期: 2026-08-20 · 状态: 已拍板(路线 B),待实施 · 类型: 功能增强
前置: 导出回归已修(commit 7ed8aca),Bug3 Win+D 已修(voice_input d495baa)

## 需求(用户原话)

> 导出里能否增加连接 Obsidian,导出**像我们梳理任务经验存入 Obsidian 那样的经验文档**?

关键定性:这不是「给现有 md 导出加 frontmatter」(路线 A),而是**先把对话提炼成经验
结晶,再落 vault**(路线 B) —— 参照 `team_lead_tools._save_team_experience_to_obsidian`
的做法。用户明确拍板走 B。

## 两种「导出」的本质区别

| | 现有导出(md/docx/pdf) | 本立项(经验提炼) |
|---|---|---|
| 内容 | 原始对话流水(按角色罗列) | 提炼后的知识(TL;DR+核心经验+踩坑) |
| 是否需要 LLM | 否 | **是**(提炼这一步必须过模型) |
| 落点 | 用户选的保存路径 | 固定 vault `experiences/` |
| 用途 | 归档/分享对话 | 沉淀可检索经验,喂养记忆系统 |

## 现有可复用沉淀

- **模板**: `team_lead_tools.py:705 _save_team_experience_to_obsidian` —— frontmatter
  (title/domain/date/created_at/tags/status/source_skill/related) + TL;DR + 核心经验 +
  配置信息 + 关联 + 原始事件 JSON。
- **vault 路径**: `OBSIDIAN_VAULT = C:/Users/Administrator/Documents/ObsidianVault`
  (env `OBSIDIAN_VAULT` 可覆盖),经验落 `experiences/` 子目录。
- **实际格式样例**(vault 现有经验文档):
  ```
  ---
  title: <一句话标题>
  date: YYYY-MM-DD
  project: <项目>
  tags: [经验, ...]
  status: solved
  related:
    - "[[experiences/...]]"
    - "[[Architecture/...]]"
  ---
  # 标题
  > **一句话:...**
  ## TL;DR / 核心经验 / 关联
  ```
- **命名惯例**: `YYYY-MM-DD-<slug>.md`,slug 从标题取,重名追加 `_HHMMSS`。

## 设计

### 触发方式(壳 UI)

对话页「导出」下拉加一项 **「存为经验 (Obsidian)」**。区别于 md/docx/pdf 的直接下载,
这一项走**后端提炼 + 落 vault**,前端只显示结果 toast(「已存 vault/experiences/xxx.md」)。

### 后端流程

```
POST /oiagent/api/experience  {session_id}
  1. get_messages(sid) 取完整对话
  2. 提炼 prompt → 当前选中模型(走低成本档,提炼不需要高思考):
     「把这段对话提炼成经验文档。输出 JSON:
      {title, tldr[], core[], gotchas[], tags[], project}
      title 一句话;tldr ≤3 条;core ≤8 条;gotchas 是踩坑;tags 含 经验」
  3. 解析 JSON(失败则退化为「原始对话 + 默认 frontmatter」)
  4. 套 frontmatter 模板(复用 team_lead_tools 格式)
  5. 命名 YYYY-MM-DD-<slug>.md,写 OBSIDIAN_VAULT/experiences/
  6. 返回 {ok, filepath, title}
```

### 关键决策点

1. **提炼模型**:用当前会话模型还是固定低成本档?
   建议:用当前会话模型(用户已选好,经验提炼质量和主对话一致),但 think_level
   强制 low(提炼不需要高思考,省 token)。
2. **提炼失败兜底**:LLM 返回非 JSON / 网络挂 → 退化为「默认 frontmatter + 原始对话」,
   不阻塞落盘(用户的核心诉求是**不丢**,提炼是增值)。
3. **related 双链**:自动关联什么?初版留空数组(提炼模型若给出 wikilink 则采纳,
   不强求)—— 避免编造不存在的链接。
4. **落盘前确认**:vault 写入是**本地文件操作**,非云端,不需要 A2H 门;但应在 UI
   给出明确反馈(toast 显示落盘路径),让用户知道文件去哪了。

### 红线对齐

- **默认本地**:vault 是本地目录,不触云。符合「默认本地,任何云端需用户显式」。
- **提炼走当前模型端点**:若用户配的是云端模型,对话内容会发给该端点提炼 ——
  这与主对话本身的数据流向一致(用户已在该端点对话),不新增数据暴露面。
  但 UI 可提示「提炼将使用当前模型端点」。

## 验收标准

- 在壳里点「存为经验」,vault `experiences/` 出现 `YYYY-MM-DD-<slug>.md`。
- 文档含 frontmatter(title/date/tags/status)+ TL;DR + 核心经验,格式与现有
  经验文档一致(可被 Obsidian graph/检索正常索引)。
- 提炼 LLM 失败时仍落盘(退化格式),不丢对话。
- 不回归现有 md/docx/pdf 导出。

## 工作量预估

- 后端 `_export_experience()` + API 路由 + 提炼 prompt: 1 天
- 前端导出下拉加项 + toast 反馈: 0.5 天
- 联调 + 退化路径测试: 0.5 天
- **合计约 2 天**(含 buffer)。

## 排期建议

**不挤进本轮 Bug 修复**。当前 Bug1 深挖(步骤 1 控件定位)已由用户点名进行中,
本立项排队在 Bug1 之后。若用户希望并行,可派 oiagent 开发团队(走 tasks-code
主会话认领循环)实现后端 `_export_experience`,前端壳改动留主会话。
