---
title: voice_input 三 ADR 调研闭环 — 闪电说 / TrustedARI / FastLane+GhostLine (2026-07-02)
domain: 工具链 / 自研隐私输入法 / 架构决策
date: '2026-07-02'
created_at: '2026-07-02T17:00:00'
tags:
  - voice_input
  - ADR
  - 闪电说
  - Wispr_Flow
  - SenseVoice
  - SAPI
  - TrustedARI
  - arXiv_2606.15822
  - ARI
  - SimpleX
  - Signal
  - FastLane
  - GhostLine
  - 调研闭环
  - 经验
status: 已存档
related:
  - '[[闪电说产品架构 (2026-07-02)]]'
  - '[[TrustedARI (arXiv 2606.15822, 清华 中转站可信路由协议, 2026-07-02)]]'
  - '[[SimpleX 服务端 .onion 化部署 — VPS 双地址通道实测 (2026-06-28)]]'
  - '[[SimpleX 客户端 v0.3-v0.8 全部踩坑复盘 — 30s 卡死根因与回归方案 (2026-06-30)]]'
  - '[[SimpleX libsimplex FFI 绑 Rust 实例调研 (GitHub + docs.rs, 2026-06-29)]]'
  - '[[SimpleX 群规模调研 + 客户端智能化(LLM Tool Use)架构设计 (2026-06-28)]]'
  - '[[wispr-flow]]'
source_skill: brainstorming
---

# voice_input 三 ADR 调研闭环 — 2026-07-02

> 本笔记是 2026-07-02 一轮调研的**完整闭环**。讨论起点是「Wispr Flow 是不是隐私输入法」,终点是**三份独立 ADR 文档**(基础版 / FastLane / GhostLine)+ **多个事实纠正**(TrustedARI、SimpleX 选型)。
>
> **Why:** 把这次调研沉淀成可检索的笔记,6 个月后回来看能 1 眼看到「为什么这么选」「踩过什么坑」「事实纠正了哪些错误假设」。
> **How to apply:** 后续 review 三份 ADR / 决定先动哪个仓库 / 重新讨论设计哲学时,直接看本笔记 + 跳到对应 ADR。

---

## TL;DR(三条产品线)

```
voice_input/                  ADR-001  基础版(双 daemon + orchestrator + SAPI TTS placeholder)
voice_input_fastlane/         ADR-002  快体验版 — 云端优先、自动降级、接受实名
voice_input_ghostline/        ADR-003  强隐私版 — 零外发、失败不响应、不接受实名
```

| 仓库 | 哲学 | ASR | LLM | TTS | IM |
|---|---|---|---|---|---|
| **基础版** | 中性参考实现 | 本地 SenseVoice Small | 用户配 | Windows SAPI(占位) | 用户配 |
| **FastLane** | 3 秒响应 | 火山豆包/Whisper/Qwen ASR/本地兜底 | Qwen-Max/DeepSeek-V3.2/Claude Sonnet 4.6 | Edge TTS(走云)/CosyVoice/SAPI 兜底 | 微信/钉钉/飞书/Slack |
| **GhostLine** | 零外发 | **本地 SenseVoice 强制** | **本地 Ollama(qwen2.5:7b-instruct-q4_K_M)**,NVIDIA 3GB 显存 CPU 跑 | **Windows SAPI 强制** | **SimpleX(用户已 VPS 自建 SMP+XFTP+.onion)**,Signal 备选 |

---

## 调研过程的关键事实纠正

这次调研里**有 3 个事实纠正**值得长期记住——下次讨论类似话题时,直接 reference 本笔记。

### 纠正 #1:闪电说 ≠ Wispr Flow 中文版

**误判**:我最初以为「闪电说 = Wispr Flow 中文版」——类似 Adobe 跟 Adobe 中国版的品牌策略。

**事实**(从 `shandianshuo.cn/docs` 调研 + 客户端实测):
- 官方文档**无任何「Wispr Flow」「中文版」「基于某某」声明**
- 两者都是「桌面客户端 + 流式 WebSocket ASR」同形态,**不构成同源证据**
- 闪电说有自己的产品架构(三类模型:语音识别 / 快速大模型 / 高级大模型),Wispr Flow 不知道有没有同样划分
- 闪电说 ASR 默认走本地 SenseVoice Small(用户客户端实测)+ 可换云端火山豆包 / 阿里云 qwen3-asr
- 闪电说「帮我说」(长按 Agent)走云端大模型,默认会员云端

**为什么纠正**:`shandianshuo-product-architecture-2026-07-02.md` memory 已落,避免未来讨论「闪电说 vs Wispr」时再误判同源。

### 纠正 #2:TrustedARI ≠ 清华隐私 LLM 平台

**误判**:用户最初(2026-07-02)把「清华 TrustedARI 协议」当成「清华提供的隐私 LLM 平台」,我(模型)差点就这么写到 ADR-003 G-2 路径 2。

**事实**(读了 28 页 arXiv PDF + Obsidian 调研笔记):
- **TrustedARI 是 ARI 中转站与 agent 之间的密码学协议**——MPC + 三方 TLS 握手 + 隐私查询构造 + 可验证计费(Plonk ZKP)
- **不是 LLM 平台**——清华没有 SaaS
- **未实施**:协议自承「无 GitHub / 无 IETF 草案 / arXiv preprint 阶段」
- **只解决「ARI 中转站看不看」**,**不解决「下游 LLM 上不上云」**
- 协议**未承诺**日志保留 / 删除 / GDPR / 个保法 / 数据保留期(纯技术协议,合规层未涉及)
- Threat Model = **semi-honest**;**元数据(id_s / sid / 模板 T 长度上界) ARI 看得到**
- **不防**下游服务商的 tool poisoning / indirect prompt injection(论文 §3 自承 out of scope)

**ADR-003 G-2 路径 2 修正**:
- 改名为「未来 ARI 协议级方案(TrustedARI 类,占位)」
- 状态明确写「**当前不可用**」
- 启用条件 5 条 explicit 约束(协议实施 + 数据保留 + 实名 + 审计 + 用户 consent)
- 默认空 whitelist,**POC 阶段只走 Ollama**

**为什么纠正**:`trustedari-protocol-facts-2026-07-02.md` memory 已落,避免未来讨论「隐私 LLM」「可信 AI 基础设施」「ARI」「MPC+TLS+ZKP 类协议」时再次误判协议提案为已实施产品。

### 纠正 #3:GhostLine G-4 IM 通道 — Matrix → SimpleX

**误判**:我最初写 ADR-003 G-4 时,推荐 Matrix/Element(因为支持匿名 + 可自建 homeserver)。

**事实**(读了用户 SimpleX 6/28 - 6/30 大量部署笔记):
- **SimpleX 比 Matrix 隐私更强**——SimpleX **没有用户 ID** / 没有用户账号,服务器**根本不知道谁在跟谁联系**;Matrix homeserver 知道用户列表 + 房间列表
- **用户已 VPS 自建 SimpleX** —— SMP + XFTP + Tor .onion 化部署,公网域名 + .onion 双地址通道
- **SimpleX 比 Signal 隐私更强**——Signal 服务器知道用户列表和元数据;SimpleX 不知道
- **SimpleX 资源占用比 Matrix 轻得多**——SMP+XFTP 共用 <100MB;Matrix Synapse 吃 1GB+ 内存
- **SimpleX 比 Signal 在中国大陆可用**——用户已部署公网 + .onion 双通道,VPN 断也能连;Signal 被墙
- **用户已踩过 SimpleX 客户端 v0.3-v0.8 的所有坑**——WS/FFI/ConPTY 三路全失败,**最终 v0.8 退回 `simplex-chat -e "cmd" -t N` 单次模式**——这条 GhostLine IM daemon 集成要直接用

**ADR-003 G-4 / G-6 / G-8 / §5.5 全部对齐 SimpleX**:
- G-4 改 SimpleX 主推,Signal 备选,完全删掉 Matrix(虽然 Matrix 也匿名,但 SimpleX 完胜)
- G-6 网络白名单加 SimpleX SMP / XFTP endpoints(用户 VPS `192.220.14.165`)
- G-8 SimpleX 零 PII / 无身份层
- §5.5 im 配置块用 `simplex-chat -e "cmd" -t N` 模式,带用户踩过的避坑(`--create-bot-display-name` / `0x08000000` 阻止 cmd 黑窗 / 绝对路径双反斜杠)

---

## 关键技术选型(横向对比)

### ASR 引擎

| 选项 | 类型 | 适合 | 备注 |
|---|---|---|---|
| **SenseVoice Small (onnx)** | 本地 | GhostLine 强制;FastLane 兜底;基础版 | 用户已下载,中英混合好,CPU 0.3x 实时 |
| 火山豆包流式 2.0 | 云端 | FastLane 主推 | 20 小时/月免费额度,中文强 |
| OpenAI Whisper API | 云端 | FastLane 备选 | 英文强,中文弱 |
| 阿里 Qwen ASR | 云端 | FastLane 备选 | 中文,大厂可靠 |
| Paraformer / sherpa-onnx | 本地 | 备选(未实测) | GhostLine 未来扩展 |

### LLM 引擎

| 选项 | 类型 | 适合 | 备注 |
|---|---|---|---|
| **本地 Ollama** | 本地 | GhostLine 强制 | qwen2.5:7b-instruct-q4_K_M,NVIDIA 3GB 显存 CPU 跑 |
| Qwen-Max / DeepSeek-V3.2 | 云端 | FastLane 主推 | 中文质量好,价格低 5-10x GPT/Claude |
| Claude Sonnet 4.6 | 云端 | FastLane 备选 | 复杂任务 |
| GPT-4o | 云端 | FastLane 备选 | 价格高,留作重要任务临时切 |
| TrustedARI 类 ARI | 协议级 | 未来(2027+) | 当前**未实施**,不可用 |

### TTS 引擎

| 选项 | 类型 | 适合 | 备注 |
|---|---|---|---|
| **Windows SAPI** | 本地 | GhostLine 强制;基础版;FastLane 兜底 | `win32com.client.Dispatch("SAPI.SpVoice")` 或 .NET,声音生硬但能用 |
| Edge TTS | 云端(免费) | FastLane 主推 | 走微软云,**走云端但免费**,声音自然度远超 SAPI |
| BAILIAN CosyVoice | 云端 | FastLane 备选 | 中文 TTS 强,需付费 token |
| MiniMax M3(speech-2.6-hd) | 云端 | FastLane 备选 | 声音好,需付费 |

### IM 通道

| 选项 | 类型 | 适合 | 备注 |
|---|---|---|---|
| **SimpleX** | 本地+自建 | GhostLine 强制(用户已 VPS 部署) | **无身份层 / E2EE 默认开 / 服务器不知 metadata / 资源极轻** |
| Signal | 端到端加密 | GhostLine 备选 | 绑手机号(虽然 username 模式不暴露) |
| Matrix/Element | 端到端加密 | 不选(被 SimpleX 完胜) | 资源重,服务器可见 metadata |
| 微信/钉钉/飞书/Slack | 实名+服务商可读 | **FastLane 主推** | **FastLane 接受服务商数据策略** |
| Telegram(默认非 E2EE) | 群聊非 E2EE | **禁止** | Secret Chat 才 E2EE 但群聊不 E2EE |

---

## 隐私边界对照表

| 维度 | 基础版 | FastLane | GhostLine |
|---|---|---|---|
| **音频字节流上云** | 用户决定 | ✅ 上云(默认) | ❌ **永远不上云** |
| **ASR 文本上云** | 用户决定 | ✅ 上云(LLM) | ❌ 上云 = 违背核心承诺 |
| **TTS 走云** | 用户决定 | ✅ 走云 | ❌ **永远走 SAPI 本地** |
| **IM 端到端加密** | 用户决定 | ❌ 不强求 | ✅ 强制(SimpleX) |
| **实名注册** | 用户决定 | ✅ 接受 | ❌ **永远不接受** |
| **失败降级语义** | 用户决定 | ✅ 自动降级 | ❌ **失败 = 不响应** |
| **零外发验证** | 用户决定 | ❌ 不验证 | ✅ **Wireshark 抓包是验收硬条件** |
| **Wireshark 验收** | 不强制 | 不强制 | **必须** |

---

## 现场发现(必须知道的「过去式」)

调研时发现 `C:/Users/Administrator/voice_agent/daemon.py`(935 行,2026-07-02 创建)已经存在,走 **STEPFUN 云端全栈**(ASR `step-asr-1.1` / LLM `step-3.7-flash` / TTS `stepaudio-2.5-tts` 后废弃改 BAILIAN)。

**新方案 ≠ 在 voice_agent/ 上演进**。理由:
1. 旧 daemon 是**云端优先**,新方案是**本地优先**——架构相反
2. 旧 daemon 没显式做 OI 解耦 / 没显式做「人在场」感知 / 没显式做静音防回声
3. **新目录更干净**,旧 daemon 退役后归档(不删除,作为历史参考)

**处理**:**不删除** `voice_agent/`,**不 import** 它的代码。

---

## 触发再讨论的全局条件

| 触发 | 重新讨论 |
|---|---|
| SenseVoice 准确度不够 | 换 Paraformer / sherpa-onnx / Whisper local(GhostLine 强制本地,无法降级) |
| 用户硬件升级(NVIDIA 显存 >3GB) | GhostLine 模型可升 14B+;**用户已确认更新时重新评估** |
| Ollama 模型质量不够 | 换更大的本地模型(成本是本地 GPU) |
| SAPI 声音听不清 | 换本地 VITS / CosyVoice 本地版(体积大) |
| 某云服务大幅涨价 | FastLane 重选默认 |
| 用户开始用 GhostLine 讨论敏感信息 | 已经是「最敏感信息」场景,无需迁移 |
| 某云服务被曝数据泄漏 | FastLane 重选或暂离 |
| TrustedARI 类协议实施 | GhostLine 评估 G-2 路径 2 启用(5 条条件全满足) |
| 出现新的 SimpleX 替代品 | GhostLine 评估 |
| 用户想跨平台(macOS / Linux) | 三 ADR 全部重写 audio/inject 抽象层 |
| 用户想接云 TTS(GhostLine) | 改 ADR + 隐私协议重写,需 explicit consent |

---

## ADR 文件路径索引

| ADR | 路径 | 状态 |
|---|---|---|
| ADR-001 基础版 | `C:/Users/Administrator/voice_input/docs/adr/ADR-001-local-voice-input-architecture.md` | 已落盘 |
| ADR-002 FastLane | `C:/Users/Administrator/voice_input_fastlane/docs/adr/ADR-002-fastlane-cloud-first.md` | 已落盘 |
| ADR-003 GhostLine | `C:/Users/Administrator/voice_input_ghostline/docs/adr/ADR-003-ghostline-privacy-first.md` | 已落盘,已修正 G-2(去 TrustedARI 平台)+ G-4(改 SimpleX)+ §5.5(NVIDIA 3GB + qwen2.5:7b-instruct-q4_K_M) |

**三个仓库的共享架构**(双 daemon + orchestrator + REST + auth_token + loopback 强制)来自 ADR-001,FastLane / GhostLine 各自独立仓库,**不共享代码**(避免隐私审计风险)。

---

## 接下来的工作(待用户 review 后)

1. **用户 review 三份 ADR**——尤其 ADR-003 §5.5 实操配置(GhostLine 推荐模型 + SimpleX endpoint)
2. **用户确认先动哪个仓库**——我推荐先动 ADR-001 基础版(共享层),**两个产品线 FastLane / GhostLine 各自在 ADR-001 基础上展开**
3. **不动任何代码直到 review 完成**——这是用户明确要求

---

## memory 索引(其他事实已落 memory)

- `shandianshuo-product-architecture-2026-07-02.md` — 闪电说产品架构(纠正 #1 详情)
- `trustedari-protocol-facts-2026-07-02.md` — TrustedARI 协议事实(纠正 #2 详情)
- SimpleX 事实见 Obsidian 知识库已有 6/28 - 6/30 多份笔记(纠正 #3 详情)
- `MEMORY.md` 索引已更新两条

---

## 一句话总结(给未来的我)

> 2026-07-02 我和用户花了一整天调研「自研隐私输入法」。我们把 3 个一开始凭印象写错的事实纠正了(闪电说 ≠ Wispr Flow / TrustedARI ≠ 隐私 LLM 平台 / GhostLine IM 选 SimpleX 不是 Matrix),最终定下 3 条产品线(基础版 / FastLane / GhostLine),每条独立仓库,共享 ADR-001 的双 daemon + orchestrator 架构。**所有决策都落在 ADR,所有事实纠正都落 memory,代码一行没动。**等用户 review 三份 ADR 后再写代码。