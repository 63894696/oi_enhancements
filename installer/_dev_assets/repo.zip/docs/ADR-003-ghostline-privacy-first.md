# ADR-003 — GhostLine 产品线:隐私优先 / 零外发(除显式白名单)

- **状态**:Proposed
- **日期**:2026-07-02
- **依赖**:ADR-001 决策架构(双 daemon + orchestrator + SAPI TTS)
- **不依赖**:不依赖 ADR-002

## 1. 一句话定位

> **「按住热键 → 识别在本机、回复在本机、IM 走端到端加密 + 匿名」**。除清华 TrustedARI 协议平台显式白名单外,**零外发请求**。

## 2. 隐式目标用户画像

- 一个人,**他自己**。
- 隐私敏感,**讨论商业秘密 / 法律 / 财务 / 个人隐私 / 内部研究**。
- 接受响应慢 1-3 秒、识别准确度略低、TTS 声音生硬,**不让渡隐私**。
- 不接受任何实名 IM、不接受明文 IM。

## 3. 决策一览

| 编号 | 决策 | 选项 |
|---|---|---|
| G-1 | ASR 引擎 | **强制本地 SenseVoice Small**;不联网;不允许云 ASR |
| G-2 | LLM(OI 后端) | **本地 Ollama** OR **未来 ARI 协议级方案(TrustedARI 类,需 explicit whitelist)**;**不允许任何其他云 LLM** |
| G-3 | TTS 引擎 | **强制 Windows SAPI**;不联网;不允许云 TTS |
| G-4 | IM 通道 | **SimpleX(主推,用户已 VPS 自建 SMP+XFTP+Tor .onion)** OR **Signal**(备选);**端到端加密 + 无用户 ID + 默认匿名**;**不允许微信 / 钉钉 / 飞书 / Slack / Telegram(默认非 E2EE)** |
| G-5 | 失败降级 | **失败 = 不响应**;显式告知用户「GhostLine 不接受降级」 |
| G-6 | 网络策略 | **零外发**;白名单(loopback + Signal/Matrix homeserver VPS + 未来 TrustedARI ARI endpoint);**Wireshark 抓包零外发是验收硬条件** |
| G-7 | 启动速度 | 优先本地模型加载速度;**不发起任何网络连接** |
| G-8 | 注册 / 实名 | **不接受实名**;SimpleX 无身份层(主推);Signal 备选(绑手机号);未来 TrustedARI 需用户 consent |

## 4. 决策详情

### G-1:ASR 引擎 — 强制本地 SenseVoice Small

- **唯一允许**:`%AppData%\Shandianshuo\models\sensevoice-small\` 或 `~/.voice_input_ghostline/asr/sensevoice-small/`
- **禁止**任何云 ASR 调用——代码层 audit 拒绝任何 `urllib` / `requests` / `http.client` 调用指向 ASR 厂商域名
- **失败**=「找不到本地 SenseVoice 模型」,GhostLine 启动失败,不启动 ASR daemon

**为什么是 SenseVoice 而不是其他本地 ASR**:
- 用户已下载,**减少 1GB+ 下载**
- 中英文混合好
- onnx 推理 CPU 跑 0.3x 实时,**自用 CPU 完全够用**

**备选本地 ASR**(代码层预留):
- Paraformer-small(onnx)
- sherpa-onnx(支持多种 ASR 模型)
- 用户未来想换,改 `config.py` 一行

**为什么不强制 Whisper.cpp**:
- Whisper large onnx 大(>1GB),CPU 慢
- 用户已有 SenseVoice,**复用最经济**

### G-2:LLM(OI 后端)— 本地 + 未来 ARI 协议级方案

**两条路径二选一**:

#### 路径 1:本地 Ollama(主推,POC 阶段唯一可用)

- OI 进程配 `base_url=http://127.0.0.1:11434`(Ollama 默认端口)
- 模型自选:`qwen2.5:7b` / `deepseek-r1:8b` / `llama3.1:8b` 等
- **完全本地**,**零外发**
- **NVIDIA 3GB 显存约束**:
  - 7B 模型在 GPU 上勉强可跑(需模型量化到 Q4 / Q5)
  - **推荐主跑 CPU 模式**(Ollama CPU inference)
  - 14B+ 模型**完全不可能**,**只能选 7B / 8B 类小模型**
  - 默认推荐:`qwen2.5:7b-instruct-q4_K_M.gguf`(CPU 可跑,质量可接受)

**为什么不是云 LLM**:
- 任何云 LLM 都意味着 query 明文上云(云 LLM 厂商能看到)
- 这违背 GhostLine「音频字节流 + 文本字节流都不上云」的核心承诺

#### 路径 2:未来 ARI 协议级方案(TrustedARI 类,占位)

**当前状态(2026-07-02)**:**不可用**。

**为什么不可用**(来自 arXiv 2606.15822 调研):
- TrustedARI 协议**未实施 / 无 GitHub 实现仓库 / 无 IETF 草案**(协议自承)
- **没有「清华 TrustedARI 协议平台」这种 SaaS** —— 论文是 5 位清华作者的协议提案,**不是产品**
- 即使未来有团队实现 TrustedARI ARI 服务,**协议承诺的只是「ARI 中转站看不到 query」**,**不是「下游 LLM 看不到 query」**
- **协议不解决「数据上不上云」问题**

**未来启用条件**(全部满足才能加白名单):
1. 存在基于 TrustedARI 协议的公开 ARI 服务,有 GitHub 仓库 / 协议规范 / IETF 草案
2. 协议服务方公布:数据保留期限 / 删除权 / GDPR / 个保法合规 / 是否用用户数据训练
3. 协议服务方不强制实名,或实名在用户接受范围内
4. **协议服务方主动审计 + 第三方审计报告**(可选,加分项)
5. **用户本人 explicit consent**(不是默认开)

**Whitelist 注册机制**(未来):
- `~/.voice_input_ghostline/llm_whitelist.json` 白名单,只有列表里的 endpoint 才允许
- 默认**空** —— GhostLine 默认**只走路径 1 Ollama**
- 加白名单需用户手动编辑此文件 + 重启 daemon

**禁止任何其他云 LLM**:
- 微信元宝 / Kimi / 智谱清言 / 文心一言 / 通义千问在线版 / DeepSeek 在线版 / GPT / Claude / Gemini 等任何公共云 LLM endpoint —— **全部禁止**
- 代码层 audit:任何指向非 loopback / 非显式白名单的 LLM HTTP 调用 → 拒绝执行

### G-3:TTS 引擎 — 强制 Windows SAPI

- **唯一允许**:`win32com.client.Dispatch("SAPI.SpVoice")` 或 `.NET System.Speech.Synthesis`
- **禁止**任何云 TTS 调用
- **禁止** Edge TTS(它走微软云,**违反 GhostLine 承诺**)

**声音质量差**是 GhostLine 接受的 trade-off——**SAPI 中文 / 英文声音生硬但能听**。未来要换本地神经网络 TTS(VITS / CosyVoice 本地版)需要改 ADR + 用户确认。

### G-4:IM 通道 — SimpleX(主推)+ Signal(备选)

#### 候选 1:SimpleX(主推,**用户已 VPS 自建**)

**关键架构事实**(基于用户 2026-06-28 ~ 2026-06-30 部署笔记):
- **没有用户 ID / 没有用户账号**——SimpleX 协议根本**不存身份**;关系建立靠**invitation link / contact request / group link**
- **E2EE 默认开**——所有消息都 E2EE;服务器只见密文
- **metadata 防护 = 服务器不知道谁在跟谁联系**——比 Matrix 强(矩阵服务器知道用户列表和房间列表);比 Signal 强(Signal 服务器知道用户列表和元数据)
- **协议栈**:SMP(消息队列)+ XFTP(文件传输);客户端和服务端均开源
- **自建服务端**:
  - SMP server:用户已跑在 VPS(2026-06-28 .onion 化部署,公网域名 + Tor 隐藏服务双通道)
  - XFTP server:同上
  - VPS IP `192.220.14.165`,SMP `smp://...@smp.dreamproject.qzz.io,.onion`,XFTP `xftp://...@xftp.dreamproject.qzz.io,.onion`
- **客户端**:官方桌面 GUI(Windows / macOS / Linux)+ 官方移动端 + 内嵌 `simplex-chat` CLI(可用 WS 模式 `-p PORT` / 单次模式 `-e "cmd" -t N`)
- **注册**:完全匿名,**不需要手机号 / 邮箱 / 任何 PII**
- **多端同步**:支持(用户已有客户端 v0.3-v0.8 踩坑复盘)
- **CLI 自动化**:支持(`simplex-chat -e` 单次模式实测可用,`-p PORT` WS 模式可用)
- **资源占用**:**服务端非常轻量**,3GB 内存 VPS 完全够用(用户实测 192.220.14.165 同时跑了 simplex-smp + simplex-xftp + nginx + WireGuard)

**实现方式**:
- GhostLine 的 IM daemon 调 `simplex-chat -e` / WS 模式
- 通过 invitation link / group link 发送文本(SAPI TTS 转换的文本 / OI 回复文本)
- 监听 SimpleX 消息(用 WS 模式)→ 文本注入到当前焦点

#### 候选 2:Signal(备选,用户已实测可用)

- **优点**:
  - 真 E2EE(Signal Protocol,业内金标准)
  - 可以**无手机号注册**(Signal 支持 username,2024+ 特性)
  - 桌面客户端开源
- **缺点**:
  - 需要绑定手机号才能注册账号(2026 仍然如此,虽然 username 模式不暴露手机号)
  - 中国大陆被墙,**需要代理**
  - 桌面客户端消息同步依赖 Signal 服务器(虽然内容加密,metadata 不加密)

#### 为什么 SimpleX 优于 Signal / Matrix

| 维度 | SimpleX | Signal | Matrix/Element |
|---|---|---|---|
| **用户 ID** | ❌ 无(完全无身份层) | ✅ 有(绑手机号) | ✅ 有(@user:server) |
| **E2EE 默认** | ✅ 默认开 | ✅ 默认开 | ⚠️ 部分房间 E2EE 需手动开 |
| **服务器看 metadata** | ❌ 服务器不知谁联系谁 | ⚠️ 服务器知用户列表 + 元数据 | ⚠️ homeserver 知道用户列表 + 房间列表 |
| **匿名注册** | ✅ 无 PII | ⚠️ 绑手机号(虽然 username 模式不暴露) | ✅ 完全匿名 |
| **VPS 自建成本** | ✅ 极轻量(SMP+XFTP 共用 <100MB) | ❌ Signal 不开源服务端 | ⚠️ Matrix homeserver 重(Synapse 吃 1GB+ 内存) |
| **中国大陆可用** | ✅ 公网 + Tor .onion 双通道 | ❌ 被墙 | ⚠️ homeserver 自建可,客户端需配置 |
| **CLI 自动化** | ✅ 官方 CLI 完整支持 | ⚠️ signal-cli 第三方 | ✅ matrix-nio Python SDK |
| **多端同步** | ✅ 官方支持 | ✅ 官方支持 | ✅ 联邦化原生支持 |

**结论**:**SimpleX 完胜**(用户已 VPS 自建 + 元数据防护最强 + 资源最轻 + 跨平台客户端齐全)。

**实现方式(用户已踩过的坑要避)**:
- 不重新发明 IM 协议
- 调 `simplex-chat` 官方 CLI 二进制(用户笔记里的关键 flag:`--create-bot-display-name` / `-e "cmd" -t N` / `-p PORT` WS 模式)
- **避坑**(来自 v0.3-v0.8 复盘):
  - **不要尝试 WS 长连 + FFI + ConPTY**——v0.3-v0.8 全失败
  - **走单次模式 `simplex-chat -e "/users" -t 3`**——5 秒能跑,稳定
  - **绝对路径 + 双反斜杠**(Windows 下必须)
  - **进程创建标志 `0x08000000`**(阻止 cmd 黑窗)
- 客户端可走 `simplex-chat -p PORT` 起 WS server,GhostLine IM daemon 用 `ws://127.0.0.1:PORT` 调

**禁止的 IM**:
- 微信 / 企业微信 / 钉钉 / 飞书 / Slack / Discord —— **全部禁止**(实名 + 服务商可读)
- Telegram(默认非 E2EE)— **禁止**;Telegram Secret Chat 才 E2EE 但群聊不是 E2EE
- 任何要求手机号实名注册的 IM

### G-5:失败降级 — 失败 = 不响应

| 失败 | 行为 |
|---|---|
| SenseVoice 模型找不到 | GhostLine 启动失败,**不启动 ASR daemon** |
| Ollama / TrustedARI 不可用 | OI 进程无法响应,**显式告知用户「GhostLine 模式下不接受降级到云 LLM」** |
| SAPI 不可用 | TTS daemon 启动失败 |
| Signal / Matrix 客户端不可用 | IM 通道标注「不可用」,但其他通道(本地 ASR / 本地 TTS)仍可用 |

**不降级 = 不偷偷调用云端**。**失败时显式提示用户**。

**为什么 GhostLine 不接受降级**:
- 「降级到云」= 违背 GhostLine 的核心承诺
- 用户选 GhostLine 时**已经预期失败是常态**

### G-6:网络策略 — 零外发 + Wireshark 验收

**网络白名单**(以下以外的域名 / IP 全部拒绝):

| 类别 | 白名单 | 备注 |
|---|---|---|
| loopback | `127.0.0.1`,`localhost` | 本机所有 daemon |
| Ollama(若启用) | `127.0.0.1:11434` | 本机 Ollama |
| SimpleX SMP / XFTP(若启用) | `smp.dreamproject.qzz.io`,`xftp.dreamproject.qzz.io`,`*.onion`(用户 VPS 192.220.14.165) | **用户已自建部署**;可走公网域名或 Tor .onion |
| 未来 ARI 协议类服务 | **空**(协议未实施) | 见 §5,5 条启用条件全部满足才能加 |

**任何其他外发请求** = **daemon 拒绝执行 + 日志告警 + 触发配置 audit**。

**Wireshark 验收**:
- `scripts/verify_offline.py`:启动所有 daemon,跑完整 e2e,**Wireshark 抓包断言「非白名单外发请求数 == 0」**
- 验收失败 → CI 红 → 拒绝发布

### G-7:启动速度 — 优先本地加载,不联网

- 启动时**不发任何网络包**(不 ping / 不预热 / 不刷 token)
- SenseVoice 模型加载 + Ollama 模型加载是耗时大头
- **启动期间可见提示**:「GhostLine 启动中:加载 SenseVoice + Ollama,预计 N 秒」

### G-8:注册 / 实名

- **不接受实名**
- SimpleX:完全无身份层,无需任何注册,**零 PII**——主推
- Signal:绑手机号(虽然 username 模式不暴露)— 部分可接受,做备选
- Matrix:完全匿名可接受,但资源太重(已被 SimpleX 取代)
- TrustedARI 类(未来):按协议服务方要求,需用户 explicit consent

## 5. 关于 TrustedARI 协议的事实纠正(2026-07-02 调研后)

**用户最初提出的「清华 TrustedARI 协议平台」假设有以下错误**:

| 错误假设 | 实际情况 |
|---|---|
| 清华 TrustedARI 是「隐私 LLM 平台」 | **是 ARI 中转站与 agent 之间的密码学协议**,**不是 LLM 平台** |
| 有现成的 TrustedARI 服务可调 | **未实施** —— 协议自承「未走同行评审 / 无 GitHub / 无 IETF 草案」 |
| TrustedARI 解决「数据上不上云」 | **不解决** —— 它只解决「ARI 中转站看不看 query」,**下游 LLM 仍看明文** |
| TrustedARI 等于「端到端加密 + 匿名 + 无日志」 | **仅承诺 semi-honest 模型下的 query 加密**;**元数据(id_s / sid / 模板 T) ARI 看得到**;**日志 / 删除权 / 合规未涉及** |

**调研来源**:`C:/Users/Administrator/Documents/ObsidianVault/知识库/TrustedARI (arXiv 2606.15822, 清华 中转站可信路由协议, 2026-07-02).md`(28 页 PDF 已存档 + 翻译 + 高亮)。

**本次 ADR 修正**:
- G-2 路径 2 改名为「未来 ARI 协议级方案(TrustedARI 类)」
- 当前状态明确写「**不可用**」
- 启用条件写明 5 条 explicit 约束(协议实施 + 数据保留 + 实名 + 审计 + 用户 consent)
- 默认空 whitelist,**POC 阶段只走 Ollama**

**协议本身的价值**:即使 TrustedARI 当前不可用,**它的设计哲学 = 「ARI 中转站应使用密码学协议防止窥探」**,这条**对将来 GhostLine 的设计是有意义的**——如果未来出现 TrustedARI 类协议 + ARI 服务 + 用户 explicit consent,**GhostLine 可以无缝接入**。本 ADR 留出接口,**不删路径 2,只是写明当前不可用 + 启用条件**。

## 5.5 NVIDIA 3GB 显存约束下的 GhostLine 实操配置

**用户硬件约束(2026-07-02)**:NVIDIA GPU 显存 **3GB**。

**这意味着**:
- **7B 模型 Q4 量化** 在 3GB 显存上勉强能跑(**Ollama 会自动切 CPU 部分 layer**)
- **14B+ 模型完全不可能**
- **CPU 推理模式完全可用**,7B Q4 模型 ~5-8 token/s 中文(慢但能用)
- **更新硬件时重新评估**(用户已确认)

**GhostLine 推荐配置**(针对 NVIDIA 3GB):

```yaml
# ~/.voice_input_ghostline/config.yaml
llm:
  backend: ollama
  base_url: http://127.0.0.1:11434
  model: qwen2.5:7b-instruct-q4_K_M   # 用户接受推荐:Q4 量化,3GB 显存勉强
  # 备选:deepseek-r1:7b-qwen-distill-q4_K_M  (推理稍弱但中文好)
  # 备选:llama3.1:8b-instruct-q4_K_M          (英文好中文稍弱)

asr:
  backend: sensevoice_local
  model_path: %AppData%\Shandianshuo\models\sensevoice-small\
  # 或 ~/.voice_input_ghostline/asr/sensevoice-small/

tts:
  backend: sapi_only

im:
  backend: simplex  # 用户已 VPS 自建 SMP + XFTP + Tor .onion
  smp_server: smp://vWtAc05N3YYSHBqKhhjWNQ4rbsbYC17dx2HuTVmNMW4=@smp.dreamproject.qzz.io,ka7ksfzpsr7cn6pttekbnrbd3shxjfkijwo3smkadm65go2rqzoxmzqd.onion
  xftp_server: xftp://q9NyFFGq0sz34e-nkzMKndVZAFPnB2KYrD0VVpkbRC4=@xftp.dreamproject.qzz.io,ka7ksfzpsr7cn6pttekbnrbd3shxjfkijwo3smkadm65go2rqzoxmzqd.onion
  cli_path: C:\path\to\simplex-chat.exe   # 用户已实测 v6.5.6 可用
  mode: exec_oneshot  # simplex-chat -e "cmd" -t N 模式(用户已踩过 WS/FFI 坑,推荐这个)
```

**性能预估**:
- 短按直接说(ASR): 0.5-1 秒(CPU 跑 SenseVoice Small)
- OI 回复(LLM): 5-15 秒(Q4 量化 7B 模型 CPU 跑,中文输入)
- OI 回复语音(TTS): 1-2 秒(SAPI 一次性生成)
- 文本通过 SimpleX 发送: 0.5-2 秒(走 Tor .onion 较慢,公网域名较快)

**vs FastLane 对比**:响应慢 **5-15 倍**(FastLane 云 LLM ~1 秒,GhostLine 本地 7B ~10 秒)

## 6. 仓库布局(独立仓库)

```
C:/Users/Administrator/voice_input_ghostline/
├── docs/
│   ├── adr/
│   │   └── ADR-003-ghostline-privacy-first.md   ← 本文档
│   ├── trusted_ari_protocol_spec.md             ← 用户补 / 我抓
│   └── threat-model-ghostline.md
├── src/voice_input_ghostline/
│   ├── config.py
│   ├── asr/
│   │   └── sensevoice_local_only.py             ← 拒绝云 ASR
│   ├── llm/
│   │   ├── ollama_local.py
│   │   └── trusted_ari.py                      ← 若启用
│   ├── tts/
│   │   └── sapi_only.py                         ← 拒绝云 TTS
│   ├── im/
│   │   ├── signal.py
│   │   └── matrix.py
│   ├── network/
│   │   └── whitelist_enforcer.py                ← 强制白名单
│   └── [继承 ADR-001 的 daemon 骨架]
├── scripts/
│   ├── verify_offline.py                        ← Wireshark 抓包验收
│   ├── network_whitelist_audit.py
│   └── fail_mode_test.py                       ← 模拟所有失败,验证「不响应」语义
└── README.md
```

## 7. 隐私边界声明(GhostLine 版)

### 7.1 永远不上云

- 音频字节流 → 本地 SenseVoice
- ASR 文本 → 本地 Ollama(未来 ARI 白名单 endpoint,当前不可用)
- LLM 回复文本 → 本地 SAPI
- IM 消息内容 → SimpleX E2EE(主推) / Signal E2EE(备选)
- 全局热键 / 静音状态 / 文本注入操作 → 仅本机

### 7.2 可能上云(显式白名单)

- **未来 ARI 协议级 endpoint**(TrustedARI 类)— **当前不可用**;5 条启用条件全部满足 + 用户 explicit consent 后,手动写入 `~/.voice_input_ghostline/llm_whitelist.json` 才允许
- **SimpleX SMP/XFTP**(若启用)— 用户自建 VPS 域名 / `.onion`,在白名单内
- **Ollama 自身若启用远程 endpoint** — **禁止**,Ollama 必须 bind loopback

### 7.3 永远不上云(显式黑名单)

- 任何 ASR 厂商(豆包 / Whisper / Qwen ASR 等)
- 任何 LLM 厂商(Qwen / DeepSeek / GPT / Claude 等在线版)
- 任何 TTS 厂商(Edge TTS / CosyVoice 云 / MiniMax 等)
- 任何 IM 厂商(微信 / 钉钉 / 飞书 / Slack / Discord 等)
- 任何 telemetry / 分析服务

## 8. 触发再讨论

| 触发 | 重新讨论 |
|---|---|
| SenseVoice 准确度不够 | 换 Paraformer / sherpa-onnx / Whisper local |
| Ollama 模型质量不够 | 换更大的本地模型(成本是本地 GPU) |
| SAPI 声音听不清 | 换本地 VITS / CosyVoice 本地版(体积大) |
| TrustedARI 协议确认后细节变化 | 重写 G-2 |
| 用户发现白名单有外发 | **立即调查 + 修代码 + 拒绝继续跑** |
| 用户新增本地 IM(如自建 Matrix homeserver) | 扩 G-4 |

## 9. 关键约束(用户 review 重点)

1. **失败 = 不响应 = 用户得有心理准备**。GhostLine 模式下,网络一断 / Ollama 没跑 / TrustedARI 不可用,**语音输入就废了**。这是产品哲学,不是 bug。
2. **响应延迟比 FastLane 高 1-3 秒**(本地推理慢)。
3. **TTS 声音生硬**(SAPI 限制)。
4. **TrustedARI 协议细节未确认前,G-2 路径 2 关闭,默认走 Ollama**——这意味着如果你没有本地 GPU / 没有 Ollama,**GhostLine 直接不可用**。

## 10. 与 FastLane 的差异

| 维度 | FastLane | GhostLine |
|---|---|---|
| **核心承诺** | 3 秒响应 | 零外发 |
| **失败语义** | 自动降级 | 不响应 |
| **网络** | 任意(强制 HTTPS) | 零外发(白名单外拒绝) |
| **ASR** | 云端 Whisper / 豆包 / Qwen ASR + 本地 SenseVoice 兜底 | **强制本地 SenseVoice**,无云端 |
| **LLM** | 云端 Qwen-Max / DeepSeek-V3.2 / Claude | **本地 Ollama 或 TrustedARI 平台**,无其他云 |
| **TTS** | 云端 Edge TTS / CosyVoice + SAPI 兜底 | **强制本地 SAPI**,无云端 |
| **IM** | 微信 / 钉钉 / 飞书 / Slack | **SimpleX(主推) / Signal(备选)**,匿名 + E2EE |
| **实名** | 接受 | 不接受 |

## 11. 双版本同台运行

**同一个 Windows 机器能同时跑 FastLane 和 GhostLine**——端口不冲突即可:

- FastLane 占端口:**8750**(orchestrator)/ **8751**(asr)/ **8752**(tts)(建议;与 base 8730-32 共存)
- GhostLine 占端口:8740(orchestrator)/ 8741(asr)/ 8742(tts)
- ADR-001 基础版:8730(orchestrator)/ 8731(asr)/ 8732(tts)

**用户切换**:
- 通过不同的全局热键区分(FastLane 用 `Ctrl+Shift+Space`,GhostLine 用 `Ctrl+Alt+Space`)
- 两个 daemon 同时跑,各自独立 OI 客户端配置

**触发场景切换**:用户在不同任务间切换时手工切热键——**这是显式选择,不是自动**。