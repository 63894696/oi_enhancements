# Prisir 浏览器编译整体逻辑(功能拆分蓝图)

日期: 2026-08-20 · 状态: 立项设计(用户拍板「按建议顺序,②先行」)· 承接翻译插件(MV3 扩展)实部署现状
前置: 扩展功能模块盘点(子代理勘察 custom-hover-translate/extension/src)+ manifest v0.3.0 基线

## 0. 核心原则(用户拍板,贯穿全文)

> **「能集成在浏览器的就集成在浏览器;用户在浏览器设置页自行配置端点和 KEY。」**

目标用户拿到的是**纯浏览器**,没有我们本地开发机的 prisirwork 组合(Python 后端、oiagent 团队、
系统环境变量)。因此:

1. **不依赖浏览器外的本机进程**。一切功能要么浏览器内闭环,要么砍掉/做成可选。
2. **凭据统一在浏览器设置页配置**,存 `chrome.storage.local`,本机不回显、不进模型上下文。
   系统环境变量那条路对终端用户不成立(浏览器读不到 OS 环境变量),废弃。
3. **翻译插件是过渡承载体**。其上现在承载的翻译/字幕/视频笔记/NTP 对话/代行/搜索,
   重编译时按本文档归置:进浏览器核心 / 留作可选扩展 / 砍掉。
4. **一套安全纪律贯穿所有功能**(见 §3 凭据纪律)。

## 1. 现状基线(manifest v0.3.0)

```
permissions:         storage, activeTab, scripting, webNavigation, contextMenus,
                     alarms, bookmarks, offscreen
optional_permissions: management                      # 运行时 opt-in(扩展管理类代行)
host_permissions:    translate.googleapis.com, youtube.com, image.baidu.com,
                     baidu.com, duckduckgo.com, html.duckduckgo.com,
                     127.0.0.1:12308, localhost:12308  # 本机后端(见 §4 决策)
optional_host_permissions: https://*/*, http://*/*
newtab override:     src/ntp/ntp.html                  # NTP 对话页
```

**关键结论(来自盘点):扩展几乎纯浏览器闭环。唯一硬依赖本机后端(127.0.0.1:12308)的
是「实时字幕 ASR」(local_sensevoice)。其余 12308 引用全是可选翻译后端 / 历史常量 / 过时注释。**

## 2. 功能归置蓝图(重编译时的拆分决策)

按「进浏览器核心 / 留作可选扩展 / 砍掉 or 保留可选」三档归置。

### 2.1 进浏览器核心(默认内置,纯浏览器闭环)

| 功能 | 现状入口 | 凭据需求 | 备注 |
|---|---|---|---|
| 整页/划词/图片文字翻译 | engines.js / content.js / inject.css / popup / options | 免 key(google_gtx)或自配 OpenAI 兼容端点 | 浏览器原生翻译层之上增强 |
| 视频双语字幕(YouTube/Netflix/通用 TextTrack) | subtitles.js / yt/nf-main-hook.js | 同翻译引擎 | |
| 视频帧笔记 + 全篇笔记 | video-notes.js / video-note-prompts.js / video-study.js | 自配多模态端点 | |
| 笔记落盘(File System Access) | note-workspace*.js / offscreen-workspace.* | 无 | 浏览器内 FSA + IndexedDB |
| NTP 对话全套(搜索问答/深入研/追问/图片问答/新窗接续/附件) | ntp/* + background 管道 | 自配端点 | 深入研已是 SW 内置 |
| 多模型 fan-out + verifier | chat_models / chat_race / cross_tab_research | 自配端点 | |
| 会话存档 + 上下文管理 | ntp/chatstore.js / ntp/ctx.js | 无 | storage.local |
| 智能体代行全套(16 动作白名单/intent 路由/审计/badcase) | agent/* | LLM 路由需端点 | 见 §5 权限 |
| 技能系统(声明式 skill 加载) | agent/skill_* | 无 | |
| 产品知识 / 外宣语料 | agent/product_knowledge / outreach* | 无 | 内置常量 |

### 2.2 留作可选扩展 / 运行时 opt-in

| 功能 | 现状 | 决策理由 |
|---|---|---|
| 扩展管理(启停/卸载其它扩展) | registry CW-2 动作,management optional | 高权限,运行时申请,默认不开 |
| 可选 local_backend 翻译引擎 | engines.js `callLocalBackend` @12308 | 高级项,默认关;无后端时自动隐藏 |

### 2.3 需重编译决策的唯一硬依赖:实时字幕 ASR

| 现状 | 问题 | 三条出路(重编译前拍板) |
|---|---|---|
| live-subtitles.js + engines.js `callLocalAsr` 默认走 `127.0.0.1:12308/asr`(本地 SenseVoice + VAD);云端 ASR 是未实现占位 | **无本机后端即不可用**,违背核心原则 | **(a) 搬进浏览器**:WASM 本地 ASR(如 whisper.cpp.wasm / sherpa-onnx),纯闭环但包体大、性能待测;**(b) 云端 ASR**:接用户自配 ASR 端点(补全 cloud_asr),与翻译端点同套凭据纪律;**(c) 砍掉实时字幕**,保留录屏后离线字幕。**建议 (b) 优先、(a) 作进阶**,(c) 兜底。 |

### 2.4 砍掉 / 不带进浏览器

- 无。盘点未发现「只能依赖 prisirwork 才能用」的功能 —— 除 ASR 外全部已浏览器闭环。
  (深入研 background.js:251 的「走 127.0.0.1:12308」是**过时注释**,实现已是 SW 内置,需顺手清理。)

## 3. 统一凭据纪律(所有功能共用)

一套纪律贯穿翻译/搜索/ASR/钱包/代行,不因功能而异:

1. **存储**:全部存 `chrome.storage.local`,永不回显明文(输入框 type=password / 存后只显示位数)。
2. **不进模型上下文**:key/口令绝不拼进发给 LLM 的 messages(同 CW-2「key 不落 LLM/不落持久化」红线)。
3. **不进审计明文**:审计日志(agentAudit)对 apiKey 等参数脱敏(现状已做,延续)。
4. **本机优先、默认不上云**:检索/翻译只走用户显式配置的端点;无配置则只走免 key 源。
5. **token/口令不落盘**:钱包口令、session token 等敏感物只活内存,重启即清(对应壳端 0600 纪律的浏览器等价物)。
6. **设置页统一入口**:所有「端点 + key + 模型」集中在设置页分组管理(翻译引擎/搜索提供方/ASR/多模态/钱包),一组一「测试连接」。

## 4. 权限清单(重编译 manifest 目标)

保留现有,新增/调整:

| 权限 | 现状 | 重编译 | 用途 |
|---|---|---|---|
| storage, activeTab, scripting, webNavigation, contextMenus, alarms, bookmarks, offscreen | ✅ 有 | 保留 | 现状功能 |
| management | optional | 保留 optional | CW-2 扩展管理(运行时申请) |
| **notifications** | ❌ 无 | **新增** | 品牌化通知(③,见 §6) |
| host: 127.0.0.1:12308 | ✅ 有 | **视 ASR 决策**:选(b)云端则**移除**,选(a)/(c)也可移除 | 本机后端(目标:消除) |
| host: 各搜索 API 域名(parallel/exa/tavily 等) | ❌ | **新增**(或并入 optional `https://*/*`) | 搜索提供方(①,见 §5) |

**目标:重编译后 manifest 不再引用任何 127.0.0.1 / localhost** —— 彻底消除浏览器外后端依赖。

## 5. 新功能落点(本轮①③④在蓝图里的位置)

| 任务 | 落点 | 凭据 | 权限 |
|---|---|---|---|
| ① 搜索提供方(Parallel/EXA/Tavily + 免 key 扩 Google/Bing/SearXNG) | background.js 搜索管道 stage2;设置页「搜索提供方」区 | 各家 key 存 storage(§3) | host: 各 API 域名 |
| ③ 品牌化通知 | background.js alarms 轮询更新清单 + chrome.notifications;壳侧 Electron Notification | 更新清单为公开静态 JSON,无需 key | notifications + alarms(已有) |
| ④ 智能书签分类 | agent/registry 新增 bookmark_classify(L1/summary) | LLM 分类需端点 | bookmarks(已有) |

三者全部浏览器内闭环,符合核心原则。

## 6. 待拍板清单(重编译前)

1. **实时字幕 ASR 出路** ✅ 已拍板(2026-08-20):**云端 ASR 自配端点**。补全 cloud_asr,
   让用户自配 ASR 端点(与翻译同套凭据纪律),消除对 12308 的硬依赖。WASM 本地 ASR 作进阶。
2. **搜索 API 域名** ✅ 已拍板(2026-08-20):**复用 optional `https://*/*`**(manifest 现状已有)。
   搜索 API 调用走它,用户首次用时按需授权;加新搜索源不改 manifest 不重编译。
3. **品牌化通知的更新清单托管** ✅ 已拍板(2026-08-20):**babelspan.com 静态 JSON**,
   与品牌站点同源便于运营;轮询每日一次(alarms,可关)。
4. **过时注释清理**:background.js:251「深入研走 12308」等,顺手修(随①一起做)。

## 6.1 重编译前检查清单(逐项核对,不通过不出包)

- [ ] **去除浏览器自带「自定义主题/自定义 Chromium」模块**。NTP 底部那行空白自定义栏
      (截图 2026-08-20:页面底部「✎ 自定义 Chromium」浮条 + 一条空白横条)是 Chromium 自带
      theme/customize 模块残留。我们的 NTP 是扩展 override(ntp.html),不需要也不应显示浏览器
      自带的自定义入口。**编译时在 Chromium 源码层移除/禁用 customize NTP 模块与主题栏**,
      编译后开新 tab 目检:页面底部只有我们自己的 footer(babelspan.com/功能介绍/内容柜/智能书签分类),
      无任何「自定义 Chromium」浮条或空白自定义横条。
- [ ] manifest 不再引用任何 127.0.0.1 / localhost(§4 目标)。
- [ ] 搜索提供方:设置页「搜索提供方」分组可配 Parallel/EXA/Tavily,测试按钮走真实 /search(非 chat/completions)。
- [ ] 凭据纪律:所有 key 存 storage.local、不回显明文、不进模型上下文、不落审计明文(§3)。
- [ ] **论坛跨端身份一致性**:论坛签名密钥必须由 identity 根**确定性派生** `DeriveKey("forum-sign","ed25519-sign")`(非每次随机生成),确保 Windows / Android / Linux / Mac 各端对同一身份根派生出**相同 Ed25519 公钥 → 相同 author_fp**。验收:(a) `forum.mojom` handler 走 identity.DeriveKey 薄壳转发,私钥不出原生层;(b) 同一身份根在两端各发一帖,relay 侧两帖 `author_fp` 完全一致;(c) localStorage 无 `forum_id_jwk` 明文私钥(降级模式已迁原生层);(d) chrome://forum 打开 `window.ForumNative` 存在。锚点:跨端 fp 不变 = 用户在任意端都是「同一个自己」,确认计数/关注/信任跨端继承。
- [ ] **发布前 VT 自检(防误报)**:本批次编译出的**每一个将分发的可执行产物**(浏览器本体 installer/exe、各 cdylib `*.dll`、输入法 `prisir_ime.dll`、探囊 `prisir_findex.dll`、shell 壳 exe 等)逐个走探囊查毒闭环:本地算 SHA256 → 查 VirusTotal;若 VT 无记录则**经用户当场显式同意**上传本体分析。判定标准:**0 引擎报毒才放行**;出现 ≥1 引擎报毒,先停发排查(是否误用敏感 API/加壳/含可疑字符串),确认误报再走厂商申诉,**绝不带病出包**。操作入口:`oiagent_web` 起服后 `POST /oiagent/api/findex/reputation {path, upload}` 或探囊页「查毒」按钮。红线不变:只传哈希默认不传本体,上传须显式同意。实测锚点(2026-08-22):无签名 `prisir_findex.dll` VT 75 引擎 0 报毒——本批新产物以「0 报毒」为放行基线。


## 红线对齐

- **不依赖浏览器外进程**:唯一硬依赖(ASR)已单列决策,目标 manifest 零 localhost。
- **凭据纪律**:key 本机存储/不回显/不进模型/不落审计明文;口令不落盘。
- **复用不重复造**:本蓝图基于实部署扩展盘点,不重写已闭环功能;搜索/通知/书签均插进现有管道。
- **默认本地,云端显式**:所有云端(搜索 API/云端 ASR)都需用户在设置页显式配置才启用。
