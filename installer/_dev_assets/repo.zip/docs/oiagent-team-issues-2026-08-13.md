# oiagent 协作团队任务 — P0.6 实测暴露的 4 项改进 · 2026-08-13

> 来源:用户在浏览器实测 P0.6(窗口标题栏/上下文提醒/新窗接续)+ 智能模式后,反馈一批问题。
> 已本轮修复 A–F(见 `custom-hover-translate` commit ff1812e);以下 4 条是**修复中暴露、但超出本轮范围**的跟进项,交协作团队分析/排期。
> **门槛:这 4 项处理完后,才继续推进串行链 P1(securedm 连接器)。**(用户拍板)
> 每条都给:现象/根因/建议/验收。红线同 M7a(白名单、凭证不进 LLM、确认在扩展侧、本地优先不上云)。

---

## I-1 浏览器内省能力扩展(management 权限做 opt-in 扩展体检)— ✅ 已实现(2026-08-13)

**现象**
本轮为「智能模式不查浏览器」补了两个 L0 内省动作:`translate_status`(报本扩展翻译状态)、`browser_introspect`(报能力+前端探针)。但**无 `management` 权限,无法枚举用户安装的其它扩展**——用户问"浏览器里装了哪些插件"时,只能如实拒绝并指去 `chrome://extensions`。

**根因**
MV3 下枚举/启停扩展需要 `management` 权限,本扩展未申请。这是隐私/安全的合理默认,但**用户有此真实需求**。

**建议(已定方向)**
1. 做一个 **opt-in 的「扩展体检」能力**:用户**明示授权**后,扩展申请 `management` 权限,提供**只读枚举**(名称/版本/启用态)。
2. `management` 放 manifest `optional_permissions`,**运行时用户点头才启用,默认不申请**——符合「权限独立 opt-in」红线。
3. **只读,不做启停写操作**(写操作风险高,不做)。
4. 枚举结果不落盘、不进 LLM(除非用户主动把它当问答上下文)。

**验收**
- 未授权时:`browser_introspect(extensions)` 仍如实说"无权限,可去 chrome://extensions 查看 / 或授权扩展体检"。
- 用户授权(optional_permissions 运行时点头)后:能列出已装扩展(名称/版本/启用态),只读。
- 全程无启停写操作;默认不申请权限。

**风险/待定**:~~是否引入 `management` 权限需用户拍板~~ → **已拍板(2026-08-13):允许引入 `management` 权限做 opt-in 扩展体检**。边界:**只读枚举(名称/版本/启用态),不做启停等写操作**;必须 `optional_permissions` + 运行时用户点头才启用、默认不申请;结果只读、不落盘、不进 LLM(除非用户主动当问答上下文)。

**实现(2026-08-13)**:回归 **4/4 实跑 PASS**(未授权态;授权后枚举分支见下)。
- **manifest**:`management` 放 `optional_permissions`(主 `permissions` 不含)——默认不申请,运行时点头才启用。
- **`_agentIntrospect(extensions)` 授权态分支**:①`chrome.permissions.contains` 探测;②**未授权**→回 `needsPermission:'management'` + 如实说明(只读/默认不申请/可去 chrome://extensions),**不给列表**;③**已授权**→`chrome.management.getAll()` 只读枚举(名称/版本/启用态/标出本扩展),**无任何 setEnabled/uninstall 写操作**(回归 C 用「management.setXxx(」调用语法断言,说明文字里的字样不算)。
- **授权手势流**:`chrome.permissions.request` 需用户手势(SW 没有),故 NTP `renderActionResult` 检测 `needsPermission` → 渲染「授权扩展体检(只读枚举)」按钮 → 用户点击(手势)触发浏览器授权弹窗 → 授权后自动重发枚举拿真实列表。
- **穿透**:SW `_agentIntrospect` 返回的 `md/needsPermission/data` 经 `_agentExec` 的 `Object.assign` 透到 NTP;`renderActionResult` 新增 `r.md` 直渲分支(内省类动作)。
- **不落盘/不进 LLM**:枚举结果只在该次回答的卡片里展示,不写 storage、不进 badcase/audit 的 params(`browser_introspect` 参数只 `{topic}`)。
- 回归 `tests/_i1_ext_audit_e2e.py`:A manifest optional 含 management 且主 permissions 不含、B 未授权→needsPermission+如实说明不给列表、C 只读无写操作、D 权限探测。**E(授权后枚举)需真实用户手势授权后重跑覆盖**——授权弹窗的点击无法自动化(恰是 opt-in 设计本意)。**改动 _agentIntrospect/manifest 权限时必跑。**

---

## I-2 路由覆盖率:该查浏览器却退回 chat 的 badcase 收集 — ✅ 已关闭(2026-08-13)

**现象**
用户的"翻译插件开没开/会自动翻吗"被判成 `chat`,模型只泛泛回答"无法确定"。本轮用**关键词快路径**(`keywordRoute`)确定性兜底了几条,但**覆盖不全**——"该查浏览器/该代行却退回纯问答"可能还有别的问法没兜住。

**根因**
路由器对「内省类/代行类」问句与「纯咨询」的边界,靠 LLM 慢路径 + 少量关键词,存在漏判。

**建议**
1. 建一个 **badcase 收集机制**:智能模式下,凡是退回 `chat` 但用户随后表示"你没去查/没去做"的,记一条(本地,含原始问句 + 实际路由结果),供离线分析。**不上云、需用户知情。**
2. 协作团队定期过这批 badcase,**补关键词快路径**(确定性)或**微调 LLM 路由 prompt**。
3. 给 LLM 慢路径 system 补一条强提示:「凡是问"当前/我的浏览器/插件/是否开启"这类**需要看实时状态**的,优先选内省动作,不要退回概念性问答」。

**验收**
- 有一组回归用例:覆盖"该查浏览器"的多种问法,断言**不退回 chat**。
- badcase 收集本地可查、默认不上传、可在设置关。

**结果(2026-08-13)**:全部落地,回归 **3/3 PASS**。
- **收集器** `src/agent/badcase.js`(`CT_BADCASE`,环形 200 条/问句截 300 字;默认开、`collectBadcases===false` 关、只存 local、不上云)。接在 `handleAgentRun` 退回 chat 分支,经 `looksLikeIntrospect` 过滤——**只记疑似内省/代行,不记纯闲聊**(减噪音 + 少存用户文本)。
- **LLM 慢路径 system 已补强提示**:「问当前/我的浏览器/插件/是否开启这类需要看实时状态的,优先选内省动作,不要退回概念性问答」。
- **顺手修了一个真 badcase**:「什么是浏览器扩展」原会被误判成扩展枚举——`keywordRoute`/`looksLikeIntrospect` 都加了概念定义式排除(什么是/什么叫/的区别/怎么工作…)。
- 设置页/离线分析可读 `badcase-list`、清 `badcase-clear` 消息端点。
- 回归:`tests/_route_badcase_e2e.py`(A 收集器记/开关/清空、B 过滤器内省T闲聊F、C 关键词路由多种问法不退 chat)+ `tests/_i2_integration_forced.py`(stub chatText 强制落 chat → 确定性验证「退回 chat 且命中 → 已记」)。**改动 router/badcase 时必跑。**

---

## I-3 产品知识集中维护(单一事实源)— ✅ 已关闭(2026-08-13)

**现象**
本轮为「模型不认识自家产品 babelspan」在 `buildAttachmentContext` 里硬编码了一段产品知识(shelf 导出格式等)。但这只在**附件问答**注入;普通问答、vision、handoff 等其它路径拿不到同一份知识,且硬编码难维护。

**根因**
产品知识散落/缺失,没有单一事实源(single source of truth)。

**建议**
1. 抽一份**集中的产品知识文件**(如 `src/agent/product_knowledge.js` 或 JSON),描述 babelspan 产品系(shelf/翻译/OIagent、各导出格式、能力边界)。
2. 所有需要的路径(附件、普通问答 system、vision、handoff)**统一引用**这份,不散落硬编码。
3. 内容只放**公开产品描述**,不放任何敏感信息(端点/key/内部实现)。

**验收**
- 产品知识只在一处维护;改一处全链路生效。
- 传自家 shelf 导出文件,普通问答/附件问答都能正确识别(不再说"无法确认哪个应用")。
- 知识文件不含敏感信息(code review 确认)。

**结果(2026-08-13)**:单一事实源落地,回归 **3/3 PASS** + 真实注入验证 PASS。
- **新模块** `src/agent/product_knowledge.js`(`CT_PRODUCT_KNOWLEDGE`,两档:`SHORT` 简短版进问答/vision system,`DETAIL` 详细版含 shelf 导出字段进附件块)。只放公开产品描述,无端点/key/内部实现。
- **全链路统一引用**:`handleChatAsk`(普通问答 system 注入 SHORT)、`handleChatVision`(vision system 注入 SHORT)、`buildAttachmentContext`(附件块用 DETAIL)。原 `background.js` 里的硬编码 `PRODUCT_KNOWLEDGE` 常量已删,三处函数源码均无 `babelspan` 字面残留(断言确认)。
- **handoff 不注入**(摘要是给新窗口的,新窗口问答会经 handleChatAsk 自带产品知识,省 token)。
- 改知识 → 只改 `product_knowledge.js` 一处,全链路生效。
- 回归 `tests/_product_knowledge_e2e.py`(A 知识正确+无敏感、B 附件引用同一模块[哨兵替换法证明非副本]、C 三链路引用模块+无硬编码残留);`tests/_i3_real_shelf.py`(stub chatText 捕获,断言发给模型的 system 带 SHORT、user 附件块带 DETAIL+shelf 字段+防注入包装)。**改动产品知识/问答链路时必跑。**

---

## I-4 会话持久化/恢复的回归测试组 — ✅ 已关闭(2026-08-13)

**现象**
本轮修的 B(空会话堆积)、C(切走再切回提问丢失)都属**状态恢复**类 bug——`storage.session` 与 `storage.local` 两条线的优先级/时序没理顺,容易回归。

**根因**
持久化(session 快照 + local 存档)与恢复(live 优先 / 存档兜底)的逻辑分散,缺乏回归网。

**建议**
补一组**状态恢复回归用例**(本地 E2E,不下标题栏 UI 也可测数据层):
1. 发问后 reload 标签页 → 提问仍在(live session 优先)。
2. 切换到历史会话 → 完整消息(user+assistant)都在。
3. 开多个空标签页 → 不堆积 0 条会话(`pruneEmpty` + 复用)。
4. 浏览器重启(模拟:清 session) → 从 local 存档恢复完整会话。
5. `persistHistory=false` 时 → 不写 local 存档(隐私开关生效)。

**验收**
- 上述 5 条做成可重复跑的 E2E(如 `tests/_persist_regression_e2e.py`),全 PASS。
- 纳入改动 ntp.js 持久化相关代码时的**必跑**回归。

**结果(2026-08-13)**:`custom-hover-translate/tests/_persist_regression_e2e.py`,**5/5 PASS**(真实 NTP 页数据层,CDP 9222)。① live 线程优先(未入档提问不丢)② 切换历史会话完整 ③ pruneEmpty 清 0 条 + 复用空会话不堆积 ④ 清 session 模拟重启后从 local 完整恢复 ⑤ `persistHistory=false` 时 `enabled()=false`(默认开可关)。测试带唯一 TAG,跑完自清理。**改动 ntp.js 持久化/恢复相关代码时必跑。**

---

## 排期与依赖

- 四条**互不阻塞**,可并行;但**全部关闭后才开 P1**(用户拍板)。
- 进度:**I-1 / I-2 / I-3 / I-4 全部 ✅ 关闭(2026-08-13)** → **P1(securedm 连接器)门槛已解除,可推进。**
- 各条回归均入库(I-4 `_persist_regression_e2e.py` 5/5、I-2 `_route_badcase_e2e.py` 3/3、I-3 `_product_knowledge_e2e.py` 3/3、I-1 `_i1_ext_audit_e2e.py` 4/4 实跑),改动对应模块时必跑。
- I-1 唯一待人工确认项:授权弹窗真实点击(需用户手势,无法自动化)——在 NTP 问"装了哪些扩展"→点「授权扩展体检」→弹窗同意后应列出扩展清单。属验收性手动测试,不阻塞代码关闭。

---

## 二轮缺陷修复(P0.6 round-2)— ✅ 已闭环(2026-08-13,嵌套仓 67404bc)

用户实测反馈 5 项,全部定位并修复,回归 `tests/_p06_round2_e2e.py` **7/7 PASS**:

| # | 现象 | 根因 | 修法 |
|---|------|------|------|
| ① | （未命名）无法重命名 / 想要自动命名 | MV3 扩展页**禁用 window.prompt**(静默返回 null) | startRename 改 **inline 输入框**(Enter 存/Esc 取消/blur 存);chatstore.listConversations 加**惰性自动命名**(空标题→首条 user 消息命名并固化) |
| ② | 无删除历史对话功能 | 未实现 | renderConvList 加「删」按钮 + startDelete **inline 确认流**(确认删?/删/留) |
| ③ | 智能模式切会话后**用户提问+oiagent 回答全丢**,切回只剩第一条回答 | routeInput(智能模式路径)**从未调 pushMsg/persistThread**,只有经典 askBody 落档 | routeInput 入口 pushMsg user、各终态(confirm/result/失败)pushMsg assistant + persistThread;askBody 加 `skipUserPush` 防重复 |
| ④ | 智能模式误解「切换到沉浸式翻译…对比实用区别」意图 | 用户要**手动切换体验**,模型却做 web 搜索对比报告 | 路由层修正意图(见⑤) |
| ⑤ | 「oiagent 睡着了吗」— 跨扩展控制请求退回 web 搜索答非所问 | 「切换某插件模式」类请求无确定性路由,落进 LLM 慢路径→web 搜索 | router.js 加 **cross_extension 关键词路由**(零 LLM 拦截)→ `browser_introspect/cross_extension` → 如实回答「**做不到**(安全铁律:一个扩展不能改另一扩展)+ 手动指引」 |

**关键技术点**
- 排除规则收窄:`(本|我的|咱的|自己的|这个).{0,4}(插件|扩展|翻译)` 才排除(本扩展状态走 translate_status);此前 `我.{0,4}插件` 把「帮我把**某插件**关闭」里的"我"误当"本插件"而漏判。
- 测试方法:routeInput/startRename/renderConvList 是 **IIFE 局部函数**,页面全局访问不到——改用 **DOM 行为断言**(触发 convbar → 断言 .del/.rename-in 出现)与**数据层断言**(CT_CHAT_STORE),不读源码字符串。

---

## 方向调整:浏览器代行从「只读」扩到「写操作」(2026-08-13 用户提出并拍板)— ✅ CW-2 已实现

**用户新定位**:浏览器 = 互联网智能操作系统。oiagent 应能像本地 agent 联网搜 skill/装 skill/卸 skill 那样,**代用户**:
- 联网**搜相关插件**、**安装**插件、**切换**用户指定的插件、**评估并卸载**不用的插件;
- 乃至**操作本扩展自己**:填入新模型厂商端点、拉取模型列表和 key。

**用户拍板(AskUserQuestion 四项全决)**:
1. management 写操作(启停/卸载插件)→ **放开,opt-in + 二次确认**。
2. 本扩展自操作(填端点/拉模型/key)→ **放开,key 不落 LLM 上下文**。
3. 联网搜插件+引导安装→ **引导式:搜到+跳 CWS 你亲手点装**。
4. 排期→ **先做写操作代行**,再做 securedm(P1)。

**CW-2 已交付(嵌套仓 9eafbc9,回归 17/17 PASS,既有回归全过)**:
新增 6 个白名单动作,全部走「白名单 + schema 校验 + 确认卡(扩展侧)+ 审计」:

| 动作 | 级别 | 说明 |
|------|------|------|
| `extension_set_enabled` | L1 | 启/停已安装扩展(management.setEnabled),opt-in + 确认卡,名称模糊解析(排除本扩展、多义回候选) |
| `extension_uninstall` | L1 | 卸载已安装扩展(management.uninstall),同样授权+确认 |
| `config_set_endpoint` | L1 | 本扩展填 baseURL(+model/engine),只写 storage,不含 key |
| `config_set_key` | L1 | 本扩展存 API Key(**不回显/不进 LLM/不落持久化**) |
| `config_list_models` | L0 | 复用 engines.listModels 拉模型清单,只列名 |
| `plugin_search_install` | L0 | 联网搜插件,尽量解析到**具体 CWS item 详情页**,引导用户亲手点装 |

**红线落实(关键)**:
- **key 隔离**:NTP routeInput 识别 key 模式(sk-/eyJ/长 token)→ `chrome.storage` 直存,pushMsg 只记「已配置(未显示)」;审计 `_maskParams` 把 apiKey 打码 `***(N chars)`;确认卡/结果 md 不回显明文。E2E 三处断言全过。
- **确认卡泛化**:`_agentConfirmPreview` 统一产 `summary`,NTP `renderConfirmCard` 渲染(书签逻辑迁移,行为不变)。
- **cross_extension 升级**:能做启停/卸载 + **仍做不到**改另一扩展内部模式(沉浸式翻译只译文),两层如实告知。
- **不擅动**:授权后真实启停/卸载/安装插件由用户手动验收(需手势),E2E 不动真实扩展。

**E2E 证据**:`tests/_cw2_write_ops_e2e.py` 17/17(路由分流/确认卡泛化/key 不回显/审计打码/名称解析排除本扩展/授权门/cross_extension 两层/安装引导含 CWS item 页链接——实跑到 `chromewebstore.google.com/detail/immersive-translate.../bpoadfkcbjbfhfodiogcnhhhpibjhbnh`)。
**既有回归全过**:I-1 4/4、I-2 3/3、I-3 3/3、I-4 5/5、P0.6 二轮 8/8(R5 断言随能力边界更新)。

**待用户手动验收**:① NTP 说「停用沉浸式翻译插件」→ 确认卡 → 真停用(再启用恢复);②「卸载某插件」→ 确认 → 真卸载;③「配置端点 X 模型 Y」「配置 key」「拉取模型列表」→ 验证端点通;④「帮我找个广告拦截插件」→ 跳 CWS 亲手装。

---

## CW-2 实测暴露的 6 项缺陷修复(2026-08-13,嵌套仓 b87f7c5)

用户手动验收 CW-2 时暴露 6 项缺陷,全部定位修复。回归 `tests/_cw2_write_ops_e2e.py` **27/27 PASS**(新增 R9-R14),既有回归全过(P0.6 round-2 8/8、I-1..I-4 全过)。

| # | 实测现象 | 根因 | 修复 |
|---|---------|------|------|
| ① | 卸载「沉浸式翻译」失败:`chrome.management.uninstall requires a user gesture` | **真实浏览器边界**——`management.uninstall` 强制要求用户手势,SW 无法直接调用 | `_agentExtUninstall` 不再调 uninstall,改为 `chrome.tabs.create(chrome://extensions/?id=<id>)` 引导用户亲手点「移除」;返回 `needsManualUninstall:true`,确认卡/结果 md 如实说明「浏览器安全限制,扩展代码不能替你点卸载」 |
| ② | 端点+key 同句只存了 key,端点没写进翻译插件 | `routeInput` 的 key 拦截块只存 `apiKey`,没抽同句里的 URL | key 块同时 `match` URL,一并 `chrome.storage.local.set({apiKey, baseURL, engine})`;pushMsg 提示「端点已写入」 |
| ③ | 「配置模型agnes-2.0-flash」变成问答而非动作;「配置模型<agnes-2.0-flash>」误走 config_set_endpoint 报 bad_baseURL | router 无「只切模型」分支,笼统「配置」被 LLM 判成 chat 或误配端点 | 新增 `config_set_model` 动作(只改 model 不动端点/key);router 区分:含 URL→config_set_endpoint / 只给模型名→config_set_model / 「拉取模型列表」→config_list_models |
| ④ | 智能模式每句都要重新点;普通模式切会话后用户消息丢失(回答还在) | (a) 提交处理器发完即 `setAgentMode(false)`;(b) `persistThread()` 只写会话快照,正常模式失败/空结果分支从不 pushMsg user 落档 | (a) `setAgentMode` 持久化 `oiAgentMode` 到 storage、启动读回、提交后不再自动关;(b) `ask`/`askVision`/`doDeepResearch` **入口即 pushMsg('user')+persistThread**,失败/catch 分支补 assistant 占位 |
| ⑤ | 智能模式答文件上传问题给的是能力清单(普通模式答得好) | 智能模式 chat 回退不注入产品知识(普通模式走 askBody 有注入) | **本轮未修**(产品知识注入不对称),记入 backlog 待修 |
| ⑥ | 「帮我找沉浸式翻译插件」回 cross_extension 能力清单,没跳 CWS | router 无「找插件」分支,落进 crossCtl/LLM | router 新增「找/搜/装/推荐插件」分支(**优先于 crossCtl**),剥壳提取真实插件名(去「帮我/找/一个/插件」)→ `plugin_search_install` 跳具体 CWS item 页 |

**实测到的 3 个真实浏览器边界(诚实记录,不假装能绕过)**:① `management.uninstall` 需用户手势;② CWS「添加至 Chrome」需用户亲手点(Google 强制,无 API);③ 改另一扩展**内部设置**(如沉浸式翻译只译文模式)无 API。

**E2E 证据**:`tests/_cw2_write_ops_e2e.py` 新增 R9(找插件/配模型/拉模型/带URL配端点路由)、R10(config_set_model 只改 model)、R11(卸载引导手动不静默)、R12(端点+key 同句写端点)、R13(智能模式持久化+不自动关)、R14(普通模式入口落档)。

**仍待用户手动验收(真浏览器重测 6 条流)**:①卸载引导跳扩展页亲手卸;②端点+key 同句后翻译插件端点真生效;③「配置模型 X」真切模型;④智能模式点一次长期有效+普通模式切会话不丢消息;⑥找插件跳 CWS item 页。

**遗留(记入 backlog)**:智能模式 chat 回退不注入产品知识(⑤后半「智能模式不那么智能」)——智能模式应复用 askBody 的产品知识注入,待修。

---

## CW-2 三轮实测缺陷修复(2026-08-13,嵌套仓 2cae768)

用户验收通过 ④智能模式持久化、普通模式切会话不丢消息、⑥找插件、①卸载引导;再暴露 ②⑦ 两项解析 bug + 要求修 ⑤。回归 `tests/_cw2_write_ops_e2e.py` **32/32 PASS**(新增 R15/R16),P0.6 round-2 8/8、路由 badcase 3/3。

| # | 实测现象 | 根因 | 修复 |
|---|---------|------|------|
| ② | 「配置端点 https://openrouter.ai/api/v1.配置key:sk-…」端点写成 `https://openrouter.ai/api/v1.配置key:sk-…`(把 key 吞进 URL) | URL 正则 `[^\s<>"')]+` 含 `.` `:` `中文字符未排除`,贪婪匹配越过英文句号把后面的 key 全吞 | URL 正则改合法字符集 `[A-Za-z0-9\-._~:/?#[\]@!$&'*+,;=%]+`(在中文/英文句号/逗号处停)+ 去尾句点;`routeInput`(ntp.js)与 `router.js` **两处统一** |
| ⑦ | 「配置模型 \<openrouter/auto-beta\>」配成 `openrouter`;「moonshotai/kimi-k3」配成 `moonshotai` | `cfgM` 模型名字符类 `[A-Za-z0-9_\-\.]` **缺 `/`**,斜杠模型名被截成斜杠前前缀 | 字符类补 `/` + 前缀补「到/为/成」(切换模型到 X);带 URL 句 model 优先取 URL 后「模型 X」、排除 URL 路径段与 key 误捕;`_agentCfgSetModel` 加校验只许 `[A-Za-z0-9 - _ . /]`,拒含空白/中文/冒号——防残缺名落盘 |
| ⑤ | (上轮记为「智能模式不注入产品知识」) | **实测:不对称不存在**——SHORT/DETAIL/附件字段在普通与智能模式**同一 handleChatAsk** 均注入(E2E `attachHasShelf/attachHasDetail/attachHasFields/shortHasShelf` 全 true) | 无需改代码。智能模式「不智能」更可能源于当次模型/检索噪声,非注入缺失 |

**E2E 证据**:R15(②⑦ 路由:斜杠模型名完整/端点不吞 key/带 URL 句取 URL 后模型名)、R16(model 校验:中文名拒写 bad_model、合法斜杠名正常落盘)。

**仍待用户手动验收**:②端点+key 同句后翻译插件端点真生效(此前你拆两次发才成功,现在一句即可);⑦「配置模型 openrouter/free」配全名不再是 openrouter。

**注**:你当前存储里 `model=moonshotai`、`engine=google_gtx` 是之前手动测试的残留(非本轮代码写入,我的 E2E 均恢复原值)。建议真浏览器里说「配置模型 openrouter/free」(或你要的全名)纠正 model,engine 在下次「配置端点 <URL>」时会自动重置为 openai_compat。



---

## 新窗接续重设计 + 对话页设置按钮修复(2026-08-13)

### 设置按钮 404(嵌套仓 6649475)
对话页右上 ⚙ `href="options.html"` 是相对路径,在 `src/ntp/` 下解析成不存在的 `src/ntp/options.html`(ERR_FILE_NOT_FOUND)。真实设置页在 `src/options.html`(manifest `options_ui` 声明)。改 `../options.html`,实测 200。

### 新窗接续重设计(嵌套仓 44560df)
用户指出四点设计反了,全部对齐其「开新标签=新窗口 / 标题栏=切换 / 快爆=新窗接续」模型。**用户两拍板**:①新标签页默认开新对话;②上下文快爆自动截断+提示接续;③(追问确认)「自动开新窗注入」做成默认。

| 项 | 原状(反直觉) | 改后 |
|----|------------|------|
| 新标签页 | 复用最近非空会话(接着上一个窗口) | **默认开新对话**(复用空会话/新建)。同标签页刷新仍恢复原会话不丢。回旧对话点标题栏 |
| 标题栏「接续」 | 名字叫「接续」实为切换,与真接续混淆 | 改名「**切换**」 |
| 新窗接续 | 只复制提示词让用户手贴 | **自动开新窗注入**(默认):压摘要(规则/LLM)→ 新建会话 → 防注入包装当第一条注入 → 自动切换。复制提示词留作后备 |
| 上下文防爆 | 只 75% 提醒,真超就端点 4xx | **自动截断发给模型的 context**(保首条任务目标+最近N条)+ system 提示。**只截 context 不动持久化存档**(本地优先不丢红线) |

**obsidian 中转辨析**:用户问 oiagent 要不要打包 obsidian 做中转(类比 Claude Code 跨会话落盘)。结论:**不需要**——Claude Code 靠 obsidian 是因每次会话是全新进程无共享内存;oiagent 所有会话本就存 `chrome.storage.local.oiThreads`,SW 随时可读,中转层就是 chatstore 自己,交接摘要直接内存压→注入新会话即可。

**E2E**:`tests/_handoff_redesign_e2e.py` 5/5(新标签开新对话/「切换」改名/开新窗注入按钮/摘要防注入当第一条/context 截断);I-4 持久化 5/5、P0.6 round2 8/8 无破坏。

---

## 四轮实测修复:新标签session泄漏 + 主动接续/导出入口 + oiagent自我身份(2026-08-13,嵌套仓 f016e95)

用户验收确认「切换」改名成功;再暴露新标签仍接旧对话 + 提出接续入口前置、导出MD、oiagent自我认知缺失。

| # | 实测现象 | 根因 | 修复 |
|---|---------|------|------|
| ① | 新开标签页**仍接着相同对话**(新窗口不新) | `chrome.storage.session` 在 MV3 里**全浏览器共享**(非 per-tab):旧标签写的 `oiConvId` 被新标签读到,`sess.oiConvId` 非空 → 跳过上一轮改的 `!cid` 新对话分支 | 改用 **URL 参数**标记会话归属:`?conv=<id>`(同源恢复:刷新/切回,由本页 `history.replaceState` 写入)/ `?new=1`(显式新对话);**无标记 = 浏览器新开的干净标签 → 一律开新对话**,忽略 session。同源刷新经 URL 标记仍恢复原对话不丢 |
| ② | 没看到「接续」入口(对话短没触发上下文提醒) | 接续只在上下文快爆提醒条里出现 | 「⇢ 接续」按钮加到「+新对话」旁,**随时主动点**开整理面板,不必判断快爆 |
| ③ | 导出 PDF/MD/DOCX/分享都没有 | 未实现 | 落地**导出 MD**(计划中功能):`exportConversationMd()` 拼 问/答/来源 引用 Blob 下载,无需 downloads 权限。PDF/DOCX/分享后续 |
| ④ | 问「你是谁/帮助操作浏览器的智能是谁」oiagent 答非所问(报底层 Agnes-2.5-Flash / 只搜网页) | product_knowledge 只有产品系没有 **oiagent 自身身份**;且 system「没有来源不要说」逼模型去搜网页 | product_knowledge 加 **IDENTITY 块**(你运行在 OIagent=babelspan 浏览器智能体,对外身份是 OIagent 不是底层模型);SHORT 补**隐私哲学**(本地优先/默认不上云/不要账号/端点key自配);system 加**身份例外规则**(问 OIagent/babelspan 自身直接依背景知识答,不必挂 [n]) |

**E2E**:`tests/_freshtab_identity_e2e.py` **5/5**(全新标签带旧 session 仍开新对话 / 同源刷新仍恢复 / 接续+导出按钮在 / 导出 md 含问答来源标题 / 身份+体系+隐私+system 例外)。新窗接续 5/5、I-4 持久化 5/5 无破坏。

**仍待用户手动验收**:①新开标签页确认是空白新对话(不再接着旧窗口);②随时点「⇢ 接续」开新窗接续;③「⭳ 导出MD」下载;④问 oiagent「你是谁」「帮助操作浏览器的智能是谁」确认自报 OIagent 身份+认知隐私方案。

## 方向记录:商业化命名 Prisir 一套(2026-08-13 用户提出,待细化)

用户提出商业化命名统一为 **Prisir 浏览器 / Prisir 翻译 / Prisir 智能体**(同品牌名,视觉识别统一)。现状已部分对齐:manifest `name`="Prisir 翻译"、图标 `prisir-mark-*`。
**我的建议(待用户拍板)**:① 主品牌靠 Prisir,「翻译/浏览器/智能体」作产品线后缀(类目词商标辨识度弱,但作后缀无碍);② 底层 agent 运行时保留英文代号(oiagent 或 prisir-agent)便于代码/日志区分。**分两步**:本轮已先把对外身份/自我认知改为 Prisir 体系(不动重资产);下一轮再做 manifest/图标/babelspan.com 站点迁移等重资产统一(涉视觉识别+站点工程,单开细致做)。
**关联网站内容对话 agent**:用户提到 babelspan.com 项目计划里本就有「网站内容对话 agent 服务」方案,oiagent 可简化浏览器智能模式、迁移到站点,作高端付费服务细致打磨——**记为战略方向,本轮不动**,待重资产统一时一并规划。

---

## 五轮:智能协作模式身份直答 + 改名 + 残留清理(2026-08-13,嵌套仓 25397f4)

用户验收:普通模式「你是谁」已成功(自报 OIagent + 认知隐私方案);导出MD成功;但 ① 标题栏出现「I4R...存档里只有回答」疑似 BUG;② 智能模式问「帮助操作浏览器的智能是谁」答非所问(返回一堆浏览器 AI 助手网页)。并拍板「智能模式」改名「智能体协作」。

| # | 现象 | 定位 | 处理 |
|---|------|------|------|
| ① | 标题栏「I4R1786616020 存档里只有回答」、切过去"只有回答" | **非产品 BUG**——是我之前 I-4 持久化测试造的脏数据(`I4R...存档里只有回答` 是测试消息文本,角色=assistant 孤零零一条),残留在真实存储里被标题栏列出 | 清理:删 4 条纯 I4R 残留会话 + 剔除 1 条混入消息;并给 `switchConversation` 加**空会话防御**(空会话提示而非渲染空白)。接力会话(c1168586,标题「接续 · 8/13」)实测 user/assistant 完整正常 |
| ② | 智能(协作)模式问身份 → 落网页搜索答非所问 | 身份问题没被关键词路由盖住,落到 LLM 慢路径被判成网页搜索 | 新增 **product_info**(L0):从 product_knowledge 单一事实源直答(identity/privacy/products 三 topic),零 LLM 零检索;router 加**身份关键词快路径**(放最前),身份/隐私/产品体系确定性拦截,明确要联网的(有哪些搜索途径)不误拦 |
| ③ | 「智能模式」易让用户以为聊天也更智能 | 命名误导期待 | 改名「**智能体协作**」(chip+hint 同步),明确这是代行/多智能体干活入口,普通问答走默认模式 |

**E2E**:`tests/_product_info_e2e.py` **4/4**(身份/隐私/产品体系路由→product_info 且联网搜索不拦截、handler 三 topic 直答、空会话防御在、chip 文案改名);I-2 3/3、CW-2 32/32 无破坏。

**仍待用户手动验收**:智能体协作模式问「你是谁/帮助操作浏览器的智能是谁/数据存哪安全吗/babelspan有什么产品」→ 确认直答 OIagent 身份(不再网页搜索);chip 显示「智能体协作」。

**教训记录**:E2E 造测试数据要带唯一 TAG 且跑完自清理;历史 `I4R...` 残留污染了真实存储被用户看到。后续测试消息统一可识别前缀 + 跑完删净。

## 六轮:Prisir 命名统一 + 视频笔记爆品外宣 + 隐私取舍(2026-08-13,嵌套仓 60ebc59)

用户拍板:① 把项目里所有**对外展示**的 oiagent 统一替换为 **Prisir 智能体**(或代码命名 PrisirAgent),浏览器统一 **Prisir 浏览器/PrisirBrowser**,含规划进浏览器源码的浏览器名;② 问答「babelspan 有什么产品」应改为「Prisir 有什么产品」(产品体系= babelspan 网站 + babelspan-shelf);③ 网页翻译介绍写太细,**视频笔记是爆品功能、藏太深,介绍时要主动推出来**;④ 用户洞察:视频平台开放 API/服务端预生成笔记的"快"可能要跨过我们的隐私红线。

| # | 事项 | 处理 |
|---|------|------|
| ① | 命名统一 | product_knowledge(IDENTITY/PRODUCTS/PRIVACY)、background(system 自称/product_info 三 topic/capabilities)、ntp.html(title/brand/欢迎语/placeholder/「智能体协作」chip)、ntp.js(导出MD 标题/说话者/文件名)、router/registry(product_info 描述)全面 Prisir 化。**代码运行时标识符(storage key `oiAgentMode`、模块名)有意保留不动**以免回归;浏览器源码层命名(PrisirBrowser)记为源码层任务 |
| ② | 产品体系介绍修正 | product_info/products 改为以 **Prisir** 为纲:Prisir 浏览器/翻译/智能体 + **视频笔记(高价值爆品)** + babelspan(网站+内容柜)作内容产品线;ntp.html 欢迎③步同步推视频笔记 |
| ③ | 视频笔记爆品外宣 | 「视频笔记」从产品体系介绍里单独列出、标注为高价值功能(带时间戳、可点击跳转画面的结构化笔记),不再埋在网页翻译细节里 |
| ④ | 隐私取舍写进设计文档 | `docs/video-study.md` 新增 **§9 隐私取舍:平台 API/预生成 vs 本地内容优先**——平台"预生成笔记"的快 = 追踪+聚合单用户观看行为 + 暴露"你在看哪条/何时记笔记",撞「本地优先/不要账号/行为不出机」红线 → **不做**;我们的「快」走隐私等价:内容优先 + 分层处理 + **本地缓存**。§10 记「内容优先」方向(字幕轨→音频转录→帧画面为辅),治 TED 笔记与字幕不相关 |

**E2E**:`_product_info_e2e.py` **4/4**(断言已对齐 Prisir:身份自报「Prisir 智能体」、products 含「Prisir 浏览器」)、`_freshtab_identity_e2e.py` **5/5**(导出MD 说话者标签「🤖 Prisir 智能体」、system 自称「你是 Prisir 智能体」)。

**仍待用户手动验收**:① 问「你是谁/Prisir 有什么产品/视频笔记怎么用」→ 确认自报 Prisir 智能体 + 产品体系含视频笔记爆品;② NTP 品牌行/欢迎语/placeholder 显示 Prisir;③ 导出 MD 说话者为「Prisir 智能体」。

**顺延事项(源码层,非扩展)**:浏览器源码里的浏览器名 → PrisirBrowser;TED/YouTube 播放(anti-bot WAF + Widevine DRM 缺失);视频笔记改内容为主(#39/#42)。

## 七轮:普通模式产品类直答 + 外宣口径扩充(2026-08-13,嵌套仓 87a45b9)

用户实测对话「什么是wEb3」暴露三缺陷,并提两点外宣诉求:① babelspan.com 网站设计很大,但回答只几个字不如搜索引擎详细,**要把可外宣文档做成 Prisir 智能体可调阅的语料**;② 产品体系还有**微信公众号「通天尺规」**(发表过书籍精评),要算进产品线。

| # | 现象 | 定位 | 处理 |
|---|------|------|------|
| ① | 普通模式问「视频笔记怎么用」**完全没响应(no_results)** | `handleChatAsk`(普通模式)本**不走 router**,产品类问题直接落网页搜索;「视频笔记怎么用」搜不到相关来源 → `no_results` 空响应 | `handleChatAsk` 检索前加**产品类确定性拦截**:router 新增独立 `productClass()`(身份/隐私/产品三条抽出复用),命中即 `_agentProductInfo` 直答,零 LLM 零检索。**普通模式与智能协作模式口径统一** |
| ② | 「视频笔记怎么用」智能协作模式回答**公式化**,不是设计好的交互用法 | `_agentProductInfo` 只说"有这个功能",没给操作步骤 | identity/products 回答补**视频笔记交互用法**:打开视频页→点「视频笔记」→带时间戳可跳转笔记→导出 MD;product_knowledge 加 `VIDEO_NOTES_USAGE` 块 |
| ③ | babelspan/产品体系**几个字不吸引**,不如搜索引擎抓的详细 | product_info products 只有一行 dry 列表 | products 补全:**babelspan 使命句**(多语种共建书籍精评/可核对证据/兴趣航道/反爬塔)+ **微信公众号「通天尺规」**(书籍精评长文)+ **Reed(一苇)助手** |

**资料采信**:产品体系/使命句/Reed 均取自 `D:\Projects\rubriclab`(`docs/design/2026-07-26-site-vision-babel-rubric.md`、`catalog/outreach/wechat-v0/brand-naming.md`、`INDEX.md`)——品牌已锁定:站=Babelspan、公号=通天尺规、助手=Reed(一苇)。

**E2E**:`tests/_product_direct_answer_e2e.py` **5/5**(视频笔记怎么用→product_info 直答不再 no_results/你是谁→Prisir 身份/产品体系含公众号+使命句/非产品类 web3·天气不拦截仍走检索/product_knowledge 块齐);`_product_info_e2e.py` 4/4 无破坏。

**待用户手动验收**:普通模式问「视频笔记怎么用」「你是谁」「Prisir 有什么产品」→ 确认直答且含视频笔记步骤、公众号、使命句(不再 no_results/不再几个字)。

**立项(下一步较大)**:**#45 外宣语料库**——把 rubriclab 可外宣文档(site-vision/brand/公众号精评等)做成 Prisir 智能体**可调阅的本地语料**,回答能真正吸引用户访问 babelspan.com。红线:公开描述、本地优先、opt-in、不带账号。先出方案再实现。

## 七轮补:视频笔记怎么用 ≠ 有什么产品(2026-08-13,嵌套仓 a930021)

用户从导出记录发现:问「视频笔记怎么用」返回**整个产品体系**,和「Prisir 有什么产品」一字不差——两问题撞了同一答案。

- **根因**:`productClass`/`keywordRoute` 把「视频笔记」归到 products(产品体系)分支;且上轮虽建了 `VIDEO_NOTES_USAGE` 知识块,却**没给它配独立 topic**,从未被路由到。
- **修复**:拆出独立 topic `usage`(操作指引)——registry enum 加 `usage`;`_agentProductInfo` 加 usage 分支(开视频页→点视频笔记→时间戳跳转→导出MD,**不含产品体系列表**);router 两处同步拆(视频笔记→usage 放最前,产品体系去掉视频笔记关键词)。
- **E2E**:`_product_direct_answer_e2e.py` **6/6**(新增 R6:两问题回答**必须不同**;R1 视频笔记→usage 含步骤且非产品体系),`_product_info` 4/4 无破坏。

## 八轮:#45 外宣语料库 M1 落地(2026-08-13,嵌套仓 8fe621d)

用户拍板「可以推进 #45 外宣语料库方案」+ 四决策(M1 纯本地先做/语料全选/babelspan host 权限接受走 opt-in/生成器+人工审)。本轮交付 **M1 纯本地内置语料**。

- **痛点**(七轮 ③④):babelspan.com 设计很大,但智能体介绍仅几个字,「还不如传统搜索引擎抓的详细」,吸引不了用户访问;外宣文档没有可调阅的地方。
- **结构**:`extension/src/agent/outreach_corpus.json` 14 条精选 entry——使命/反爬塔(海图非排行榜)/可核对八维评分/公众号通天尺规+精评样例×3(狂人日记·阿Q正传·东野圭吾106部谱系)/babelspan-shelf 书柜/品牌命名(站·公号·Reed)/视频笔记/翻译/智能体/浏览器/隐私。每条 `{id,title,tags,url,body}`,**链接全 babelspan.com**,E2E 校验零密钥值/端点/内部标识。
- **检索**:`outreach.js` `CT_OUTREACH.retrieve(query,n)` 确定性关键词路由(同义词归一→子串计分→tag 精确命中加权),top-N 由 `format()` 拼成「📚 深入了解:」md 块(title+可点链接+body≤90字),挂在 `_agentProductInfo` 回答尾。零 LLM、零向量、零联网。
- **关键修复(MV3 载入)**:初版 `_loadBuiltin` 用同步 `fetch().json()`——但 classic SW 里 `importScripts` 同步、`fetch` 却返回 **Promise**,`res.ok` 拿到 undefined → 语料载入 0 条,retrieve 全空。同步 XHR 在 MV3 SW 同样被禁。**正解**:语料转成 `outreach_corpus.js`(`self.CT_OUTREACH_CORPUS={...}`)走 `importScripts` 同步载入,与 langs/prompts/engines/registry 同一模式;`retrieve()` 保持同步,`background.js` importScripts 链加在 product_knowledge 之后。JSON 留作单一事实源供 M2 生成器维护。
- **E2E**:`tests/_outreach_corpus_e2e.py` **5/5**(载入14条/关键词路由 gzh·vnotes·mission 命中且无关查询空/product_info 带📚块/普通模式整链路含可点 babelspan 链接/语料纯公开);回归 `_product_direct_answer` 6/6、`_product_info` 4/4、`_agent_delegate`、`_cw2_write_ops` 32/32 全绿(顺手把 delegate 测试里 `REGISTRY 动作数==4` 的 M7a 硬编码改为 `>=4`——CW-2 后已 14 个动作,纯环境陈旧断言非本次回归)。
- **红线守住**:只放公开外宣内容、本地优先、retrieve 不联网、无敏感串;L2 在线刷新(opt-in + babelspan host 权限)与 M2 生成器后续期。

**待用户手动验收**:开新标签问「Prisir 有什么产品」「视频笔记怎么用」「babelspan 是什么」→ 确认回答尾部带「📚 深入了解」+ 可点 babelspan.com 链接(关于/功能/精评页),内容比几个字的预设简介更具体、更能引人进站。

## 八轮补:产品体系补 Prisir密信 + Prisir钱包(2026-08-13,嵌套仓 b82bf5e)

用户指出漏了两条**浏览器杀手锏**:匿名加密通信(两人/多人群聊·语言/视频/屏幕共享/文件传送加密签名)与可自选加载的加密钱包;并拍板**匿名加密通信也挂 Prisir 品牌名组合**。

- **命名(用户拍板)**:匿名加密通信=**Prisir 密信**;可选加密钱包=**Prisir 钱包**。
- **product_knowledge PRODUCTS** 加 ⑤Prisir 密信(端到端加密群聊+音视频+屏幕共享+文件加密传输带签名,不依赖中心账号)⑥Prisir 钱包(可选加载·独立口令·本地管理),编号 ①~⑧。
- **语料**加 sechat/wallet 两条 entry(16 条);outreach.js SYNONYMS 加 加密通信/加密钱包 归一。
- **_agentProductInfo products 分支**同步补两行(它是内联 markdown 模板,不直接读 PRODUCTS——这是与 product_knowledge 并存的第二处口径,改动需两边同步)。
- **E2E**:outreach_corpus 5/5(R1 16条+R2 加 sechat/wallet 路由)、product_direct 6/6(R3 加 hasSechat/hasWallet)、product_info 4/4 无破坏。

## 九轮:read_page_tab — 智能体读当前/指定页正文喂模型出表(2026-08-13,嵌套仓 1b8dafe)

用户实测(导出 trending 对话):让智能体「读 GitHub Trending 前十项目出表」,**虽已提前打开 trending 页,智能体仍无法完成**——退到联网检索,而 trending 是动态渲染(JS 拉榜单)静态检索抓不到 → 诚实说「无法」。且它嘴上说「我可以代行打开读取」实际白名单没这动作,**说能做、实际做不到**,违诚实红线。

- **根因**:14 个代行动作里**没有「读标签页正文」的动作**(translate_page=整页翻译/browser_introspect=体检/product_info=答自家产品),用户已打开的页够不着。
- **方案(用户拍板「加读当前页动作」)**:新增 `read_page_tab`(L0)。这是 **P4(CW-3 跨 tab)第一步**。
- **实现**:registry 加动作(url?/focus?);content.js 加 `read-page-text` 分支(article/main 优先,剔 script/style/nav 等噪音+隐藏元素,折叠空白,截断 ~6000 字);background `_agentReadPage`——有 url 新开隐藏 tab 等 complete+渲染缓冲→读→**finally 关临时 tab**(呼应 #40 收口),无 url 用活动页+受限页判定;读到正文**直接调 chatText 整理**(不触发 web 检索),只基于正文答、不编造,空页诚实回 empty_page;router 加读页关键词分支(读/打开/看看+页/网址/出表/前十/榜单),抽 url+focus。
- **诚实性修复**:capabilities 与 identity 口径补「读取你当前打开或指定网址的网页正文并整理(动态渲染页如 github trending 也能读)」——动作落地后这句才为真。
- **红线守住**:只读活动页/新开指定页,**不枚举其它已开 tab(零 tabs 权限)**;正文只经自配模型端点,不落盘、不进持久化原文。
- **E2E**:`tests/_read_page_tab_e2e.py` **7/7**(路由含 url/focus、读指定URL页模型整理、新开临时tab读完即关 tab 数回落、受限页判定、真实页正文可抽取);回归 product_direct 6/6、product_info 4/4、delegate、cw2 32/32 全绿。

**待用户手动验收**:真实 github.com/trending(动态渲染)开新标签说「读一下当前页面前十项目出表」→ 确认能读出真实榜单并整理成表(项目名/简介/语言/星数)。

## 十轮:修 restricted_page(NTP盲点)+ 翻译失败日志 trLog(2026-08-13,嵌套仓 cffa647)

用户刷新 trending 后在**新标签页**开「智能体协作」说「读一下当前页面,前十项目都有什么,出个表」→ 直接没回复,跳「代行失败 / failed — restricted_page」。同时发现 trending 页面样式被**翻译插件的思考模型**破坏、多条翻译失败,却**没有失败日志可查**,无法归因到哪个模型/哪批。

### ① restricted_page 根因:NTP 盲点
「智能体协作」输入框在**新标签页(NTP)**上。用户在 NTP 里发问时,**NTP 自己就是活动 tab**(chrome://newtab 是受限页)。`_agentReadPage` 走活动页分支 → `_activeTab()` 返回 NTP → 命中受限页判定 → 抛 restricted_page。但用户想读的「当前页」是他**刚看过的那个 trending tab**,不是 NTP 自己。

**修**(`background.js _agentReadPage` 活动页分支):检测到活动 tab 是受限页时,**fallback 到 `lastAccessed` 最近的真实 http(s) tab**——「当前页」应=用户最近看的那个网页,不是 NTP 自己。

```js
tab = await _activeTab();
if (tab && /^(chrome|edge|about|chrome-extension|moz-extension|devtools):\/\//.test(tab.url || '')) {
  const all = await chrome.tabs.query({});
  const web = (all || []).filter((x) => x.url && /^https?:\/\//.test(x.url) && x.id != null)
    .sort((a, b) => ((b.lastAccessed || 0) - (a.lastAccessed || 0)));
  if (web.length) tab = web[0];
}
```

### ② 翻译失败此前无持久日志
trending 样式被破坏 + 多条翻译失败,但 `reportProgress` 只存**瞬态** `_ct_progress`,没有持久失败记录、没有模型归因——查不到是哪批、哪个模型、哪个端点出的问题。

**修**(`content.js`):新增 `_logTranslateFail`——批次失败时落 `trLog`(**本地环形缓冲,最多 200 条**),每条记:
- `ts`(时间)、`url`(页面,截 200)
- `engine`、`model`(归因到具体模型)
- `host`(端点主机名,**不含路径与 key**)
- `n`(失败条数)、`error`(原因,截 300)、`sample`(原文样例,截 120)

**红线守住**:本地优先、不上云、可关(复用 `collectBadcases===false` 开关);host 只留主机名不含路径/key,不落敏感信息。

### 意义:先有日志,才能答「推荐模型要指定具体型号」
用户提的方向——「推荐模型页面要具体指定用哪个模型型号,或直接推荐模型厂商的任意模型要在插件上做开发调整」——**前提是先能看到失败记录**。trLog 落地后,用户/开发能看到「trending 这批失败是哪个 engine+哪个 model+哪个 host 出的」,才有依据决定:是该在推荐页钉死具体型号,还是插件侧做「推荐厂商任意可用模型」的适配。**这是该决策的前置,不是决策本身**——型号指定/厂商任意模型的开发调整是新功能,待拍板后另做。

### E2E / 回归
- `tests/_read_page_tab_e2e.py` **8/8**(新增 R6:NTP fallback 选最近真实 http tab 断言)。
- 回归:read_page 8/8、product_direct 6/6、product_info 4/4、delegate、outreach 5/5、CW-2 32/32 全绿。

**待用户手动验收**:① 刷新 trending 后在 NTP 发「读一下当前页面前十项目出表」→ 应能读到 trending(不再 restricted_page);② trending 翻译若再失败,可在扩展存储 `trLog` 里查到失败批次 + 模型 + 端点。
