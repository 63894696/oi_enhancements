# ADR-002 — FastLane 产品线:云端优先 / 体验为先

- **状态**:Proposed
- **日期**:2026-07-02
- **依赖**:ADR-001 决策架构(双 daemon + orchestrator + SAPI TTS placeholder)
- **不依赖**:不依赖 ADR-003

## 1. 一句话定位

> **「按住热键 → 3 秒内高质量回复」**。用户接受音频 / 文本上云,优先响应质量、识别准确度、TTS 自然度。

## 2. 隐式目标用户画像

- 一个人,**他自己**。
- 时间敏感,**愿意为响应速度 / 准确度让渡隐私**。
- 不会用此工具讨论商业秘密 / 密码 / 身份证号 / 财务信息。
- 接受实名 / 手机号绑定的云服务。

## 3. 决策一览

| 编号 | 决策 | 选项 |
|---|---|---|
| F-1 | ASR 引擎 | **云端优先**:Whisper API / 阿里 Qwen ASR / 火山豆包流式 2.0 / OpenAI Whisper |
| F-2 | LLM(OI 后端) | **云端优先**:Qwen-Max / DeepSeek-V3.2 / Claude Sonnet 4.6 / GPT-4o,**质量优先** |
| F-3 | TTS 引擎 | **云端 + 本地混合**:Edge TTS(免费,微软走云)/ BAILIAN CosyVoice / MiniMax TTS / Windows SAPI 兜底 |
| F-4 | IM 通道 | 微信 / 钉钉 / 飞书 / Slack / 企业微信(原厂客户端,**不强求 E2EE**) |
| F-5 | 失败降级 | **自动降级**:ASR 失败切下一个 ASR 服务;LLM 失败切更便宜模型;TTS 失败降级到 SAPI |
| F-6 | 网络策略 | **任意**,**接受云端调用**,但**强制 HTTPS + TLS 1.3** |
| F-7 | 启动速度 | 优先,daemon 启动时**预热连接到云端**(预 ping / token 缓存) |
| F-8 | 注册 / 实名 | 接受(每个云服务按服务方要求实名 / 手机号) |

## 4. 决策详情

### F-1:ASR 引擎 — 云端优先

**默认**:火山豆包流式语音识别模型 2.0(中文 + 中英混读最强,延迟低,**20 小时/月免费额度**)

**备选**(自动切换顺序):
1. 阿里 Qwen ASR(中文,大厂可靠)
2. OpenAI Whisper API(英文强,**但中文弱**)
3. **本地 SenseVoice Small 兜底**——**关键**:即使 FastLane 也保留本地兜底,**避免网络完全断时不能用**

**为什么不是单选某一家**:
- 单点故障 + 单家定价变化,**多档备选符合 FastLane 的「不中断」哲学**。
- 不同 ASR 对不同语种 / 方言 / 领域词有强弱差异,**多档覆盖更广**。

**触发再讨论**:
- 某家 ASR 价格上涨 / 服务降级
- 出现新的 SOTA ASR

### F-2:LLM(OI 后端)— 云端优先

**默认**:Qwen3-Max / DeepSeek-V3.2 / Claude Sonnet 4.6,**三选一**(OI 进程配置决定)。

**为什么不是 GPT-4o / Claude Opus**:
- **质量 ≈ Qwen-Max / DeepSeek-V3.2**(中文场景下实测 Qwen/DeepSeek 还常反超)
- **价格低 5-10 倍**——自用,不烧钱
- **Claude Opus / GPT-4o 留作「重要任务临时切」**——不绑死

**OI 进程配 LLM 是用户责任**——FastLane 的 voice_input 不锁死某家。

**触发再讨论**:
- Qwen / DeepSeek 大幅涨价 / 服务降级
- 出现明显 SOTA 突破

### F-3:TTS 引擎 — 云端 + 本地混合

**首选**:Edge TTS(微软 edge 浏览器的免费 TTS,**走云端但免费**,声音自然度远超 SAPI)。

**备选**:
1. BAILIAN CosyVoice(中文 TTS 强,需付费 token)
2. MiniMax M3(speech-2.6-hd,声音好,需付费)
3. **Windows SAPI 本地兜底**——网络断时用,生硬但能用

**为什么不锁单一**:
- 不同 TTS 引擎声音特征不同(男女声 / 老少声 / 风格),**OI 可能想动态切**(今天用女声,明天用男声)
- 价格分层:免费 Edge TTS → 付费 CosyVoice → 免费 SAPI

### F-4:IM 通道 — 原厂客户端

**支持列表**:微信 / 钉钉 / 飞书 / Slack / 企业微信 / Telegram(注意:Telegram 默认非 E2EE)。

**实现方式**:
- **不重新发明 IM 协议**——直接调用各 IM 的桌面客户端 API / 自动化库(wechaty / dingtalk SDK / feishu SDK / slack-sdk 等)
- **用户选哪个就配哪个**,**不强制**

**隐私边界**:**FastLane 不承诺 IM 消息端到端加密**——微信 / 钉钉的服务器可以看到消息内容。**这是用户主动选择 FastLane 时已经接受的 trade-off**。

### F-5:失败降级 — 自动降级

| 失败 | 自动降级路径 |
|---|---|
| 首选 ASR 超时 / 5xx | 切下一个 ASR 服务 |
| 所有云 ASR 失败 | 兜底本地 SenseVoice Small(可在 config 关掉) |
| 首选 LLM 超时 / 5xx | 切下一个 LLM |
| 所有云 LLM 失败 | 兜底本地 Ollama(可在 config 关掉) |
| 首选 TTS 失败 | 切下一个 TTS |
| 所有 TTS 失败 | SAPI 本地 |

**降级时日志明示**:「FastLane 降级:首选 Qwen-Max → DeepSeek-V3.2,原因:HTTP 504」

### F-6:网络策略 — 强制 HTTPS / TLS 1.3

- 所有云端调用走 HTTPS,**强制 TLS 1.3**(代码层 `ssl.SSLContext` 强制)
- **不允许 HTTP**——任何明文 HTTP 请求 → daemon 拒绝执行
- **不允许自签证书 / 跳过证书校验**——代码禁止 `verify=False`

### F-7:启动速度 — 预热连接

- daemon 启动时,后台线程并发对所有配置中的云服务做:
  - DNS 解析
  - TLS 握手
  - Token 刷新
  - 健康检查 `GET /health`
- 预热结果缓存,用户首次按热键时**已无网络握手延迟**。
- 预热**不发送用户数据**,只 ping。

### F-8:注册 / 实名

- 接受(用户自己配云服务时按服务方要求实名)。
- FastLane 不收集实名信息——实名发生在云服务那边,不在我们这。

## 5. 仓库布局(独立仓库)

```
C:/Users/Administrator/voice_input_fastlane/
├── docs/
│   └── adr/
│       └── ADR-002-fastlane-cloud-first.md   ← 本文档
├── src/voice_input_fastlane/
│   ├── config.py
│   ├── asr_cloud/
│   │   ├── doubao_streaming.py
│   │   ├── qwen_asr.py
│   │   ├── openai_whisper.py
│   │   └── sensevoice_local_fallback.py
│   ├── llm_cloud/
│   │   ├── qwen.py
│   │   ├── deepseek.py
│   │   ├── claude.py
│   │   └── ollama_local_fallback.py
│   ├── tts_cloud/
│   │   ├── edge_tts.py
│   │   ├── bailian_cosyvoice.py
│   │   └── sapi_fallback.py
│   ├── im/
│   │   ├── wechat.py
│   │   ├── dingtalk.py
│   │   ├── feishu.py
│   │   └── slack.py
│   └── [继承 ADR-001 的 daemon 骨架]
├── scripts/
│   ├── prewarm_connections.py
│   └── health_check_all.py
└── README.md
```

## 6. 隐私边界声明(FastLane 版)

### 6.1 上云的数据(用户已知)

- 音频字节流 → 云 ASR
- ASR 文本 + 屏幕内容 + 历史记忆 → 云 LLM
- OI 回复文本 → 云 TTS
- IM 消息内容 → IM 服务方服务器(微信 / 钉钉等)

### 6.2 不上云的数据

- 全局热键状态 / 麦克风静音状态 / 文本注入操作 → 仅本机
- auth_token / 配置 / 日志 → 仅本机

### 6.3 用户控制

- 用户**完全控制**选哪家云服务、什么时候上云、要不要 fallback
- **完全控制 OI 进程配什么 LLM**(可临时切到本地 Ollama,即使在 FastLane 模式)

## 7. 触发再讨论

| 触发 | 重新讨论 |
|---|---|
| 某云服务大幅涨价 | 重选默认 |
| 用户开始用此工具讨论敏感信息 | **建议切到 GhostLine**——FastLane 不适合敏感场景 |
| 某云服务被曝数据泄漏 | 重选或暂离 FastLane |
| 用户新增云端资源(如自有 GPU + 本地模型) | 加进 fallback |

## 8. 与 GhostLine 的差异

| 维度 | FastLane | GhostLine |
|---|---|---|
| **核心承诺** | 3 秒响应 | 零外发 |
| **失败语义** | 自动降级 | 不工作 |
| **用户责任** | 选云 + 实名 + 接受服务商数据策略 | 配本地 / 自建 + 接受体验降级 |
| **隐私承诺** | 数据上云,服务方按其隐私政策处理 | **数据不上云** |
| **同台机器能同时跑吗** | **能**(端口不冲突即可) | **能** |

## 9. 关键约束(用户 review 重点)

1. **多云服务管理** = 多套账号 + API key + 实名——你**已经接受**这种成本?memory 里你已经有 BAILIAN / STEPFUN / BIGMODEL / SILICONFLOW 等多套 API key(自取自用策略),FastLane 沿用这个模式。
2. **预热连接 = 后台常驻网络活动**——daemon 即使不在语音输入,也会有定期心跳 / health check。如果你在意「闲置时段网络静默」,**FastLane 不适合**。
3. **本地兜底 SenseVoice / Ollama 仍需要**——避免完全断网时 100% 不可用。**FastLane 的「纯云端」是 false choice**,我会强制保留兜底。