# 交接:M3 编译批次 — 香港强实例执行窗(2026-08-22)

> 你是接续窗口。上一窗口已完成编译前所有材料核验与拍板前置,你的唯一主线是**按施工单把 M3 编译跑完并释放实例**。先读完本文件再动手。

## 0. 开工前必读(按顺序,都在 repo `C:\Users\Administrator\oi_enhancements`)

1. **施工单(权威顺序+验收)**: `docs/prisir-m3-compile-workorder-2026-08-22.md` — P0→P5 全流程,这是你的施工图。
2. **架构+检查清单**: `docs/prisir-browser-compile-architecture-2026-08-20.md`(尤其 §6.1 出包清单,含 VT 自检)。
3. **各子项契约**(P3 接线时按需查): #58 融合版、#69 ⋮菜单、findex、mixin/forum/content-cabinet 等契约文档在 `docs/`。
4. **memory**: `prisir-m3-compile-workorder.md`(含海外/国内实例可行性已否决结论)。

## 1. 用户已拍板的现状(勿重查、勿推翻)

- **用香港实例,不换 region**。海外(最低吉隆坡 ¥16.10)与国内(¥7.36 但 GFW 墙死 googlesource+CIPD)都已实测否决。维持 cn-hongkong。
- **图标用 A 深色方底不透明**(B 透明化已交付被用户否决并全删)。正式图标 = `assets/prisir-logo-*` + `prisir-logo-solid-*`(同一不透明版),已提交 `a0b7cb4`。编译期品牌层直接用这套,不要再透明化。
- **双 agent 任务移交已落地**(#90,提交 47a0550 + 嵌套 ea0bb69):浏览器→壳 `/shell_task` 并行确认卡 + `delegate_local_task` 动作 + 补齐 `agent/pair`、`agent/ack`。结果回浏览器依赖 #58 `_shellChannel` 客户端(遗留,契约占 TODO,不阻塞编译)。
- **预检已过**: 镜像 `m-j6cgwhn89zx36bc1tp8j`(Available,400GB,Win2022,Chromium153 src+obj+ATL+WinSDK26100,C 已扩 400GB,ninja -j48 已验证)、SG `sg-j6c5xtnlr1v54naric40`、vSwitch `vsw-j6chjrio5ijum3ynw1hxl`(zone-d)全部在线同 vpc。

## 2. 你要执行的 P0 起实例参数(已向用户出示,时薪 ¥18.58/h)

```
RegionId           cn-hongkong
ZoneId             cn-hongkong-d
InstanceType       ecs.c8i.8xlarge      (32 vCPU / 64GB)
InstanceChargeType PostPaid             (按时付费 — 硬性,禁 Spot/按量)
ImageId            m-j6cgwhn89zx36bc1tp8j
SecurityGroupId    sg-j6c5xtnlr1v54naric40
VSwitchId          vsw-j6chjrio5ijum3ynw1hxl
SystemDisk         cloud_essd 400GB
```

**但:RunInstances 是写操作+即时计费,执行前必须再次向用户出示以上参数+时薪 ¥18.58/h,拿到「开/确认」才跑。上一窗口已出示过一次,本窗口开工时简短复述确认即可,不要跳过拍板。**

## 3. 安全/操作红线(逐条遵守,来自全局契约)

- **凭证**: aliyun AK/SK 只在 Windows **User 环境变量**,用 PowerShell `[Environment]::GetEnvironmentVariable('ALIYUN_ACCESSKEY_ID','User')` 注入;**值永不进 Git Bash 环境前缀/LLM 上下文/审计明文/日志**。CLI 在 `D:\Temp\aliyun.exe`。
- **Git Bash 坑**: 内联 `powershell -Command "$env:X..."` 的 `$` 会被 bash 吃掉 → **写 .ps1 文件**,用 `powershell -NoProfile -ExecutionPolicy Bypass -File` 跑。
- **CLI JSON 解析坑**: aliyun CLI banner/警告走 stderr,`2>&1|Out-String|ConvertFrom-Json` 会混入非 JSON 报「无效的 JSON 基元」→ 用 `2>$null|Out-String|ConvertFrom-Json` 只留 stdout。参数用 `--region`(非 `--RegionId`)。已有可用脚本 `.tmp_m3_precheck.ps1` 可参考写法。
- **禁区镜像**: `m-j6cg6nxefjl4ujykzlwd`(Linux)绝不动;只用 Windows 编译基 `m-j6cgwhn89zx36bc1tp8j`。
- **资源 ID 纪律**: 密码不落盘/脚本;.env 只放凭证,资源 ID 走 `instance-info.json` + 前缀校验;远端脚本不自杀。
- **实例临时性**: 按量/按时,编译完(P5)必须 DeleteInstance 释放,产物先拷回持久位+外部做快照,绝不留置烧钱。

## 4. 编译主线(照施工单 P1→P5)

- **P1 基线编译门**: 起实例后先跑通基线 ninja 编译链,不通则停,排查后再往下。
- **P2 M-4 libsimplex FFI spike 最优先探活**(唯一可能否决功能的不确定项): 失败则密信 2 人私信降级 Web/壳版,群聊+ML-KEM 照做,不阻塞整批。
- **P3 九项可并行接线**: proxy(5点+B8视频) / agent(M2存储+identity) / mixin(chrome://mixin) / forum(代签) / content-cabinet / findex(薄壳+⋮菜单) / NTP(chrome://agent) / ⋮菜单#69 / 品牌层(删 Google + 用 A 版图标)。
- **P4 §6.1 出包清单**: 每个将分发的可执行产物(installer/exe/各 dll)→ SHA256 → 查 VT → 无记录经显式同意上传 → **0 引擎报毒才放行**,≥1 停发排查。锚点: prisir_findex.dll 已实测 0/75。
- **P5 释放**: 产物拷回持久位 → 外部做镜像 → DeleteInstance → 结算。

## 5. 其它

- 探查纪律: loop_guard 警告/阻断时换参数/换工具或升级给用户,不绕。
- 速度异常(实例卡住/编译远超预期)主动介入接手,不甩锅。
- 有不确定先做完不依赖答案的部分,阻塞性问题才停下来问用户。
