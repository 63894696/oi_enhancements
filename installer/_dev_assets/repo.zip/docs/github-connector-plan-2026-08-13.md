# GitHub 连接器方案 — P3/CW-3 站点写操作(2026-08-13 起草,待拍板)

> 起因:用户想让 Prisir 智能体在 GitHub 建仓(填项目名/备注)、建仓库操作 token 并自动选权限。
> 这属于「站点写操作连接器」,与现在的「读页(read_page_tab)」是不同能力层。本文定方案,**先文档后实现,红线先拍板再动工**。
> 串行链位置:P3(连接器写操作)/ CW-3(跨 tab 编排)的一部分;P1 securedm 之后、或与之并行(待拍板)。

---

## 0. 一句话定位

让智能体在你**已登录的 GitHub 会话**里代行**白名单内的写操作**(建仓/写 issue/star 等),凭证用 **PAT 走 GitHub REST API**(不驱动页面 DOM 碰密码),每个写动作都过**确认卡**、token **永不进 LLM 上下文**。

**核心决策:走 API,不走页面 DOM 自动化。** 理由见 §3。

---

## 1. 能做什么(范围分级)

| 级 | 动作 | 说明 |
|----|------|------|
| **读(L0)** | 列我的仓库 / 读 issue·PR / 搜代码 / 读文件 | 低危,只需 `repo:read` 或 public |
| **写(L1)** | 建仓(名/描述/私有序)/ 写 issue·评论 / star·fork / 改 repo 设置 | 中危,需 `repo` scope,**确认卡** |
| **凭证(L2)** | 建·删 PAT、给 token 选 scope | **最高危,本轮不做自动**,见 §5 |

**用户要的「建仓+填名/备注」= L1「写」,可做;「自动建 token 选权限」= L2,风险极高,建议第一版不做自动、改为引导。**

---

## 2. 凭证怎么管(红线最优先)

**铁律(贯穿全部):token 永不进 LLM 上下文、不落审计明文、不落日志。**

1. **存储**:GitHub PAT 存 `chrome.storage.local`(与现有翻译 key 同机制),字段 `ghPat`。**独立口令加密可选**(复用钱包「独立口令」思路):用户可设一个口令,token 用其派生密钥 AES 加密落盘,内存里用时才解。
2. **不进 LLM**:路由层(NTP routeInput)识别到 `ghp_`/`github_pat_` 前缀的字符串 → **直存 storage,pushMsg 不记、审计 `_maskParams` 打码 `ghp_***(40 chars)`**、md 不回显。模型只能看到「已配置 GitHub token」这个事实,看不到值。
3. **审计**:`CT_AGENT_AUDIT` 记「github_connector: create_repo 名=X」这类**动作+非敏感参数**,**不记 token**。
4. **最小权限**:用户配 token 时,界面**建议最小 scope**(建仓只要 `repo`;只读只要 `public_repo`)。token 页 GitHub 端创建,扩展**不替你在 GitHub 网页勾 scope**(那是 L2,不做)。

---

## 3. 走 API 还是驱动页面 DOM?

| | **REST API(选这个)** | 页面 DOM 自动化 |
|---|---|---|
| 可靠性 | 高(API 契约稳定) | 低(GitHub 改版就碎) |
| 凭证 | PAT header,干净 | 要碰登录态/2FA/密码,危险 |
| 权限边界 | scope 明确 | 拿到的是整个登录会话,权限=用户全部 |
| 可审计 | 每次调用是离散 API 请求 | 一连串 DOM 点击,难界定「做了什么」 |
| 反爬/风控 | 官方允许 | 触发 GitHub 风控(异常自动化) |

**结论:REST API(`https://api.github.com`),token 走 `Authorization: Bearer`。** 不驱动页面 DOM 做写操作。
- `fetch` 走 background SW(带 token header),**白名单域名只放 `api.github.com`**(呼应 fetch-text 白名单思路)。
- 建仓:`POST /user/repos` `{name, description, private}`。读:`GET /user/repos`、`GET /repos/{o}/{r}/issues`。

---

## 4. 动作设计(白名单 + schema + 确认卡)

复用现有 agent 骨架(registry/router/audit/确认卡)。新增 `github` 连接器,动作注册进 REGISTRY:

| action id | risk | confirm | params(schema) | 说明 |
|-----------|------|---------|----------------|------|
| `gh_list_repos` | L0 | none | `{query?}` | 列我的仓库(只读) |
| `gh_read_issues` | L0 | none | `{repo, state?}` | 读 issue 列表(只读) |
| `gh_create_repo` | L1 | **card** | `{name, description?, private?}` | 建仓。**确认卡**显示将建的名/描述/公私 |
| `gh_create_issue` | L1 | **card** | `{repo, title, body?}` | 开 issue,确认卡 |
| `gh_star` / `gh_fork` | L1 | **card** | `{repo}` | star/fork,确认卡 |

- **确认卡**(L1 全部):复用 CW-2 泛化确认卡,卡片写清「将在你的 GitHub 建公开仓库 `foo`,描述:…」,用户点确认才执行。**不批量、不静默。**
- **路由**:router 加 github 关键词分支——「在 github 建个叫 X 的仓,备注 Y」→ `gh_create_repo`;「我 github 有哪些仓」→ `gh_list_repos`。LLM 慢路径兜底。
- **token 未配置**:任何 gh_* 动作先查 `ghPat`,无则回 `needsConfig:'github_token'` + 引导(去 GitHub 建 PAT,只勾 `repo`,粘进来)。

---

## 5. 「自动建 token 选权限」为什么第一版不做

用户原话含「建立仓库操作 token 自动选择权限」。这步要**在 GitHub 网页新建 PAT 并勾选 scope**——属于驱动页面操作凭证页,风险最高:

- 要碰 GitHub 设置页(可能遇 2FA/密码确认);
- 「自动选权限」= 模型替你决定 token 有多大权,**越权风险**(勾多了 token 泄漏=账号大开);
- GitHub 对创建 token 的页面有反自动化。

**第一版替代(引导式,与「卸载插件→引导手动」同款思路)**:
- 智能体检测到无 token → 打开 `https://github.com/settings/tokens/new`(你亲手勾 `repo`、生成、粘回)。
- 扩展**只在本地校验 token 格式+调一次 `GET /user` 验证可用并读出 scope 给你看**,「这个 token 有这些权限:repo, gist…」让你确认。
- **自动建 token 留作后续**(若要,单独评估 GitHub fine-grained PAT API / OAuth App flow,且 scope 由你在确认卡里手选,不模型定)。

---

## 6. 隐私 / 安全红线清单(动工前逐条确认)

- [ ] token 只存本地,**永不进 LLM 上下文 / 审计明文 / 日志 / md 回显**。
- [ ] API 白名单只放 `api.github.com`;不带 token 访问任何非 GitHub 域。
- [ ] 每个 L1 写动作都有**确认卡**,写清将做什么;**不批量、不静默**。
- [ ] **不**替用户在 GitHub 网页勾 scope / 建 token(L2 不做自动,引导手动)。
- [ ] 审计只记动作+非敏感参数,可本地查看、可清。
- [ ] 建仓默认 `private:true` 还是 `false`?——**待拍板**(建议默认私有,最安全)。
- [ ] token 可选独立口令加密落盘(默认开?待拍板)。
- [ ] E2E 用 **GitHub 测试账号 / 专用 test repo**,Token 走环境变量,不碰你真账号主仓(呼应钱包 testnet 红线)。建仓 E2E 建完即删。

---

## 7. 实施步骤(拍板后)

1. **M1 凭证通路**:`ghPat` 存储 + 路由识别 `ghp_` 直存(不进 LLM)+ `GET /user` 校验+读 scope 展示。E2E:配 token→验证→列出权限。
2. **M2 只读动作**:`gh_list_repos`/`gh_read_issues`。E2E:列测试账号仓库。
3. **M3 写动作+确认卡**:`gh_create_repo`(确认卡→建仓→返回 url)。E2E 测试账号建仓即删。
4. **M4 issue/star/fork**:`gh_create_issue`/`gh_star`/`gh_fork`。
5. 全程红线回归(凭证隔离/审计打码/确认卡)。

**排期**:与 P1 securedm 的关系待拍板——是先做完 P1 再做 GitHub 连接器,还是 GitHub 连接器插队(用户需求更急)。

---

## 8. 待拍板汇总

1. **走 API(建议)还是 DOM?** —— 建议 API。
2. **建仓默认私有还是公开?** —— 建议默认私有。
3. **token 独立口令加密,默认开吗?**
4. **「自动建 token」第一版确认不做、改引导手动?**(建议不做)
5. **排期**:GitHub 连接器 vs P1 securedm,谁先?
6. **E2E 用哪个测试账号/仓?**(需要一个 GitHub 测试 token 走环境变量,不贴字面值)
