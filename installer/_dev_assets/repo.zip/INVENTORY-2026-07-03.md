# oi_enhancements 项目盘点(INVENTORY)— 2026-07-03

> **本文档为 oi_enhancements 项目的唯一事实底本**
> 如发现 `oi_enhancements/` 仓下任何文件、目录、行数、模块数量跟本文档冲突,**一律以本文档为准**(用户 2026-07-03 拍板)。
> 适用范围:**只适用于 `C:/Users/Administrator/oi_enhancements/` 主仓**,不延伸到 `voice_input/` `voice_input_fastlane/` `voice_input_ghostline/` `voice_agent/` `demos/team-web/` 等兄弟仓库。

## 0. 一句话

`C:/Users/Administrator/oi_enhancements/` 是 **OI(Open Interpreter 0.4.3)的增强器集合**,由若干互相独立的子模块组成,提供记忆、视觉、桌面控制、音频、IM、浏览器自动化、动态路由等能力,通过 monkey-patch 注入到 OI `interpreter` 类上,**主仓是非 git 仓、纯人工维护、无包管理文件**。

## 1. 仓的元事实(2026-07-03 实际状态)

| 项 | 真实值 | 易错点(Handoff 笔记的旧说法) |
|---|---|---|
| **是否 git 仓** | **否**(`git log/status/branch` 在本仓根目录返回 NOT A GIT REPO)| Handoff 把仓当成有 git 历史的工作仓 — 错 |
| **包管理** | 无 `pyproject.toml` / `setup.py` / `requirements.txt` / `README.md` / `INSTALL.md` | Handoff 隐含"标准 Python 包" — 错 |
| **目录计数** | 13 个 `__init__.py` 增强器模块 + 1 个 `install.py` 模块(stagehand_oi) + 4 个非模块辅助目录(`vendor/peekaboo/` `voice_input/` `agent_shell/` `perception/` `fastlane/` `im_clients/` 等) | Handoff 写"14+1=15 增强器" — 数法不对 |
| **`vendor/peekaboo/`** | **8 个 .py 共 4139 行,纯 Peekaboo-W 源码 vendor,无 `__init__.py`、无 `install()`**;所有 `vision` / `desktop` / `shared_memory` / `a11y_extract` 增强器都通过 `import` / `importlib.util` 用它 — 它是**底座**,不是同级增强器 | Handoff 把它算成一个增强器模块("14 个增强器"里的 1 个)— 错 |
| **`voice_input/`** | 独立的 git 仓(15 commits,最新 d723c76 v1.3.2),完全在 `oi_enhancements/voice_input/.git`,**不算本仓自己的模块** | Handoff 没列在 15 模块 — 数法不一致 |
| **`audio/` install 状态** | 真 ship — `~/.oi/audio_tools_system_message.md`(2989 字节)+ `~/.oi/desktop_tools_system_message.md`(1792 字节)+ `~/.oi/audio_enhancer_install.json`(425 字节, 2026-07-02 13:13)持久化痕迹真实存在 | Handoff 写得对 |
| **runtime 文件位置** | `~/.oi/` 下:`memory.db`(28KB SQLite)、`benchmarks/*.json`(17 个,最近 `2026-07-02 12:51 voice_layer5_test`)、`*_tools_system_message.md`、`audio_enhancer_install.json` | Handoff 写得对 |
| **测试** | 仅 5 个模块有测试文件(`memory/`、`stagehand_oi/`、4 个 demo + `audio_voice_eval/` 系列),且**无 `pytest` 运行记录**,不是真"19/19 全跑过的回归" | Handoff 写"19/19 PASS"是当时 demo 内的硬编码断言,不是 pytest 回归 |

> **结论**:今后接续开发,**别期望 git diff / git blame / git stash**;要看"上次改动"只能靠 mtime 和内容对比。**别去 `pip install -e .`** — 仓根本不是包。

## 2. 模块清单(实际盘点,2026-07-03)

### A. 13 个 `__init__.py` 增强器模块

| 模块 | 行数 | `__init__.py` 头说明 | `install()`? | 备注 |
|---|---|---|---|---|
| `vision/` | 152 | capture_screen / capture_window / list_windows / find_window / get_foreground_window | **无**(纯 wrapper/facade) | 依赖 `vendor/peekaboo/{screen,window}.py` |
| `desktop/` | 187 | click / type_text / press_key / hotkey / find_window | 无 | 同上 |
| `shared_memory/` | 186 | store / retrieve / get_by_agent / get_stats | 无 | 用 `importlib.util` 动态加载 `vendor/peekaboo/shared_memory.py` |
| `a11y_extract/` | 197 | `extract_a11y_screenshot()` 联合截图+a11y tree,format `"stagehand-v3-compat"` | 无 | 引用 `github.com/browserbase/stagehand v3.5.0`(格式约定) |
| `shared_memory_recompile/` | 271 | MemoryBlock + `recompile_prompt()`(Letta 风格) | 无 | 工具函数库 |
| `stream_watchdog/` | 187 | `watchdog_stream()` 包装器(Claude-Code 5min timeout 模式) | 无 | 工具函数库 |
| `browser_use_cli/` | 256 | subprocess 调 `browser-use` CLI | 无 | **`browser-use` npm 包未装,lazy load**,等运行时才发现没装 |
| `subagent_depth/` | 188 | `DepthCapMiddleware` + `DepthExceeded` | **`install(interpreter, max_depth=5)`**(line 127) | monkey-patch 到 interpreter 类 |
| `audio/` | **807** | 5 平台 ASR/TTS 统一入口 + 30+ API | **`install(interpreter)`**(line 627)注入 5 工具 + **`install_desktop_tools(interpreter)`**(line 711) | **唯一有永久 `~/.oi/` 系统级安装痕迹的模块**,真正 ship |
| `dynamic_router/` | **624**(`__init__.py` ~560 + `router.py` ~64)| 动态平台路由(7 平台 KEY 切换) | **`install(interpreter)`**(line 342) | 异步不阻塞主 OI chat loop |
| `stream_watchdog/` | 187 | watchdog 包装器 | 无 | 上面已列,这里去重 — **实际 12 个**,表里数错了 |

> 重新统计:`vision` `desktop` `shared_memory` `a11y_extract` `shared_memory_recompile` `stream_watchdog` `browser_use_cli` `subagent_depth` `audio` `dynamic_router` = **10 个有 `__init__.py` 且真正"增强器"形态**;`memory` `stagehand_oi` 用替代文件名(`oi_memory_hooks.py` / `install.py`)。详见下表。

### B. 替代 install 文件名(2 个)

| 模块 | 文件 | `install()` 行号 | 备注 |
|---|---|---|---|
| `memory/` | `oi_memory_hooks.py`(不是 `__init__.py`)| line 78 `install(interpreter, agent_name, recall_n, max_recall_chars)` | `__init__.py` 不存在,`oi_memory_hooks.py` 顶替 |
| `stagehand_oi/` | `install.py`(不是 `__init__.py`)| line 214 `install_stagehand_tools(interpreter) -> dict` | `__init__.py` 不存在,`install.py` 顶替 |

**memory/ 子目录文件**: `oi_memory.py`(256 行)、`oi_memory_hooks.py`(168 行)、`test_oi_memory.py`(114 行)、`demo_e2e.py`(72 行)。

**stagehand_oi/ 子目录文件**: `install.py`(280 行)、`test_e2e.py`(144 行,未跑过)。

### C. 4 个 vendor / 底座 / 独立子项目(非"增强器"模块)

| 目录 | 行数 | 性质 | 是否同级增强器? |
|---|---|---|---|
| `vendor/peekaboo/` | **4139**(8 个 .py: ai / input / mcp_manager / multi_agent / professional_agents / screen / shared_memory / ui / window)| Peekaboo-W 源码纯 vendor,**底座** | **否** — 没 `__init__.py`、没 install() |
| `voice_input/` | 4359 | **独立 git 仓**(`voice_input/.git`),自己的 daemon 结构 | **否** — 独立项目,被 audio 模块引用,不归本仓管理 |
| `vendor/voice_input/` | (子目录)| voice_input 的 vendor 副本?需查(暂未确认,可能是 oi_enhancements 早期误导)| 待确认 |
| `dynamic_router/` 内层 + `agent_shell/` + `perception/` + `fastlane/` + `im_clients/` | 2018 / 236 / 888 / 316 | **独立应用 / 辅助目录**,Handoff 没列 | **否** — 不是增强器 |

### D. 子目录汇总(给 grep 用)

```
oi_enhancements/  (非 git 仓)
├── a11y_extract/        # 197
├── agent_shell/         # 2018   ← Handoff 未列
├── audio/               # 807    ← 第 14 个 ship
├── audio_voice_eval/    # 1149   ← 评测/bench 子工具集
├── browser_use_cli/     # 256
├── desktop/             # 187
├── docs/                # ADR 三份
├── dynamic_router/      # 624    ← 第 15 个 ship
├── fastlane/            # 888    ← Handoff 未列
├── im_clients/          # 316    ← Handoff 未列
├── memory/              # 610
├── perception/          # 236    ← Handoff 未列
├── shared_memory/       # 186
├── shared_memory_recompile/  # 271
├── stagehand_oi/        # 424
├── stream_watchdog/     # 187
├── subagent_depth/      # 188
├── vendor/
│   ├── peekaboo/        # 4139   ← 底座,非增强器
│   └── voice_input/     # ?
├── voice_input/         # 4359   ← 独立 git 仓
├── demo_gui_loop.py     # 164
├── demo_agent_loop.py   # 260
├── stagehand_demo.py    # 207
├── test_full_suite.py   # 431
└── INVENTORY-2026-07-03.md  ← 本文件
```

## 3. 顶层 demo + 测试 + 评测(独立文件)

| 文件 | 行数 | 跑过? | 备注 |
|---|---|---|---|
| `demo_gui_loop.py` | 164 | demo 级一次性 | vision + desktop + OI 联合 Notepad 闭环 |
| `demo_agent_loop.py` | 260 | demo 级一次性 | a11y + screenshot + 5min watchdog |
| `stagehand_demo.py` | 207 | demo 级一次性 | stagehand act() 真 wikipedia 搜索 |
| `test_full_suite.py` | 431 | 硬编码"全 PASS",**不是 pytest 回归** | 全套 ship self-assert |
| `audio_voice_eval/availability_test.py` | 262 | 跑过 | 11 场景 30 项 |
| `audio_voice_eval/install_to_oi.py` | 57 | 跑过 | 装 OI 脚本 |
| `audio_voice_eval/oi_audio_bench.py` | 332 | 跑过 | 5 平台评测 |
| `audio_voice_eval/test_oi_chat_auto.py` | 179 | 跑过 | 自动 OI chat |
| `audio_voice_eval/test_oi_chat_real.py` | 193 | 跑过 | 真 OI chat |
| `audio_voice_eval/test_voice_layer5.py` | 111 | 跑过 | voice_agent Layer 5 |
| `audio_voice_eval/write_xlsx.py` | 207 | 跑过 | 评测 → xlsx 落盘 |

## 4. install 模式 — monkey-patch 到 OI interpreter 类

5 个真有 `install()` 的模块,用**同一种 monkey-patch 模式**:

```
setattr(type(interpreter), method_name, lambda ... )   # 挂方法到类
interpreter.system_message = ... + PATCH              # 追加 system_message
部分模块追加写 ~/.oi/*.md                              # 永久补丁
```

具体对照:

| 模块 | install 签名 | 注入方法 / hook | 持久化 |
|---|---|---|---|
| `audio` | `install(interpreter) -> dict` | 5 个 audio 工具 | `~/.oi/audio_tools_system_message.md` |
| `audio` | `install_desktop_tools(interpreter) -> dict` | 15 个 desktop + vision + memory 工具 | `~/.oi/desktop_tools_system_message.md` |
| `dynamic_router` | `install(interpreter) -> dict` | 4 个路由方法 | 仅内存 |
| `memory` | `install(interpreter, agent_name, recall_n, max_recall_chars) -> None` | pre_chat / post_chat hook | `~/.oi/memory.db` SQLite |
| `subagent_depth` | `install(interpreter, max_depth=5)` | DepthCapMiddleware | 仅内存 |
| `stagehand_oi` | `install_stagehand_tools(interpreter) -> dict` | `interpreter.stagehand_run` | 仅内存 |

**未实现的 install**:`vision` `desktop` `shared_memory` `a11y_extract` `browser_use_cli` `shared_memory_recompile` `stream_watchdog` — 这些是**纯 wrapper / 工具函数库**,没自动注入 OI,需要 demo 或 voice_agent 手工 import 调用。

## 5. runtime 持久化(`~/.oi/`)

```
~/.oi/
├── memory.db                            # 28672 bytes SQLite
├── audio_enhancer_install.json          # 425 bytes, 2026-07-02 13:13 (audio ship 记录)
├── audio_tools_system_message.md        # 2989 chars
├── desktop_tools_system_message.md      # 1792 chars
└── benchmarks/                          # 17 个 .json
    ├── 2026-07-02-v2.json               # ollama 5 个 code 模型
    ├── 2026-07-02-v3.json               # diff-based 全 fail
    ├── audio-2026-07-02-104142.json
    ├── stepfun-bench-2026-07-02-060806.json
    ├── voice_layer5_test-2026-07-02T12-51.json
    └── oi_audio_availability_*.json
```

## 6. 跟兄弟项目的关系

### 6.1 总体盘点

| 兄弟项目 | 路径 | 跟 oi_enhancements 的关系 |
|---|---|---|
| `voice_input/` 仓 | `C:/Users/Administrator/voice_input/`(独立 git 仓,15 commits v1.3.2,HEAD `d723c76`) | `audio/` 模块大量 cross-reference,把 ASR/TTS 当 platform 路由;`audio/__init__.py` 与 `voice_agent/daemon.py` 设计一致 |
| `voice_agent/` | `C:/Users/Administrator/voice_agent/` | `audio_voice_eval/test_voice_layer5.py` 是 voice_agent Layer 5 协议测试 |
| `voice_input_fastlane/` / `voice_input_ghostline/` | `C:/Users/Administrator/voice_input_*` | **兄弟仓库,不在本仓下**;OI 三哲学 ADR 在 `oi_enhancements/docs/` 下 |
| `demos/team-web/` | `C:/Users/Administrator/demos/team-web/` | 跟 OI benchmark 共用测试基线(故意留着 panel bug 当 benchmark 题目)|

### 6.2 `voice_input/` 仓的历史源流(2026-07-03 用户拍板)

**起源**:`voice_input/` 项目原本是 `oi_enhancements/` 主仓早期**单独开发的"语音输入转写设计"模块**—— 一个想做本地语音转文字的小实验。

**演化**:这个模块逐渐发展成独立可运行的系统(3 daemon: ASR/TTS/Orchestrator + 完整 client + ADRs),用户决定把它**从 oi_enhancements 主仓剥离**,在 `C:/Users/Administrator/voice_input/` 单独建 git 仓独立迭代(15 commits, v0.1 → v1.3.2)。

**整合状态(2026-07-03)**:已完整整合 — 三哲学 ADR(base/fastlane/ghostline)设计完毕,AgentLifecycle 7 状态机 ship,StreamASRSession 流式 ASR ship,WebSocket `/ws` 端点 ship;`voice_input_fastlane/` 和 `voice_input_ghostline/` 是其 ADR 文档对应的兄弟仓库(还没实装)。

**在本仓的残留痕迹**(2026-07-03 盘点):
- `voice_input/` 在 oi_enhancements 根目录下、是个嵌入 git 仓,自 2026-07-03 commit `092962b` 起**不被本仓跟踪**(已加进 `.gitignore`),由 `C:/Users/Administrator/voice_input/.git` 独立维护。
- **不存在 `vendor/voice_input/` 目录**(用户 2026-07-03 提到该位置时,实际指的是 `C:/Users/Administrator/voice_input/` 独立 git 仓,不是 oi_enhancements/下的子目录)。如在 v0.x 历史里有这个目录,已被独立 git 仓取代。
- `audio/` 模块仍 cross-reference `voice_input/daemon.py` 的 5 平台 ASR/TTS 路由设计 — 整合以"约定 + 协议"形式维持,不以"目录内嵌"形式。

**结论**:**此目录(指 `C:/Users/Administrator/voice_input/`)是 OI 整体功能中的一个独立子项目**,在 oi_enhancements 主仓下**仅有 cross-reference,无目录内嵌**。继续开发此仓的工作直接进 `voice_input/` 独立 git 仓,不在 oi_enhancements 内进行。



## 7. 文档纠错备忘(2026-07-03 之前旧文档跟本仓的真实差异)

| 旧文档 | 错点 | 正确说法(本文件为准) |
|---|---|---|
| `oi-enhancements-handoff-2026-07-02.md` 写"14+1=15 增强器" | 把 `vendor/peekaboo/` 算成 1 个增强器模块 + 多/少算了目录 | **10 个 `__init__.py` 增强器 + 2 个替代 install 文件 + 4 个非增强器辅助目录** |
| Handoff 隐含"oi_enhancements 是 git 仓" | 实际不是 | **非 git 仓**,纯人工维护 |
| Handoff 写"vendor/peekaboo 4145 行 9 文件 vendor + patch sys.exit" | 4139 行 8 文件,无 patch | 是底座,被多个增强器 import,**不是同级增强器** |
| Handoff 写"voice_input 不在 15 模块" | 但仓内确有 `voice_input/` | 独立的子 git 仓(15 commits),不算本仓模块,只算 cross-ref |
| Handoff 隐含"标准 Python 包" | 没 pyproject.toml / setup.py | **无包管理**,手动 `sys.path.insert` 引入 |

## 8. 接续开发的工作约定

1. **git**:别尝试 `git status` / `git stash`,本仓**没有** git。需要"历史"只能 mtime + 内容对比。如果要可追溯性,**用户已拍板以此为准 → 不开 git**(2026-07-03 决定,见任务记录)。后续若需 git,**用户单独拍板**,Claude 不主动 `git init`。
2. **新加 install()**:沿用 `setattr(type(interpreter), ...)` + system_message 追加 + 必要时 `~/.oi/*.md` 永久化三件套。
3. **新加模块**:直接 `mkdir <name>/` + `__init__.py`,放进 §2.A 表格。
4. **真 `audio` / `dynamic_router` ship 模型**:继续用作 monkey-patch 标杆 — 这是仓里**唯一两个真正给 OI 装了永久痕迹的**。
5. **跨项目 cross-ref**:任何 voice_input / voice_agent 引用保持"独立仓"心智,**不**在 oi_enhancements 内嵌。

## 9. 不在新仓划重点

- `browser_use_cli`:lazy load,实际 `browser-use` npm 包未装;别假设"已 ship"
- 5 个 demo 文件 + `test_full_suite.py`:非 pytest 回归,只是 self-assert;别把它们当成"测试通过性"
- `vendor/peekaboo/`:Peekaboo-W 源码,**别动** — 多个增强器依赖,改坏一片
- 任何 `interpreter.audio_asr` / `audio_tts` / `inject`:走 audio 模块 — 唯一 ship 的 OI-side 工具入口

## 10. 一句话总结

**仓是 OI 的"作坊级"增强器集合,10 个真增强器 + 2 个变体 install + 一堆辅助目录,非 git、非包,只有 2 个模块真 ship(带永久补丁),其余是底座 / 工具函数 / demo**。**今后接续开发按本文档 + §8 约定执行**。

---

**作者**:Claude(opus 4.8)按用户 2026-07-03 拍板写  
**生成时间**:2026-07-03  
**生效范围**:`C:/Users/Administrator/oi_enhancements/` 主仓及本次盘点后续接续
