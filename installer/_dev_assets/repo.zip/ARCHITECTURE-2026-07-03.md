# oi_enhancements 架构图 — 2026-07-03

> **配套事实底本**。与 `INVENTORY-2026-07-03.md` 互为索引 — 本文件用图说清楚"怎么动",INVENTORY 用表说清楚"有什么"。

## 阅读顺序

1. **§1 进程拓扑**(一张 Mermaid 子图)— 谁在哪里跑,谁跟谁说话
2. **§2 install 链**(一张 Mermaid 类图)— 5 个 install 入口的横向边界
3. **§3 典型事件流**(三张 Mermaid 时序图)— F8 热键、OI speak、OI open/type/click
4. **§4 全部图使用的颜色规范 + 命名约定**

---

## 1. 进程拓扑:仓库边界 / 进程边界 / 端口

```mermaid
flowchart LR

  subgraph WIN["🖥️ Windows 桌面(被操控目标)"]
    Notepad["Notepad / Chrome / 任意窗口"]
  end

  subgraph OI_PROC["🤖 OI 进程 (单进程)"]
    direction TB
    LLM["OI LLM<br/>OpenInterpreter 0.4.3<br/>devstral / qwen / stepfun"]
    MONKEY["Monkey-patch 挂载<br/>setattr(type(interpreter), X, …)<br/>实例属性覆盖 chat()"]
    ENH["增强器方法<br/>audio_asr / audio_tts<br/>dt_click / vi_capture_screen<br/>dynamic_route / stagehand_run<br/>chat() ← wrapped"]
  end

  subgraph VA_PROC["🎙️ voice_action_demo (独立)"]
    LISTENER["hotkey_listener.py<br/>F8/F9 + Ctrl+Alt+R"]
    VAD_DEMO["keyboard_lib<br/>+ pyautogui"]
  end

  subgraph AGENT_PROC["🧠 voice_agent daemon.py"]
    LAYER5["Layer 5: [ACTION:json]<br/>execute_action(click/type/...)<br/>importlib 动态 import 增强器"]
  end

  subgraph VI_PROC["📦 voice_input 仓 (3 daemon 进程)"]
    ORCH["Orchestrator<br/>:8730<br/>POST /speak /inject<br/>GET /agent_state /health"]
    ASR["ASR daemon<br/>:8731<br/>POST /record_and_transcribe<br/>WS /ws (流式)<br/>POST /inject"]
    TTS["TTS daemon<br/>:8732<br/>POST /synthesize<br/>Windows SAPI"]
  end

  subgraph VE_PROC["📁 oi_enhancements 仓 (Python 模块库)"]
    direction TB
    AUDIO["audio/__init__.py<br/>5 平台 ASR/TTS 路由<br/>edge-tts + googletrans 免费 fallback"]
    DROUTER["dynamic_router/__init__.py<br/>7 平台 KEY 切换"]
    MEM["memory/oi_memory_hooks.py<br/>OIMemory pre/post chat"]
    STAGE["stagehand_oi/install.py<br/>stagehand_run 实例方法"]
    DESKTOP["desktop/__init__.py<br/>click/type/hotkey"]
    VISION["vision/__init__.py<br/>capture_screen/list_windows"]
    VENDOR["vendor/peekaboo/<br/>8 文件底座<br/>(InputController/Window)<br/>ai / multi_agent / mcp_manager"]
  end

  subgraph EXT["☁️ 外部平台"]
    BAILIAN["BAILIAN<br/>qwen3-asr-flash<br/>sambert-v1"]
    SF["SILICONFLOW<br/>SenseVoiceSmall<br/>CosyVoice2"]
    STEP["STEPFUN<br/>step-asr-1.1"]
    EDGE["edge-tts<br/>微软 WebSocket"]
    GOOGLE["googletrans<br/>Google API"]
  end

  %% OI 内部
  LLM --> MONKEY --> ENH
  ENH -.动态 import.-> AUDIO
  ENH -.动态 import.-> DESKTOP
  ENH -.动态 import.-> VISION
  ENH -.动态 import.-> MEM

  %% OI 调 voice_input
  ENH ==HTTP==> ORCH
  ENH ==HTTP / WS==> ASR

  %% voice_action_demo
  LISTENER -.F8 触发录音.-> ASR
  VAD_DEMO -->|"pyautogui 注入"| Notepad

  %% voice_agent
  LAYER5 -.importlib.-> DESKTOP
  LAYER5 -.importlib.-> VISION
  LAYER5 -.importlib.-> MEM
  LAYER5 -.importlib.-> AUDIO

  %% voice_input 内部
  ORCH ==Mute Gate==>|TTS 播放前后| ASR
  ORCH ==HTTP==> TTS
  ASR -->|"process_vad_on_chunk<br/>Silero VAD"| AudioCap[AudioCapture<br/>sounddevice]
  ASR --> SenseVoice["SenseVoice Small<br/>241MB onnx(本地)"]
  TTS --> WinSAPI["Windows SAPI<br/>winsound.PlaySound"]

  %% audio 模块调云端
  AUDIO ==HTTPS==> BAILIAN
  AUDIO ==HTTPS==> SF
  AUDIO ==HTTPS==> STEP
  AUDIO ==WebSocket==> EDGE
  AUDIO ==> GOOGLE

  %% vendor
  DESKTOP -.依赖.-> VENDOR
  VISION -.依赖.-> VENDOR
  Shared_Memory["shared_memory/<br/>Peekaboo-W 4 层"] -.依赖.-> VENDOR

  %% Windows 操控
  DESKTOP -->|"click/type/hotkey"| Notepad
  STAGE -.依赖浏览器.-> Notepad

  classDef process fill:#e1f5ff,stroke:#01579b,color:#000
  classDef internal fill:#fff3e0,stroke:#e65100,color:#000
  classDef external fill:#f3e5f5,stroke:#4a148c,color:#000
  classDef gua fill:#e8f5e9,stroke:#1b5e20,color:#000

  class ORCH,ASR,TTS,OI_PROC,VA_PROC,AGENT_PROC process
  class AUDIO,DROUTER,MEM,STAGE,DESKTOP,VISION,VENDOR,Shared_Memory internal
  class BAILIAN,SF,STEP,EDGE,GOOGLE external
  class SenseVoice,WinSAPI,AudioCap,LISTENER,VAD_DEMO,LAYER5,LLM,MONKEY,ENH gua
```

**关键观察**(从图可见):

- **仓库边界 ≠ 进程边界**:`voice_input/` 是独立 git 仓(15 commits),运行时是 3 个 OS 进程;`oi_enhancements/` 是 Python 模块库,**不直接产生任何 OS 进程**,只在 OI / voice_agent 进程内被 import。
- **audio 模块是"云端 SDK 路由器",跟 voice_input 仓无调用关系** — Explore B 已确认 audio 没有调用 voice_input 任何 REST 端点。
- **OI 进程内 monkey-patch 是唯一一处"把 Python 模块库变成 OI 工具"的地方**。
- **GUI 操控路径有 2 条独立通道**:① OI → desktop 模块 → pyautogui(直接)② voice_agent → 动态 import desktop 模块 → pyautogui。

---

## 2. install 链:5 个 install 入口 + 3 种注入模式

```mermaid
classDiagram

  class OI_Class {
    +llm: any
    +system_message: str
    +auto_run: bool
    +chat(): generator
    +audio_asr() 类方法
    +audio_tts() 类方法
    +audio_translate() 类方法
    +audio_chat() 类方法
    +audio_platforms() 类方法
    +dt_click() 类方法
    +dt_type_text() 类方法
    +vi_capture_screen() 类方法
    +mm_recall() 类方法
    +dynamic_route() 类方法
    +dynamic_route_async() 类方法
    +dynamic_platforms() 类方法
    +dynamic_executor 实例属性
    +stagehand_run 实例属性
    +_stagehand_available 实例属性
    +_depth_cap 实例属性
  }

  class Interpreter_Instance {
    +chat: wrapped generator
    +system_message: extended
    +stagehand_run
    +_depth_cap
    +agent_name
  }

  class Audio_Install {
    +install(interpreter)
    +install_desktop_tools(interpreter)
  }

  class DynamicRouter_Install {
    +install(interpreter)
  }

  class Memory_Install {
    +install(interpreter, agent_name, recall_n, max_recall_chars)
  }

  class Stagehand_Install {
    +install_stagehand_tools(interpreter)
  }

  class SubAgentDepth_Install {
    +install(interpreter, max_depth)
  }

  class PersistentFiles {
    +~/.oi/audio_tools_system_message.md
    +~/.oi/desktop_tools_system_message.md
    +~/.oi/audio_enhancer_install.json
    +~/.oi/memory.db (SQLite)
  }

  OI_Class <|.. Interpreter_Instance

  Audio_Install --> OI_Class : setattr 类属性<br/>5 个 audio_* 方法
  Audio_Install --> Interpreter_Instance : system_message += AUDIO_TOOLS
  Audio_Install ..> PersistentFiles : 写 .md / .json

  Audio_Install ..> Audio_Install : install_desktop_tools()<br/>setattr 类属性<br/>14 个 dt_/vi_/mm_
  Audio_Install ..> PersistentFiles : 写 desktop_tools_system_message.md

  DynamicRouter_Install --> OI_Class : setattr 类属性<br/>4 个 dynamic_*
  DynamicRouter_Install --> Interpreter_Instance : system_message += DYNAMIC_ROUTER

  Memory_Install --> Interpreter_Instance : 覆盖实例属性 chat()<br/>pre_chat: recall + inject ctx<br/>post_chat: store L3
  Memory_Install ..> PersistentFiles : 写 ~/.oi/memory.db

  Stagehand_Install --> Interpreter_Instance : 设实例属性<br/>stagehand_run + _stagehand_available
  Stagehand_Install --> Interpreter_Instance : system_message += TOOL_DESCRIPTOR
  Stagehand_Install ..> PersistentFiles : **不写**

  SubAgentDepth_Install --> Interpreter_Instance : 设 _depth_cap 容器<br/>middleware 未来生效

  classDef monkey_class fill:#fff3e0,stroke:#e65100
  classDef monkey_inst fill:#e1f5ff,stroke:#01579b
  classDef pure_meta fill:#f3e5f5,stroke:#4a148c

  class Audio_Install,DynamicRouter_Install monkey_class
  class Memory_Install,Stagehand_Install,SubAgentDepth_Install monkey_inst
  class PersistentFiles pure_meta
```

**关键发现**:

1. **三组方法名互不重叠** — 不会互相覆盖,顺序无关紧要
2. **类属性 vs 实例属性**:
   - 类属性(`setattr(type(interpreter), X)`):所有 interpreter 实例共享,重启 OI 后消失
   - 实例属性(`interpreter.X = ...`):仅当前实例,重启消失
3. **memory.install 是唯一 chat 拦截器**(覆盖 `interpreter.chat` generator)— 必须在其他 install **之前**跑,否则 chat 会绕过 pre/post hooks
4. **audio.install 与 install_desktop_tools 共存但互不调,功能完全分开**(audio = 5 平台 SDK 路由;desktop = pyautogui 输入 + 截图)
5. **只有 audio/install 真正写永久文件**(`~/.oi/audio_tools_system_message.md` + `audio_enhancer_install.json`)— 这是判断"已 ship"的硬证据
6. **subagent_depth 实际没生效** — OI 0.4.3 不原生支持 sub-agent spawn,目前是 future-proof 容器

---

## 3. 典型事件流(三张时序图)

### 3.1 事件 A:F8 全局热键 → mic 录音 → 文本注入焦点窗口

```mermaid
sequenceDiagram
    autonumber
    participant U as 用户
    participant HL as hotkey_listener.py
    participant ASR as voice_input<br/>ASR daemon :8731
    participant VAD as Silero VAD
    participant SV as SenseVoice<br/>(241MB onnx 本地)
    participant IM as Pyperclip + Ctrl+V
    participant WIN as Windows 焦点窗口

    U->>HL: 按 F8
    HL->>ASR: POST /record_and_transcribe (max_seconds=15)
    ASR->>VAD: AudioCapture.start_listening()
    VAD-->>ASR: 检测到 speech start
    ASR->>U: 🎤 mic 采集
    U->>ASR: 说话(中文)
    VAD-->>ASR: 检测到 silence 800ms
    ASR->>VAD: stop_listening()
    ASR->>SV: transcribe(wav_bytes)
    SV-->>ASR: "打开记事本在里面打字 hello"
    ASR->>ASR: ASR_MEMORY_WRITER.write(text)<br/>→ Peekaboo L3
    ASR->>IM: inject_text(text)<br/>→ 先 imm32 切英文 IME
    IM->>WIN: pyperclip.copy + Ctrl+V
    ASR-->>HL: {"text": "打开记事本…"}
```

**关键点**:
- VAD 自动停录,无须人工按停止
- inject 在 ASR daemon 进程内发生,不经过 orchestrator
- mic 静音(mute gate)由 orchestrator 控制,这里 F8 走 ASR daemon 不走 orchestrator → 不静音

---

### 3.2 事件 B:OI LLM 输出 `speak('hello')` → TTS 播放(mute gate)

```mermaid
sequenceDiagram
    autonumber
    participant LLM as OI LLM<br/>(interpreter.chat)
    participant MEM as memory.oi_memory_hooks<br/>(pre/post)
    participant INT as interpreter<br/>(speak 实例方法)
    participant AUDIO as audio/__init__.py
    participant BAILIAN as ☁️ BAILIAN SDK
    participant ORCH as Orchestrator :8730
    participant ASR as ASR daemon :8731
    participant TTS as TTS daemon :8732
    participant SAPI as Windows SAPI

    LLM->>MEM: chat(task)
    MEM->>MEM: pre_chat: OIMemory.recall(task) → ctx
    MEM->>LLM: chat(task + ctx)<br/>(generator 透传)
    LLM-->>MEM: yield chunks (assistant response)
    MEM->>MEM: post_chat: store(L3, task+response)
    Note over LLM,INT: LLM 决策输出<br/>speak("已完成,已开 Notepad")
    LLM->>INT: code block 调<br/>interpreter.audio_tts(...)
    INT->>AUDIO: audio_tts(text, wav_path, voice='auto')
    AUDIO->>BAILIAN: dashscope sambert-zhichu-v1
    BAILIAN-->>AUDIO: 125KB wav bytes
    AUDIO->>AUDIO: wav_bytes → write wav_path
    INT->>ORCH: POST /speak {text:"已完成"}
    ORCH->>ORCH: presence.get() = "voice"
    ORCH->>ORCH: with_mute_gate(text, tts_call)
    ORCH->>ASR: POST /mute (mic 静音)
    ORCH->>TTS: POST /synthesize {text}
    TTS->>SAPI: PlaySound(win_synth.wma)
    SAPI-->>TTS: 播放完毕
    TTS-->>ORCH: {"status":"ok"}
    ORCH->>ASR: POST /unmute (mic 解除静音)
    ORCH-->>INT: {"status":"ok","route":"tts"}
```

**关键点**:
- **mute gate 在 orchestrator**,不是 ASR 也不是 OI — 这是中间层
- audio 模块跟 voice_input REST 没关系(直接 bypass — 见 §1)
- memory hooks 在 chat 级别拦截,**对 audio_tts() 透明**
- SILICONFLOW fallback(CosyVoice2 中文不 work)、edge-tts 最后兜底

---

### 3.3 事件 C:OI LLM 决策 click/type → pyautogui 注入

```mermaid
sequenceDiagram
    autonumber
    participant LLM as OI LLM
    participant ENH as interpreter<br/>(monkey-patched)
    participant DESK as desktop/__init__.py
    participant VEND as vendor/peekaboo/<br/>InputController
    participant PG as PyAutoGUI
    participant IMM as imm32.dll<br/>(IME)
    participant WIN as Windows 桌面

    Note over ENH: install_desktop_tools 已挂<br/>dt_click / dt_type_text / vi_capture_screen
    LLM->>ENH: 第一轮 code block:<br/>screenshot = interpreter.vi_capture_screen()
    ENH->>DESK: vision.capture_screen(monitor=0, max_width=1024)
    DESK-->>VEND: mss / peekaboo screen
    VEND-->>DESK: PNG bytes
    DESK-->>ENH: return (1024×n) PNG
    LLM->>LLM: screenshot+a11y tree → STEPFUN LLM 决策<br/>{"action":"click","x":512,"y":540,"text":"hello"}
    LLM->>ENH: 第二轮 code block:<br/>interpreter.dt_click(512, 540)
    ENH->>DESK: desktop.click(512, 540)
    DESK->>PG: pyautogui.click(512*SCALE, 540*SCALE)
    PG->>WIN: mouse move + mouse down/up
    LLM->>ENH: 第三轮 code block:<br/>interpreter.dt_type_text("hello")
    ENH->>DESK: desktop.type_text("hello")
    DESK->>IMM: ImmSetConversionStatus<br/>(强制切英文)
    DESK->>VEND: detect_chinese("hello") → 全英文
    DESK->>PG: pyautogui.typewrite("hello", interval=0.02)
    PG->>WIN: KEY_DOWN/UP hello
    ENH-->>LLM: {"status":"ok"}
    Note over LLM,WIN: 端到端:GUI 截图 → LLM 决策坐标 → pyautogui 输入
```

**关键点**:
- OI LLM **不会直接调 pyautogui**,必须通过 monkey-patch 后的 interpreter method
- 截图的坐标(1024 系)→ 真实屏幕坐标有 SCALE 缩放(demo_gui_loop L125)
- type 之前必先切英文 IME(L226-245),否则中文输入法污染

---

## 4. 图例约定

```
颜色      含义
🟦 蓝   进程 / 服务运行时
🟧 橙   Python 模块(被 import 的代码)
🟪 紫   外部云端平台
🟩 绿   概念性 / 内部组件

线条类型
━━━ 实线 同步调用 / 数据流
╍╍╍ 点线 import 关系(动态或静态)
═══ 双线 HTTP / WebSocket / 进程间通信
```

---

## 5. 跟 INVENTORY 的交叉索引

| INVENTORY 章节 | ARCHITECTURE 对应章节 |
|---|---|
| §2.A 10 个真增强器(类属性 monkey-patch)| §2 install 链 classDiagram |
| §2.B 2 个变体 install(实例属性 / 直接设)| §2 stagehand + memory + subagent_depth |
| §2.C 4+ 辅助目录 | §1 vendor 节点 |
| §3 demo 文件 | §3 事件流 A/B/C |
| §4 install 模式解释 | §2 完整覆盖 |
| §5 `~/.oi/` 持久化 | §2 PersistentFiles 节点 |
| §6 兄弟项目关系 | §1 进程拓扑 |

---

**作者**:Claude(opus 4.8)按用户 2026-07-03 拍板写
**生成时间**:2026-07-03  
**生效范围**:`C:/Users/Administrator/oi_enhancements/` 主仓
